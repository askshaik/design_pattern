#include <iostream>
namespace decorator
{
using namespace std;
class Beverage {
	public:
	Beverage() = default;
	Beverage(Beverage&) = delete;
	Beverage& operator=(Beverage &) = delete;
	virtual int cost() = 0;
	virtual void dispense() = 0;
	virtual ~Beverage(){}
};
class Coffee : public Beverage {
	public:
	int cost() override { return 15; }
	void dispense() override { cout << "Coffee dispensed\n"; }
};
class Tea : public Beverage {
	public:
	int cost() override { return 10; }
	void dispense() override { cout << "Tea dispensed\n"; }
};
class CondimentDecorator : public Beverage {
	protected:
	Beverage *b;
	public:
	CondimentDecorator(Beverage *b1) :b(b1) {}
};
class Milk : public CondimentDecorator {
	public:
	Milk(Beverage *b) : CondimentDecorator(b) {}
	int cost() override { return 2 + b->cost() ; }
	void dispense() override {
			b->dispense();
			cout << "Milk dispensed\n";
	}
};
class Sugar : public CondimentDecorator {
	public:
	Sugar(Beverage *b) : CondimentDecorator(b) {}
	int cost() override { return 1 + b->cost(); }
	void dispense() override {
			cout << "Sugar dispensed\n";
			b->dispense();
	}
};
}
void decorator_main() {
	using namespace decorator;
	Beverage *b = new Milk(new Sugar(new Tea()));
    cout << b->cost() << endl;
	b->dispense();
}
