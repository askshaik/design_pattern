#include <iostream>
#include <vector>
using namespace std;
namespace inter {
class Product {
	public: int price,color;
	Product(int p, int c) { price = p; color = c; }
};

class Spec {
	public: virtual bool isSatisfiedBy(Product *p)  = 0;
};
class ProductFinder { public:
	vector<Product *> products;
	vector<Product *> *selectBy(Spec *criteria) {
		vector<Product *> *r = new vector<Product *>();
		for (unsigned int i=0; i<products.size(); i++) {
			Product *p = products[i];
			if (criteria->isSatisfiedBy(p)) r->push_back(p);
		}
		return r;
	}
};
class AndSpec : public Spec {
	Spec *part1, *part2;
	public: AndSpec(Spec *p1,Spec *p2) { part1=p1; part2=p2; }
	bool isSatisfiedBy(Product *p) {
		return part1->isSatisfiedBy(p) && part2->isSatisfiedBy(p);
	}
};
class BelowPriceSpec : public Spec {
	int price;
	public: BelowPriceSpec(int price1) { price = price1;}
	bool isSatisfiedBy(Product *p) {
		return p->price < price;
	}
};
class NotSpec : public Spec {
	Spec *part;
	public: NotSpec(Spec *p) { part=p; }
	bool isSatisfiedBy(Product *p) {
		return !part->isSatisfiedBy(p);
	}
};
class ColorSpec : public Spec {
	int color;
	public: ColorSpec(int color1) { color = color1;}
	bool isSatisfiedBy(Product *p) {
		return p->color == color;
	}
};
}
void inter_main() {
	using namespace inter;
	ProductFinder pf;
	pf.products.push_back( new Product (100,5));
	pf.products.push_back( new Product (50,6));
	pf.products.push_back( new Product (60,5));
	pf.products.push_back( new Product (70,5));
	vector<Product *> *v =pf.selectBy ( new AndSpec (new BelowPriceSpec(90), new ColorSpec(6)));
	for (unsigned int i=0; i<v->size(); i++)
		cout << i << "  price=" << v->at(i)->price << "   color=" << v->at(i)->color << endl;
}















