#include <iostream>
#include <vector>
namespace observer {
using namespace std;

class Observer {
	public: virtual void update() = 0;
	virtual ~Observer(){}
};
class Observerable {
	Observerable& operator= (Observerable& ) = delete;
	Observerable(Observerable&) = delete;
	vector<Observer *> observers;
protected:
	Observerable() { }
public:
	void addObserver(Observer *o) {
		observers.push_back(o);
	}
	void notifyObservers() const {
		for (auto p : observers)
			p->update();
	}
	virtual ~Observerable() {}
};
class WeatherData : public Observerable {
	public:
	int temperature, humidity, pressure;
	WeatherData() {
		temperature = humidity = pressure = 0;
	}
};
class Device1 : public Observer {
	public: void update() override {
		cout << "Device1 received update of weather" << endl;
	}
};
class Device2 : public Observer {
	public: void update() override {
		cout << "Device2 received update of weather" << endl;
	}
};
}
void observer_main() {
	using namespace observer;
	Device1 d1;
	Device2 d2;
	WeatherData wd;
	wd.addObserver(&d1);
	wd.addObserver(&d2);
	wd.notifyObservers();
}
