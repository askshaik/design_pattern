#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <boost/thread/condition_variable.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/lock_types.hpp>

using namespace std;


namespace object_pool {
	class Semaphore {
		volatile int count_;
		boost::mutex mutex_;   //mutex_ protects count_.

		//Code that increments count_ must notify the condition variable.
		boost::condition_variable condition_;
	public:
		explicit Semaphore(int initial_count)
			: count_(initial_count), mutex_(), condition_()  { }
		void signal() //called "release" in Java
		{
			boost::unique_lock<boost::mutex> lock(mutex_);
			++count_;
			condition_.notify_one();
		}
		void wait() //called "acquire" in Java
		{
			boost::unique_lock<boost::mutex> lock(mutex_);
			while (count_ == 0)
				condition_.wait(lock);
			--count_;
		}
	};

	class Reusable_pool;
	class Reusable {
		int number;
		Reusable(int n) : number(n) {}
		friend class Reusable_pool;
		friend ostream& operator<< (ostream &cout, Reusable &r);
	};
	class Reusable_pool {
		static const int POOL_SIZE = 10;
		vector<Reusable *> pool;
		Semaphore lock;
		boost::mutex pool_lock;
	public:
		Reusable_pool() : lock(POOL_SIZE) {
			for (auto i=0; i<POOL_SIZE; ++i)
				pool.push_back(new Reusable(i));
		}
		Reusable *acquire();
		void release(Reusable *resource_acquired_earlier) {
			boost::unique_lock<boost::mutex> lock_for_vector(pool_lock);
			pool.push_back(resource_acquired_earlier);
			lock.signal();
		}
		~Reusable_pool() {
			for (auto r : pool) delete r;
		}
		static Reusable_pool *get_instance();
	};
	Reusable *Reusable_pool::acquire() {
		lock.wait();
		boost::unique_lock<boost::mutex> lock_for_vector(pool_lock);
		Reusable *r = pool.front();
		pool.erase(pool.begin());
		return r;
	}
	ostream& operator<< (ostream &cout, Reusable &r) {
		return cout << "Reusable [" << r.number << "]";
	}
	Reusable_pool *Reusable_pool::get_instance() {
		static Reusable_pool instance; //Singleton
		return &instance;
	}
}
using namespace object_pool;
boost::mutex print_lock;   //Only one thread should print on cout at any point of time.

void wait_random_time() {
	this_thread::sleep_for(chrono::seconds(rand() % 5 + 1));
}
void get_and_release() { //infinite loop, started from multiple threads.
	Reusable_pool *rp = Reusable_pool::get_instance();
	while (true) {
		wait_random_time();
		Reusable *r = rp->acquire();
		{
	        boost::unique_lock<boost::mutex> lock(print_lock);
	        cout << "Thread " << this_thread::get_id() << " acquired resource " << *r << endl;
		}
		wait_random_time();
		rp->release(r);
		{
	        boost::unique_lock<boost::mutex> lock(print_lock);
			cout << "Thread " << this_thread::get_id() << " released resource " << *r << endl;
		}
	}
}
void object_pool_main() {
	srand(time(0));
	for(auto i=0;i<20;++i)
		new thread(get_and_release);
	get_and_release();
}
