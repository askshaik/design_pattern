#include <iostream>
using namespace std;

namespace builder {
class ActualBuilder;
class Actual {
	int a, b, c, d, e;
	Actual (int a1, int b1, int c1, int d1, int e1) {
		a = a1; b = b1; c = c1; d = d1; e = e1;
	}
	friend ActualBuilder;
	public:
	//...
};
class ActualBuilder {
	int a, b, c, d, e;
	bool ag, bg, cg, dg, eg;
	public:
	ActualBuilder() {
		ag = bg= cg = dg = eg = false;
	}
	void SetA(int a1) { a = a1; ag = true; }
	void SetB(int b1) { b = b1; bg = true; }
	void SetC(int c1) { c = c1; cg = true; }
	void SetD(int d1) { d = d1; dg = true; }
	void SetE(int e1) { e = e1; eg = true; }
	Actual *give_instance() {
		if (!ag) a = 5;
		if (!bg) b = 25;
		if (!cg) c = 20;
		if (!dg) d = 21;
		if (!eg) e = 31;
		//...
		return new Actual(a,b,c,d,e);
	}
};
}
void builder_main() {
	using namespace builder;
	ActualBuilder ab;
	ab.SetB(50);
	ab.SetD(25);
	Actual *a = ab.give_instance();
	delete a;
}
