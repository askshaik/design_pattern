#include <iostream>
#include <functional>
using namespace std;

namespace builderFluent {
	class ActualBuilder;
	class Actual {
		int a, b, c;
		Actual(int a1, int b1, int c1) {
			a = a1; b = b1; c = c1;
		}
		friend ActualBuilder;
	public:
		//...
	};
	class ActualBuilder {
		int a, b, c;
		bool ag, bg, cg;
	public:
		ActualBuilder() {
			ag = bg = cg = false;
		}
		ActualBuilder* SetA(int a1) { a = a1; ag = true; return this; }
		ActualBuilder* SetB(int b1) { b = b1; bg = true; return this; }
		ActualBuilder* SetC(int c1) { c = c1; cg = true; return this; }
		static Actual* give_instance(function<void(ActualBuilder *)> set_params) {
			ActualBuilder b;
			set_params(&b);
			if (!b.ag) b.a = 5;
			if (!b.bg) b.b = 25;
			if (!b.cg) b.c = 20;
			//...
			return new Actual(b.a, b.b, b.c);
		}
	};
}
void builder_fluent_main() {
	using namespace builderFluent;
	builderFluent::Actual * a = ActualBuilder::give_instance([](ActualBuilder* b) {b->SetB(20)->SetC(1); });
	delete a;
}
