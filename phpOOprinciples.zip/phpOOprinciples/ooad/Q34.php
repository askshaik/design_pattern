<?php
declare (strict_types=1);

//Improve the code
class CustomersInDB {
    /** @var Connection */
    private $conn;
    function getCustomer(string $IDNumber): Customer {
        $st = $this->conn->prepareStatement('select * from customer where ID=?');
        try {
            $st->setString(1, str_replace("-()/", "    ", $IDNumber));
            $rs = $st->executeQuery();
            //...
        } finally {
            $st->close();
        }
    }
    function addCustomer(Customer $customer): void {
        $st = $this->conn->prepareStatement('insert into customer values(?,?,?,?)');
        try {
            $st->setString(1, str_replace('-()/', '    ', $customer->getIDNumber()));
            $st->setString(2, $customer->getName());
            //...
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
    //...
}
