<?php
declare (strict_types=1);
use \Ds\Map;

//Improve the code
class FoodDB {
    //find all foods whose names contain both the keywords. returns
    //an iterator on these foods.
    function srchFood(String $cName, String $eName): iterable {
        //it contains all the foods to be returned.
        $food_tree = new Map();
        $food_list = $this->getAllRecords();
        foreach ($food_list as $food) {
            //do its names contain both keywords?
            if (($cName === null || //null or "" means no key is specified
                    $cName === "" ||
                    strpos($food->getCName(), $cName) !== false)
                &&
                ($eName === null || //null or "" means no key is specified
                    $eName === "" ||
                    strpos($food->getEName(), $eName) !== false))
                $food_tree->put($food->getFoodKey(), $food);
        }
        return $food_tree->values();
    }
    //...
}