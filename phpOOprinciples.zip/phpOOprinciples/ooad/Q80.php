<?php
declare (strict_types=1);

/*This is a small program handling zip files. The user can input the
 * path to the zip file such as c:\f.zip and the paths to the files
 * that he would like to add to the zip file such as c:\f1.doc,
 * c:\f2.doc and etc. in the main frame, then the program will compress
 * f1.doc and f2.doc and create f.zip. When it is compressing each file,
 * the status bar in the main frame will display the related message.
 * For example, when it is compressing c:\f2.doc,
 * the status bar will display "zipping c:\f2.zip".
 */

class ZipMainFrame extends Frame {
    /** @var StatusBar */    private $sb;

    function makeZip(): void {
        $zip_file_path = "";
        $src_file_paths = [];
        //setup zip_file_path and src_file_paths according to the UI.
        $ze = new ZipEngine();
        $ze->makeZip($zip_file_path, $src_file_paths, $this);
    }

    function setStatusBarText(string $statusText): void {
        $this->sb->setText($statusText);
    }
    //...
}
class ZipEngine {
    function makeZip(string $zipFilePath, array $srcFilePaths, ZipMainFrame $f): void {
        //create zip file at the path.
        //...
        foreach ($srcFilePaths as $src_file) {
            $f->setStatusBarText("Zipping " . $src_file);
            //...
        }
    }
    //...
}
