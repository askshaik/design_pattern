<?php
declare (strict_types=1);

/* This is a word processor application. It can let the user select the
 * font. Before the user confirms to change the font, it will let the
 * user preview the effect of the change. The current code is shown below.
 * Point out the code smell. If we need to reuse the ChooseFontDialog
 * in a GUI application that doesn't support this preview functionality,
 * how should you change the code?
 */
class WordProcessorMainFrame extends JFrame {
    function onChangeFont(): void {
        $chooseFontDialog = new ChooseFontDialog($this);
        if ($chooseFontDialog->showOnScreen()) {
            $newFont = $chooseFontDialog->getSelectedFont();
            //show the contents using this new font.
        } else {
            //show the contents using the existing font.
        }
    }
    function previewWithFont(Font $font): void {
        //show the contents using this preview font.
    }
    //...
}
class ChooseFontDialog extends JDialog {
    /** @var WordProcessorMainFrame */  private $mainFrame;
    /** @var Font */                    private $selectedFont;
    function __construct(WordProcessorMainFrame $mainFrame) {
        $this->mainFrame = $mainFrame;
    }
    function onSelectedFontChange(): void {
        $this->selectedFont = $this->getSelectedFontFromUI();
        $this->mainFrame->previewWithFont($this->selectedFont);
    }
    function getSelectedFont(): Font {
        return $this->selectedFont;
    }
    function getSelectedFontFromUI(): Font {
        ///...
    }
    function showOnScreen(): bool {
        //...
    }
}
