<?php
declare (strict_types=1);

class NormalPayment {
    /** @var int */
    private $units;
    /** @var float */
    private $rate;
    const TAX_RATE = 0.1;
    function getBillableAmount(): float {
        $base_amt = $this->units * $this->rate;
        $tax = $base_amt * self::TAX_RATE;
        return $base_amt + $tax;
    }
}
class PaymentForSeniorCitizen {
    /** @var int */
    private $units;
    /** @var float */
    private $rate;
    const TAX_RATE = 0.1;
    function getBillableAmount(): float {
        $base_amt = $this->units * $this->rate * 0.8;
        $tax = $base_amt * (self::TAX_RATE - 0.05);
        return $base_amt + $tax;
    }
}

