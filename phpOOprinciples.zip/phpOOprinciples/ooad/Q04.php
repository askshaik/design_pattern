<?php
declare (strict_types=1);
namespace ooad;
//Improve code
class ParticipantsInDB {
    /** @var Connection */
    private $db;
    function addParticipant(Participant $part): void {
        $st = $this->db->prepareStatement('INSERT INTO participants VALUES (?,?,?,?,?,?,?)');
        try {
            $st->setString(1, $part->getId());
            //...
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
    function deleteAllParticipants(): void {
        $st = $this->db->prepareStatement('DELETE FROM participants');
        try {
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
    function getCount(): int {
        $st = $this->db->prepareStatement('SELECT COUNT(*) FROM participants');
        try {
            $rs = $st->executeQuery();
            $rs->next();
            return $rs->getInt(1);
        } finally {
            $st->close();
        }
    }
    //...
}
