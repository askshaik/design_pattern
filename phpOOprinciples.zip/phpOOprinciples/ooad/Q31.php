<?php
declare (strict_types=1);
//Improve the code
class UserAccount {
    const USERTYPE_NORMAL = 0;
    const USERTYPE_ADMIN = 1;
    const USERTYPE_GUEST = 2;
    /** @var int */
    public $userType;
    /** @var string */
    private $id;
    /** @var string */
    private $name;
    /** @var string */
    private $password;
    /** @var DateTime */
    public $dateOfLastPasswdChange;
    function checkPassword(string $password): bool {
        //...
    }
    //...
}
class InventoryApp {
    function login(UserAccount $userLoggingIn, string $password): void {
        if ($userLoggingIn->checkPassword($password)) {
            $today = new DateTime();
            $expiry_date = $this->getAccountExpiryDate($userLoggingIn);
            if ($today > $expiry_date) {
                //prompt the user to change password
            }
        }
    }

    function getAccountExpiryDate(UserAccount $account): DateTime {
        $password_max_age_in_days = $this->getPasswordMaxAgeInDays($account);
        $expiry_date = new DateTime();
        $ad = $account->dateOfLastPasswdChange;
        $expiry_date->setTime((int)$ad->format('H'), (int)$ad->format("i"), (int)$ad->format('s'));
        return $expiry_date->add(new DateInterval("P{$password_max_age_in_days}D"));
    }

    function getPasswordMaxAgeInDays(UserAccount $account): int {
        switch ($account->userType) {
        case UserAccount::USERTYPE_NORMAL:
            return 90;
        case UserAccount::USERTYPE_ADMIN:
            return 30;
        case UserAccount::USERTYPE_GUEST:
            return PHP_INT_MAX;
        }
    }

    function printReport(UserAccount $currentUser): void {
        $can_print = false;
        switch ($currentUser->userType) {
        case UserAccount::USERTYPE_NORMAL:
            $can_print = true;
            break;
        case UserAccount::USERTYPE_ADMIN:
            $can_print = true;
            break;
        case UserAccount::USERTYPE_GUEST:
            $can_print = false;
        }
        if ($can_print === false) {
            throw new RuntimeException("You have no right");
        } //print the report.
    }
}

