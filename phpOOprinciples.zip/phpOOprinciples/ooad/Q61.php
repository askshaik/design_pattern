<?php
declare (strict_types=1);

class Game {
    public const SIZE = 3;

    public const EMPTY = 0;
    public const CROSS = 1;
    public const CIRCLE = 2;

    /** @var int[][] */ private $board = [];

    public function __construct() {
        for ($r = 0; $r < self::SIZE; ++$r) {
            $this->board[] = [];
            for ($c = 0; $c < self::SIZE; ++$c)
                $this->board[$r][] = self::EMPTY;
        }
    }
    function putX(int $r, int $c): void {
        $this->board[$r][$c] = self::CROSS;
    }
    function putO(int $r, int $c): void {
        $this->board[$r][$c] = self::CIRCLE;
    }
    function isEmpty(int $r, int $c): bool {
        return $this->board[$r][$c] === self::EMPTY;
    }
    function isOver(): bool {
        /* The game is over, if any of the following condition is true
           - The board is filled
           - Any row is filled with same element
           - Any column is filled with same element
           - The left or right diagonal is filled with same element.
        */
    }
}
//Complete the function isOver using functional programming techniques.
