<?php
declare (strict_types=1);

/* This program below implements a game called "MasterMind". The game
 * is played like this: the computer "comes up with" a secret code such
 * as "RGBY" in which "R" means red, "G" means green, "B" means blue,
 * "Y" means yellow, "P" means pink, "C" means cyan.
 * The task of the player is to try to find out this secret code.
 * Every turn the player can input a code also consisting of four colors
 * such as "RBPY". In this case, he has got "R" correct because the
 * secret code also contains "R" in the first position. The same is true
 * for "Y". In contrast, the secret code contains "B", but the position is
 * not correct. In response to the guess, the computer will tell the player
 * that he has got two pegs in correct color and position (but will not tell
 * him that they are "R" and "Y") and that he has got one peg in the
 * correct color but incorrect position (but will not tell him that
 * it's "B"). The player has at most 12 turns. If he can find out the
 * secret code within 12 turns, he wins. Otherwise he loses.
 *
 * 	Point out and remove the problems in the code below.
 *
 */
class MasterMind {
private $secret = "RGBY";
function __construct() {
        for ($i = 0; $i < 12;) { //can guess at most 12 times
            $current_guess = readline("Guess:");
            $current_secret = $this->secret;
            $m = 0; //how many pegs are right in color and position.
            $n = 0; //how many pegs are right in color but wrong position.
            //valid the colors and find those in right color and position.
            for ($j = 0; $j < strlen($current_guess);) {
                //must sure each peg is one of: Red, Yellow, Pink, Green, Blue or Cyan.
                if (strpos("RYPGBC", substr($current_guess, $j, 1)) === false) {
                    echo "Invalid color!\n";
                    break;
                }
                if (substr($current_guess, $j, 1) === substr($current_secret, $j, 1)) {
                    //right color and position.
                    $m++;
                    //delete the peg.
                    $current_guess = substr($current_guess, 0, $j) . substr($current_guess, $j + 1);
                    $current_secret = substr($current_secret, 0, $j) . substr($current_secret, $j + 1);
                } else {
                    $j++;
                }
            }
            //see how many pegs are in right color but wrong position.
            for ($j = 0; $j < strlen($current_guess);) {
                //is it in right color regardless of the position?
                $k = strpos($current_secret, substr($current_guess, $j, 1));
                if ($k !== false) {
                    $n++;
                    //delete the peg.
                    $current_guess = substr($current_guess, 0, $j) . substr($current_guess, $j + 1);
                    $current_secret = substr($current_secret, 0, $k) . substr($current_secret, $k + 1);
                } else {
                    $j++;
                }
            }
            echo ((string)$m) . " are right in color and position\n";
            echo ((string)$n) . " are right in color but wrong position\n";
            if ($m==4) { //all found?
                echo "You won!\n";
                return;
            }
            $i++;
        }
        echo "You lost!\n";
    }
}
new MasterMind();
