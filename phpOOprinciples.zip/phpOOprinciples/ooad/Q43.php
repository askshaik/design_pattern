<?php
declare (strict_types=1);
use \Ds\Map;

// Point out and remove the code smells in the code
class Customer {
    /** @var string */
    public $homeAddress;
    /** @var string */
    public $workAddress;
}
class Order {
    /** @var string */
    private $orderId;
    /** @var Restaurant */
    private $restaurantReceivingOrder;
    /** @var Customer */
    private $customerPlacingOrder;

    //"H": deliver to home address of the customer.
    //"W": deliver to work address of the customer.
    //"O": deliver to the address specified here.
    /** @var string */
    private $addressType;

    /** @var string */
    private $otherAddress; //address if addressType is "O".
    /** @var Map */
    private $orderItems;

    function getDeliveryAddress(): ?string {
        if ($this->addressType === "H") {
            return $this->customerPlacingOrder->homeAddress;
        } elseif ($this->addressType === "W") {
            return $this->customerPlacingOrder->workAddress;
        } elseif ($this->addressType === "O") {
            return $this->otherAddress;
        } else {
            return null;
        }
    }
    //...
}