<?php
declare (strict_types=1);
//Improve the code
class Badge {
    /** @var string */
    private $pid; //participant ID
    /** @var string */
    private $engName; //participant's full name in English
    /** @var string */
    private $chiName; //participant's full name in Chinese
    /** @var string */
    private $engOrgName; //name of the participant's organization in English
    /** @var string */
    private $chiOrgName; //name of the participant's organization in Chinese
    /** @var string */
    private $engCountry; //the organization's country in English
    /** @var string */
    private $chiCountry; //the organization's country in Chinese
    //***********************
    //constructor.
    //The participant ID is provided. It then loads all the info from the DB.
    //***********************
    function __construct(string $pid) {
        $this->pid = $pid;
        //***********************
        //get the participant's full names.
        //***********************
        $parts_in_db = ParticipantsInDB::getInstance();
        $part = $parts_in_db->locateParticipant($pid);
        if ($part !== null) {
            //get the participant's full name in English.
            $this->engName = $part->getELastName() + ", " + $part->getEFirstName();
            //get the participant's full name in Chinese.
            $this->chiName = $part->getCLastName() + $part->getCFirstName();
            //***********************
            //get the organization's name and country.
            //***********************
            $orgs_in_db = OrganizationsInDB::getInstance();
            //find the ID of the organization employing this participant.
            $oid = $orgs_in_db->getOrganization($pid);
            if ($oid !== null) {
                $org = $orgs_in_db->locateOrganization($oid);
                $this->engOrgName = $org->getEName();
                $this->chiOrgName = $org->getCName();
                $this->engCountry = $org->getEAddress()->getCountry();
                $this->chiCountry = $org->getCAddress()->getCountry();
            }
        }
    }
//...
}
