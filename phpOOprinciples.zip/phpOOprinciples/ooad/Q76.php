<?php
declare (strict_types=1);

abstract class PricingService {
    function calculatePrice(ShoppingBasket $shoppingBasket, User $user, string $voucher): float {
        $discount = $this->calculateDiscount($user);
        $total = 0;
        foreach ($shoppingBasket->items() as $item)
            $total += $this->calculateProductPrice($item->getProduct(), $item->getQuantity());
        $total = $this->applyAdditionalDiscounts($total, $user, $voucher);
        return $total * ((100 - $discount) / 100);
    }
    protected abstract function calculateDiscount(User $user): float;
    protected abstract function calculateProductPrice(Product $product, int $quantity): float;
    protected abstract function applyAdditionalDiscounts(float $total, User $user, string $voucher): float;
}

abstract class UserDiscountPricingService extends PricingService {
    private function calculateDiscount(User $user): float {
        return $user->isPrime() ? 10 : 0;
    }
}

abstract class VoucherPricingService extends UserDiscountPricingService {
    /** @var VoucherService */    private $voucherService;
    private function applyAdditionalDiscounts(float $total, User $user, string $voucher): float {
        $voucher_value = $this->voucherService->getVoucherValue($voucher);
        $total_after_value = $total - $voucher_value;
        return ($total_after_value > 0) ? $total_after_value : 0;
    }
    function setVoucherService(VoucherService $voucherService): void {
        $this->voucherService = $voucherService;
    }
}

class StandardPricingService extends VoucherPricingService {
    protected function calculateProductPrice(Product $product, int $quantity): float {
        return $product->getPrice() * $quantity;
    }
}

class BoxingDayPricingService extends VoucherPricingService {
    const BOXING_DAY_DISCOUNT = 0.60;
    protected function calculateProductPrice(Product $product, int $quantity): float {
        return $product->getPrice() * $quantity * self::BOXING_DAY_DISCOUNT;
    }
}
