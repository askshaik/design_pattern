<?php
declare (strict_types=1);
//Improve the code
class Currency {
    const USD = 0;
    const RMB = 1; //Chinese currency
    const ESCUDO = 2; //Portuguese currency
    /** @var int */
    private $currencyCode;
    function __construct(int $currencyCode) {
        $this->currencyCode = $currencyCode;
    }
    function format(int $amount): string {
        switch ($this->currencyCode) {
        case self::USD:
            //return something like $1,200
        case self::RMB:
            //return something like RMB1,200
        case self::ESCUDO:
            //return something like $1.200
        }
        throw RuntimeException("Invalid value");
    }
}