<?php
declare (strict_types=1);
//Improve the code
class Payment {
    const FOC = 'FOC'; //free of charge.
    const TT = 'TT'; //paid by telegraphic transfer.
    const CHEQUE = 'Cheque'; //paid by cheque.
    const CREDIT_CARD = 'CreditCard'; //paid by credit card.
    const CASH = 'Cash'; //paid by cash.

    //type of payment. Must be one of the above constant.
    /** @var string */
    private $paymentType;
    /** @var DateTime */
    private $paymentDate; //if FOC, the date the fee is waived.
    /** @var int */
    private $actualPayment; //if FOC, it is 0.
    /** @var int */
    private $discount; //if FOC, the amount that is waived.
    /** @var string */
    private $bankName; //if it is by TT, cheque or credit card.
    /** @var string */
    private $chequeNumber; //if it is by cheque.

    //if it is by credit card.
    /** @var string */
    private $creditCardType;
    /** @var string */
    private $creditCardHolderName;
    /** @var string */
    private $creditCardNumber;
    /** @var DateTime */
    private $creditCardExpiryDate;

    function getNominalPayment(): int {
        return $this->actualPayment + $this->discount;
    }
    function getType(): string {
        return $this->paymentType;
    }

    function getBankName(): string {
        if ($this->paymentType === self::TT ||
            $this->paymentType === self::CHEQUE ||
            $this->paymentType === self::CREDIT_CARD)
            return $this->bankName;
        else
            throw new RuntimeException('Bank name is undefined for this payment type');
    }
    //...
}
