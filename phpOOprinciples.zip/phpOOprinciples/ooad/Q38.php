<?php
declare (strict_types=1);
require_once 'Q37.php';
//Improve the code
class EditPaymentDialog extends JDialog {
    /** @var Payment */
    private $newPayment; //new payment to be returned.
    /** @var JPanel */
    private $sharedPaymentDetails;
    /** @var JPanel */
    private $uniquePaymentDetails;
    /** @var JTextField */
    private $paymentDate;
    /** @var JComboBox */
    private $paymentType;
    /** @var JTextField */
    private $discountForFOC;
    /** @var JTextField */
    private $bankNameForTT;
    /** @var JTextField */
    private $actualAmountForTT;
    /** @var JTextField */
    private $discountForTT;
    /** @var JTextField */
    private $bankNameForCheque;
    /** @var JTextField */
    private $chequeNumberForCheque;
    /** @var JTextField */
    private $actualAmountForCheque;
    /** @var JTextField */
    private $discountForCheque;
    //...

    function __construct() {
        //setup the components.
        $content_pane = $this->getContentPane();
        $combo_box_items = [ //available payment types.
            Payment::FOC, Payment::TT, Payment::CHEQUE, Payment::CREDIT_CARD, Payment::CASH];

        //setup the components for the details shared by all types of payment.
        $this->sharedPaymentDetails = new JPanel();
        $this->paymentDate = new JTextField();
        $this->paymentType = new JComboBox($combo_box_items);
        $this->sharedPaymentDetails->add($this->paymentDate);
        $this->sharedPaymentDetails->add($this->paymentType);
        $content_pane->add($this->sharedPaymentDetails, BorderLayout::NORTH);

        //setup the unique components for each type of payment.
        $this->uniquePaymentDetails = new JPanel();
        $this->uniquePaymentDetails->setLayout(new CardLayout());

        //setup a panel for FOC payment.
        $panel_for_FOC = new JPanel();
        $this->discountForFOC = new JTextField();
        $panel_for_FOC->add($this->discountForFOC);
        $this->uniquePaymentDetails->add($panel_for_FOC, Payment::FOC);

        //setup a panel for TT payment.
        $panel_for_TT = new JPanel();
        $this->bankNameForTT = new JTextField();
        $this->actualAmountForTT = new JTextField();
        $this->discountForTT = new JTextField();
        $panel_for_TT->add($this->bankNameForTT);
        $panel_for_TT->add($this->actualAmountForTT);
        $panel_for_TT->add($this->discountForTT);
        $this->uniquePaymentDetails->add($panel_for_TT, Payment::TT);

        //setup a panel for cheque payment.
        $panel_for_cheque = new JPanel();
        $this->bankNameForCheque = new JTextField();
        $this->chequeNumberForCheque = new JTextField();
        $this->actualAmountForCheque = new JTextField();
        $this->discountForCheque = new JTextField();
        $panel_for_cheque->add($this->bankNameForCheque);
        $panel_for_cheque->add($this->chequeNumberForCheque);
        $panel_for_cheque->add($this->actualAmountForCheque);
        $panel_for_cheque->add($this->discountForCheque);
        $this->uniquePaymentDetails->add($panel_for_cheque, Payment::CHEQUE);

        //setup a panel for credit card payment.

        //setup a panel for cash payment.

        $content_pane->add($this->uniquePaymentDetails, BorderLayout::CENTER);
    }

    function editPayment(Payment $payment): Payment {
        $this->displayPayment($payment);
        $this->setVisible(true);
        return $this->newPayment;
    }

    function displayPayment(Payment $payment): void {
        $this->paymentDate->setText($payment->getDateAsString());
        $this->paymentType->setSelectedItem($payment->getType());
        if ($payment->getType() === Payment::FOC) {
            $this->discountForFOC->setText((string)$payment->getDiscount());
        } elseif ($payment->getType() === Payment::TT) {
            $this->bankNameForTT->setText($payment->getBankName());
            $this->actualAmountForTT->setText((string)$payment->getActualAmount());
            $this->discountForTT->setText((string)$payment->getDiscount());
        } elseif ($payment->getType() === Payment::CHEQUE) {
            $this->bankNameForCheque->setText($payment->getBankName());
            $this->chequeNumberForCheque->setText($payment->getChequeNumber());
            $this->actualAmountForCheque->setText((string)$payment->getActualAmount());
            $this->discountForCheque->setText((string)$payment->getDiscount());
        } elseif ($payment->getType() === Payment::CREDIT_CARD) {
            //...
        } elseif ($payment->getType() === Payment::CASH) {
            //...
        }
    }
    function onOK(): void { //when the user clicks OK.
        $this->newPayment = $this->makePayment();
        $this->dispose();
    }

    //make a payment from the components.
    function makePayment(): Payment {
        $payment_type_string = (String)$this->paymentType->getSelectedItem();
        $payment = new Payment(paymentTypeString);
        $payment->setDateAsText($this->paymentDate->getText());
        if ($payment_type_string === Payment::FOC) {
            $payment->setDiscount((int)$this->discountForFOC->getText());
        } elseif ($payment_type_string === Payment::TT) {
            $payment->setBankName($this->bankNameForTT->getText());
            $payment->setActualAmount((int)$this->actualAmountForTT->getText());
            $payment->setDiscount((int)$this->discountForTT->getText());
        } elseif ($payment_type_string === Payment::CHEQUE) {
            $payment->setBankName($this->bankNameForCheque->getText());
            $payment->setChequeNumber($this->chequeNumberForCheque->getText());
            $payment->setActualAmount((int)$this->actualAmountForCheque->getText());
            $payment->setDiscount((int)$this->discountForCheque->getText());
        } elseif ($payment_type_string === Payment::CREDIT_CARD) {
            //...
        } elseif ($payment_type_string === Payment::CASH) {
            //...
        }
        return $payment;
    }
    //...
}
