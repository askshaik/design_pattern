<?php
declare (strict_types=1);

//Improve the code
class Shape {
    const TYPELINE = 0;
    const TYPERECTANGLE = 1;
    const TYPECIRCLE = 2;
    /** @var int */
    private $shapeType;

    //starting point of the line.
    //lower left corner of the rectangle.
    //center of the circle.
    /** @var Point */
    private $p1;

    //ending point of the line.
    //upper right corner of the rectangle.
    //not used for the circle.
    /** @var Point */
    private $p2;

    /** @var int */
    private $radius;

    public function getType(): int {
        return $this->shapeType;
    }
    public function getP1(): Point {
        return $this->p1;
    }
    public function getP2(): Point {
        return $this->p2;
    }
    public function getRadius(): int {
        return $this->radius;
    }
    //...
}
class CADApp {
    function drawShapes(Graphics $graphics, array $shapes): void {
        foreach ($shapes as $shape) {
            switch ($shape->getType()) {
            case Shape::TYPELINE:
                $graphics->drawLine($shape->getP1(), $shape->getP2());
                break;
            case Shape::TYPERECTANGLE:
                //draw the four edges.
                $graphics->drawLine(//...
                );
                $graphics->drawLine(//...
                );
                $graphics->drawLine(//...
                );
                $graphics->drawLine(//...
                );
                break;
            case Shape::TYPECIRCLE:
                $graphics->drawCircle($shape->getP1(), $shape->getRadius());
                break;
            }
        }
    }
}
