<?php
declare (strict_types=1);
//improve code
class ReportCatalogueIndexCommandParser {
    const NO_GROUPING = 'orgNoGrouping';
    const ORG_CATALOG = 0;
    const PART_CATALOG = 1;
    //.... other codes
    function getGroupingType(string $grouping): int {
        if ($grouping === self::NO_GROUPING) {
            return self::ORG_CATALOG;
        } elseif ($grouping === 'orgGroupByCountry') {
            return self::ORG_CATALOG;
        } elseif ($grouping === 'orgGroupByTypeOfOrgName') {
            return self::ORG_CATALOG;
        } elseif ($grouping === 'part') {
            return self::PART_CATALOG;
        }
        // many other elif statements
        else
            throw new InvalidArgumentException("Invalid grouping!");
    }
}
