<?php
declare (strict_types=1);
use \Ds\Vector;

class PianoKey {
    const key0 = 0;
    const key1 = 1;
    const key2 = 2;
    /** @var int */
    private $keyNumber;
    function playSound(): void {
        if ($this->keyNumber == 0) {
            //play the frequency for key0
        } elseif ($this->keyNumber == 1) {
            //play the frequency for key1
        } elseif ($this->keyNumber == 2) {
            //play the frequency for key2
        }
    }
//Functions to set keyNumber to key0, key1 or key2
}
class Piano {
    /** @var Vector */
    private $rhythm;
    function play(): void {
        foreach ($this->rhythm as $piano_key)
            $piano_key->playSound();
    }
    //...
}

