<?php
declare (strict_types=1);
use \Ds\Vector;

//Improve the code
class BookRentals {
    /** @var Vector */    private $rentals;
    function countRentals(): int {
        return $this->rentals->count();
    }
    function getRentalAt(int $i): BookRental {
        return $this->rentals->get($i);
    }
    function printOverdueRentals(): void {
        for ($i = 0; $i < $this->countRentals(); $i++) {
            $rental = $this->getRentalAt($i);
            if ($rental->isOverdue() &&
                true //some Complex if condition here
            )
                echo $rental . '\n';
        }
    }
    function countOverdueRentals(): int {
        $count = 0;
        for ($i = 0; $i < $this->countRentals(); $i++)
            if ($this->getRentalAt($i)->isOverdue() &&
                true //Same complex condition as above
            )
                $count++;
        return $count;
    }
    //...
}