<?php
declare (strict_types=1);

/* This application is concerned with the training courses.
 * The schedule of a course can be expressed in three ways (as of now):
 *	weekly, range or list.
 * A weekly schedule is like "every Tuesday for 5 weeks starting
 *   from Oct. 22".
 * A range schedule is like "Every day from Oct. 22 to Nov. 3".
 * A list schedule is like "Oct. 22, Oct. 25, Nov. 3, Nov. 10".
 * In this exercise we will ignore the time and just assume that it is
 * always 7:00pm-10:00pm. It is expected that new ways to express the
 * schedule may be added in the future.
 * Point out and remove the code smells in the code
 */
class Course {
    const WEEKLY = 0;
    const RANGE = 1;
    const LIST = 2;
    private $scheduleType; // WEEKLY, RANGE, or LIST

    /** @var string */
    private $courseTitle;
    /** @var int */
    private $noWeeks; // For WEEKLY.
    /** @var DateTime */
    private $fromDate; // for WEEKLY and RANGE.
    /** @var DateTime */
    private $toDate; // for RANGE.
    /** @var DateTime[] */
    private $dateList; // for LIST.

    function getDurationInDays(): int {
        switch ($this->scheduleType) {
        case self::WEEKLY:
            return $this->noWeeks;
        case self::RANGE:
            return (int)($this->fromDate->diff($this->toDate)->days);
        case self::LIST:
            return count($this->dateList);
        default:
            return 0; // unknown schedule type!
        }
    }

    function printSchedule(): void {
        switch ($this->scheduleType) {
        case self::WEEKLY:
            //...
        case self::RANGE:
            //...
        case self::LIST:
            //...
        }
    }
    //...
}
