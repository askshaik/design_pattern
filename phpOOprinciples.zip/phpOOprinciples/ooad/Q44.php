<?php
//We need exclusive access to FILE1 and DATABASE1.
//New resources will be added later on. The design should be able
//accommodate these new resource allocation/deallocation easily.
declare (strict_types=1);
require_once '../myUtils/BetterEnum.php';
use myutil\BetterEnum;

class ResourceType extends BetterEnum {
    const FILE1 = 1;
    const DATABASE1 = 2;
}
class Ra1 {
    function allocate(ResourceType $r): int {
        $resource_id = 0;
        switch ($r->getValue()) {
        case ResourceType::FILE1:
            $resource_id = $this->getFreeFile();
            break;
        case ResourceType::DATABASE1:
            $resource_id = $this->getFreeDatabase();
        }
        return $resource_id;
    }

    function free(ResourceType $r, int $resourceId): void {
        switch ($r->getValue()) {
        case ResourceType::FILE1:
            $this->markFileFree($resourceId);
            break;
        case ResourceType::DATABASE1:
            $this->markDatabaseFree($resourceId);
        }
    }
    function markDatabaseFree(int $a): void {
        //...
    }
    function markFileFree(int $a): void {
        //...
    }
    function getFreeFile(): int {
        //...
    }
    function getFreeDatabase(): int {
        //...
    }
}