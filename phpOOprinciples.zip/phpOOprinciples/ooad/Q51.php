<?php
declare (strict_types=1);

class Department {
    const ACCOUNT = 0;
    const MARKETING = 1;
    const CUSTOMER_SERVICES = 2;
    /** @var int */
    protected $departmentCode;
    function __construct(int $departmentCode) {
        $this->departmentCode = $departmentCode;
    }
    function getDepartmentName(): string {
        switch ($this->departmentCode) {
        case self::ACCOUNT:
            return "Account";
        case self::MARKETING:
            return "Marketing";
        case self::CUSTOMER_SERVICES:
            return "Customer Services";
        }
    }
    //...
}
