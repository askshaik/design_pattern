<?php
declare (strict_types=1);

//Remove the duplication for scanning the listeners array
interface GridListener {
    function onRowAppended(): void;
    function onRowMoved(int $existingIdx, int $newIdx): void;
}
class Grid {
    /** @var GridListener[] */    private $listeners = [];

    function appendRow(): void {
        //append a row at the end of the grid.
        foreach ($this->listeners as $grid_listener)
            $grid_listener->onRowAppended();
    }

    function moveRow(int $existingIdx, int $newIdx): void {
        //move the row.
        foreach ($this->listeners as $grid_listener)
            $grid_listener->onRowMoved($existingIdx, $newIdx);
    }
}
