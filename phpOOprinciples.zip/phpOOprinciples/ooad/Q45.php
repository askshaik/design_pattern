<?php
declare (strict_types=1);

//Suppose you are writing a module to approve personal loans and
//before doing that you want to validate the personal information.
//Later on, its required to approve vehicle loans, consumer goods loans and what not.
class LoanApprovalHandler {
    function approvePersonalLoan(PersonalLoanValidator $validator): void {
        if ($validator->isValid()) {
            //Process the loan.
        }
    }
    function approveVehicleLoan(VehicleLoanValidator $validator): void {
        if ($validator->isValid()) {
            //Process the loan.
        }
    }
    // Methods for approving other loans.
}

class PersonalLoanValidator {
    function isValid(): bool {
        //Validation logic
    }
}

class VehicleLoanValidator {
    function isValid(): bool {
        //Validation logic
    }
}

