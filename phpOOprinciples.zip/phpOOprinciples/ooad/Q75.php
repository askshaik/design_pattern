<?php
declare (strict_types=1);

//Remove the problem in code below.
//Assume that PropertyFileWriter is not used anywhere else
//other than class App.
class FileWriter {
    function __construct(string $filename) {
        //...
    }
    function write(string $line): void {
        //...
    }
    function close(): void {
        //...
    }
}
class PropertyFileWriter extends FileWriter {
    function __construct(string $path) {
        parent::__construct($path);
    }
    function writeEntry(string $key, string $value): void {
        $this->write($key . '=' . $value);
    }
    //Many more functions here
}
class App {
    function makePropertyFile(): void {
        $fw = new PropertyFileWriter("f1.properties");
        try {
            $fw->writeEntry("conference.abc", "10");
            $fw->writeEntry("xyz", "hello");
        } finally {
            $fw->close();
        }
    }
}
