<?php
declare (strict_types=1);
use \Ds\Map;

//Improve the code
class Order {
    /** @var string */      private $orderId; //order ID.
    /** @var Restaurant */  private $r1; //the order is placed for this restaurant.
    /** @var Customer */    private $c1; //the order is created by this customer.
    /** @var string */      private $address; //Shipping address
    /** @var Map */         private $orderItems; //order items.

    //get the total amount of this order.
    function getTotalAmt() : float {
        //total amount.
        $amt= "0.00";
        //for each order item do...
        foreach ($this->orderItems->values() as $oi)
            //add the amount of the next order item.
            $amt = bcadd($amt, (string)($oi->getAmount()));
        return (float)$amt;
    }
    //...
}
