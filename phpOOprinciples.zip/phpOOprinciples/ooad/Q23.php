<?php
declare (strict_types=1);
//Improve the code
class TokenStream {
    /** @var string[] */
    private $v; //a list of tokens parsed from br.
    /** @var int */
    private $index; //index of the current token in v.
    /** @var BufferedReader */
    private $br; //read the chars from here to parse the tokens.
    /** @var string */
    private $currentChar; //previous char read from br.

    //read the chars from the reader and parse the tokens.
    function __construct(Reader $read) {
        $this->br = new BufferedReader($read);
        $this->takeChar();
        $this->v = $this->parseFile();
        $this->index = 0;
    }
    //read the chars from br, parse the tokens and store them into an List
    function parseFile(): array {
        $v = []; //accumulate the tokens that have been parsed.
        //...
        return $v;
    }
    //...
}