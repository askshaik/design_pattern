<?php
declare (strict_types=1);
class Piece {
    /** @var string */
    public $representation;
    //...
}
class Location {
    /** @var Piece */
    public $current;
    //...
}
class Board {
    //...
    function boardRepresentation(): string {
        $buf = '';
        foreach (squares() as $location)
            $buf .= substr($location->current->representation, 0, 1);
        return $buf;
    }
}

