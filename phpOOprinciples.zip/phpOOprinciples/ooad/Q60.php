<?php
declare (strict_types=1);
use \Ds\Set;
/*
 * The goal is to classify numbers. A number is perfect, if the sum of its
 * factors equals the number e.g. 6 is perfect. The factors are 1, 2, 3. 1 + 2 +
 * 3 equals 6.
 * A number is abundant, if the sum of its factors is greater than
 * the number e.g. 12 is abundant. The factors are 1, 2, 3, 4 and 6. 1+2+3+4+6
 * is greater than 12.
 * A number is deficient, if the sum of its factors is less
 * than the number e.g. 10 is deficient. The factors are 1, 2, 5. 1+2+5 is less
 * than 10.
 */
class NumberClassifier {
    /** @var Set */    private $_factors;
    /** @var Set */    private $_number;

    public function __construct(int $number) {
        if ($number < 1)
            throw new RuntimeException("Can't classify negative numbers");
        $this->_number = $number;
        $this->_factors = new Set();
        $this->_factors->add(1);
    }
    private function isFactor(int $factor): bool {
        return intdiv($this->_number, $factor) === 0;
    }
    public function getFactors(): array {
        return $this->_factors->toArray();
    }
    private function calculateFactors(): void {
        $upper_limit = sqrt($this->_number);
        for ($i = 2; $i <= $upper_limit; $i++)
            if ($this->isFactor($i))
                $this->addFactor($i);
    }
    private function addFactor(int $factor) {
        $this->_factors->add($factor);
        $this->_factors->add(intdiv($this->_number, $factor));
    }
    private function sumOfFactors(): int {
        $this->calculateFactors();
        return $this->_factors->sum();
    }
    public function isPerfect(): bool {
        return $this->sumOfFactors() == $this->_number;
    }
    public function isAbundant(): bool {
        return $this->sumOfFactors() > $this->_number;
    }
    public function isDeficient(): bool {
        return $this->sumOfFactors() < $this->_number;
    }
    public static function isNumberPerfect(int $number): bool { //Convenience function
        return (new NumberClassifier($number))->isPerfect();
    }
}