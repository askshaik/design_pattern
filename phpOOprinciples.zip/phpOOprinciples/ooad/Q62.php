<?php
declare (strict_types=1);

// A CSV file book.csv contains lots of information in format
// ISBN,Title,Price
// 123,Java,500
// 234,C#,700
// 345,OOAD,600
//
// Our goal is to find sum all the book prices.
// Also report number of valid and invalid books.
// The procedural code is given below.

class ProceduralCode {
    static $currentBookPrice = 0;
    static function main(): void {
        $total_price = 0.0;
        $valid_records = 0;
        $invalid_records = 0;
        $s = fopen("book.csv", "r");
        fgets($s);//Skip the header line
        while (($line = fgets($s)) !== false) {
            self::validatePrice($line);
            if (self::$currentBookPrice > 0)
                $valid_records++;
            else
                $invalid_records++;
            $total_price += self::$currentBookPrice;
        }
        fclose($s);
        printf("Total price of all Books %.2f\n. Total Valid records - %d.    Total Invalid records - %d\n",
            $total_price, $valid_records, $invalid_records);
    }
    private static function validatePrice(string $line): void {
        self::$currentBookPrice = 0;
        if ($line == null || $line == '') return;
        $items = explode(',', $line);
        if (count($items) != 3) return;
        $price = (int)trim($items[2]);
        if (preg_match_all('/\d+/', $price) !== 1) return;
        self::$currentBookPrice = (float)$price;
    }
}

