<?php
declare (strict_types=1);

//Remove the problem in code below without using Collections
class Node {
    /** @var Node */    private $nextNode;
    function getNextNode(): Node {
        return $this->nextNode;
    }
    function setNextNode(Node $nextNode): void {
        $this->nextNode = $nextNode;
    }
    //...
}
class LinkList {
    /** @var Node */    private $firstNode;
    function addNode(Node $newNode): void {
        //...
    }
    function getFirstNode(): Node {
        return $this->firstNode;
    }
    //...
}
class Employee extends Node {
    /** @var string */    private $employeeId;
    /** @var string */    private $name;
    //...
}
class EmployeeList extends LinkList {
    function addEmployee(Employee $employee): void {
        $this->addNode($employee);
    }
    function getFirstEmployee() {       //Type hint to return Employee here gives error
        return $this->getFirstNode();   //because return variable is of type Node.
    }
    //...
}
