<?php
declare (strict_types=1);

/* Point out the problem in the code below. Further suppose that
 * you need to reuse the heat sensor code in another application.
 * What should you do?
 */
class Cooker {
    /** @var HeatSensor */ private $heatSensor;
    /** @var Speaker */    private $speaker;
    function alarm(): void {
        $this->speaker->setFrequency(Speaker::HIGH_FREQUENCY);
        $this->speaker->turnOn();
    }
    //...
}
class HeatSensor {
    /** @var Cooker */
    private $cooker;
    function __construct(Cooker $cooker) {
        $this->cooker = $cooker;
    }
    function checkOverHeated(): void {
        if ($this->isOverHeated()) {
            $this->cooker->alarm();
        }
    }
    function isOverHeated(): bool {
        //...
    }
    //...
}