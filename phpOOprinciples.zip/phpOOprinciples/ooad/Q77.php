<?php
declare (strict_types=1);

abstract class Employee {
    /** @var string */ private $name;
    /** @var string */ private $address;
    /** @var int */    private $id;
    /** @var int */    private $mobile;
    //Assume public constructor, getters,setters, toString and other common functions.
    abstract function calculateHolidaysPermitted(int $month): int;
}

class PermanentEmployee extends Employee {
    function calculateHolidaysPermitted(int $month): int {
        return ($month == 12) ? 4 : 3;
    }
}

class TemporaryEmployee extends Employee {
    function calculateHolidaysPermitted(int $month): int {
        return 2;
    }
}
//Replace simple hierarchy with Higher-order functions
