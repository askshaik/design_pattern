<?php
declare (strict_types=1);
//Improve the code
class InchToPointConvertor {
    //convert the quantity in inches to points.
    static function parseInch(float $inch): float {
        return $inch * 72; //one inch contains 72 points.
    }
}
