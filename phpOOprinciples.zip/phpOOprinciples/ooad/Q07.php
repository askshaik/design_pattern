<?php
declare (strict_types=1);
//improve code
class Account {
    //...
}
class Restaurant extends Account {
    //the string "Rest" is concated with the restaurant ID to form the key.
    const RestaurantIDText = 'Rest';
    /** @var string */
    private $website;
    /** @var string */
    private $addr_cn; //address in Chinese.
    /** @var string */
    private $addr_en; //address in English.

    //the restaurant would like to update its fax # with this. After it is
    //confirmed, it will be stored in Account. Before that, it is stored here.
    /** @var string */
    private $numb_newfax;
    private $has_NewFax = false;

    //a list of holidays.
    /** @var DateTime[] */
    private $holiday;

    //id of the category this restaurant belongs to.
    /** @var string */
    private $catId;

    //a list of business session. Each business session is an array
    //of two times. The first time is the start time. The second time
    //is the end time. The restaurant is open for business in each
    //session.
    /** @var array */
    private $bsHour; //Business hour
    ///...
    //y: year.
    //m: month.
    //d: date.
    function addHoliday(int $y, int $m, int $d): void {
        if ($y < 1900) $y += 1900;
        $a_holiday = new DateTime("$y-$m-$d 0:0:0", new DateTimeZone('UTC'));
        $this->holiday[] = $a_holiday;
    }

    function addBsHour(int $fromHr, int $fromMin, int $toHr, int $toMin): bool {
        $f_min = $fromHr * 60 + $fromMin; //start time in minutes.
        $t_min = $toHr * 60 + $toMin; //end time in minutes.
        //make sure both times are valid and the start time is earlier than the end time.
        if ($f_min >= 0 && $f_min <= 1440 && $t_min >= 0 && $t_min <= 1440 && $f_min < $t_min) {
            $bs = [
                new DateTime("1900-1-1 {$fromHr}:{$fromMin}:0", new DateTimeZone('UTC')),
                new DateTime("1900-1-1 {$toHr}:{$toMin}:0", new DateTimeZone('UTC')),
            ];
            $this->bsHour[] = $bs;
            return true;
        } else {
            return false;
        }
    }
}
