<?php
declare (strict_types=1);

class Account {
    const SAVING = 0;
    const CHEQUE = 1;
    const FIXED = 2;
    /** @var int */
    private $accountType;
    /** @var float */
    private $balance;

    function __construct(int $accountType) {
        $this->accountType = $accountType;
    }

    function calcInterest(): float {
        switch ($this->accountType) {
        case self::SAVING:
            return $this->balance * $this->getInterestRate();
        case self::CHEQUE:
            return 0;
        case self::FIXED:
            return $this->balance * ($this->getInterestRate() + 0.02);
        }
    }

    // other functions like getInterestRate.
}
