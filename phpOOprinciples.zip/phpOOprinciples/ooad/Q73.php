<?php
declare (strict_types=1);

/* Suppose that in general a teacher can teach many students. However,
 * a graduate student can be taught by a graduate teacher only.
 * Point out and remove the problem in the code:
 */

class Student {
    /** @var string */
    public $studentId;
    //...
}
class Teacher {
    /** @var string */    public $teacherId;
    /** @var Student[] */ public $studentsTaught = [];
    //...
    function getId(): string {
        return $this->teacherId;
    }
    function addStudent(Student $student): void {
        $this->studentsTaught[] = $student;
    }
}
class GraduateStudent extends Student {
    //...
}
class GraduateTeacher extends Teacher {
    //...
}
