<?php
use \Ds\Map;

//Point out and remove the problem in code below.
class CourseCatalog extends Map {
    function addCourse(Course $c): void {
        $this->put($c->getTitle(), $c);
    }
    function findCourse(string $title): Course {
        return $this->get($title);
    }
    function countCourses(): int {
        return $this->count();
    }
    //...
}
