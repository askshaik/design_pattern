<?php
declare (strict_types=1);
//Improve the code
class Account {
    //...
    //check if the password is complex enough, i.e.,
    //contains letter and digit/symbol.
    function isComplexPassword(string $password): bool {
        //found a digit or symbol?
        $dg_sym_found = false;
        //found a letter?
        $letter_found = false;
        foreach (str_split($password) as $c) {
            if (ctype_alpha($c))
                $letter_found = true;
            else
                $dg_sym_found = true;
        }
        return $letter_found && $dg_sym_found;
    }
}