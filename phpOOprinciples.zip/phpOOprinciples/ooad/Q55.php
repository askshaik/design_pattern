<?php
declare (strict_types=1);

class Form1 extends JDialog {
    /** @var JComboBox */
    private $comboBoxReportType;
    function __construct() {
        $this->comboBoxReportType = new JComboBox();
        $this->comboBoxReportType->addItem("r1");
        $this->comboBoxReportType->addItem("r2");
//...
        $this->comboBoxReportType->addItem("r31c");
    }
    private function processReport1(): void {
        //print some fancy report...
    }
    private function processReport2(): void {
        //print another totally different fancy report...
    }
//...
    private function processReport31c(): void {
        //print yet another totally different fancy report...
    }
    public function printReport(string $repNo) {
        if ($repNo === 'r1')
            $this->processReport1();
        elseif ($repNo === 'r2')
            $this->processReport2();
        //...
        elseif ($repNo == 'r31c')
            $this->processReport31c();
    }
    function onPrintClick(): void {
        $this->printReport($this->comboBoxReportType->getSelectedItem());
    }
}
