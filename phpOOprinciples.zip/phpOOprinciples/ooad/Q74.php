<?php
declare (strict_types=1);

//remove the problem in code below
class Button {
    /** @var Font */    private $labelFont;
    /** @var string */  private $labelText;
    //...
    function addActionListener(ActionListener $listener): void {
        //...
    }
    function paint(Graphics $graphics): void {
        //draw the label text on the graphics using the label's font.
    }
}
class BitmapButton extends Button {
    /** @var Bitmap */    private $bitmap;

    function paint(Graphics $graphics): void {
        //draw the bitmap on the graphics.
    }
}