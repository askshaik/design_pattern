<?php
declare (strict_types=1);

/* Point out the problem in the code below. Further suppose that you
 * need to reuse the file copier in a text mode file copying application
 * that will display the progress in its text console as an integer.
 * What should you do?
 */
class MainApp extends JFrame {
    /** @var ProgressBar */
    private $progressBar;
    function main(): void {
        $file_copier = new FileCopier($this);
        $file_copier->copyFile('f1.doc"', 'f2.doc');
    }
    function updateProgressBar(int $noBytesCopied, int $sizeOfSource): void {
        $this->progressBar->setPercentage($noBytesCopied * 100 / $sizeOfSource);
    }
    //...
}
class FileCopier {
    /** @var MainApp */
    private $app;
    function __construct(MainApp $app) {
        $this->app = $app;
    }
    function copyFile(string $source, string $target): void {
        $size_of_source = filesize($source);
        //open files
        for ($i = 0; $i < $size_of_source;) {
            $n = 512;
            //read n (<= 512) bytes from source.
            //write n bytes to target.
            $i += $n;
            $this->app->updateProgressBar($i, $size_of_source);
        }
        //close files
    }
    //...
}

