<?php
declare (strict_types=1);

/* This application is about restaurants. Initially we created a
 * Restaurant class to represent a restaurant account and
 * includes information such as its
 *      name, access password, tel and fax number, address.
 * The class had string variables like:
 * class Restaurant { public $name, $password, $telNo, $faxNo, $address;}
 *
 * Later, the following requirements are added in sequence:
 * 1. After initial registration, the restaurant account is assigned an
 *    activation code by the system. Only after the user enters the
 *    activation code, the account will become activated.
 *    Until then, the account is inactive and login is not allowed.
 * 2. If the user would like to change the fax number of the account,
 *    the new fax number will not take effect immediately
 *    (the existing fax number will remain in effect). Instead,
 *    the account is assigned an activation code by the system.
 *    Only after the user enters the activation code, the new fax number
 *    will take effect.
 * 3. A restaurant can be marked as in a certain category
 *    (e.g., Chinese restaurant, Portuguese restaurant and etc.).
 *    A category is identified by a category ID.
 * 4. The user can input the holidays for the restaurant.
 * 5. The user can input the business hours for the restaurant.
 *
 * After implementing all these five requirements, the class has grown
 * significantly and become quite complicated as shown below. Our task
 * now is to implement the five requirements above in separate classes,
 * leaving the original simple Restaurant class unchanged.
 */
class Restaurant {
    /** @var string */    public $name;
    /** @var string */    public $password;
    /** @var string */    public $telNo;
    /** @var string */    public $faxNo;
    /** @var string */    public $address;
    /** @var string */    public $verificationCode;
    /** @var bool */      public $isActivated;
    /** @var string */    public $faxNoToBeConfirmed;
    /** @var bool */      public $isThereFaxNoToBeConfirmed = false;
    /** @var string */    public $catId;
    /** @var DateTime[] */public $holidays;
    /** @var DateTime[] */public $businessSessions;

    function activate(string $verificationCode): void {
        $this->isActivated = ($this->verificationCode === $verificationCode);
        if ($this->isActivated && $this->isThereFaxNoToBeConfirmed) {
            $this->faxNo = $this->faxNoToBeConfirmed;
            $this->isThereFaxNoToBeConfirmed = false;
        }
    }
    function setFaxNo(string $newFaxNo): void {
        $this->faxNoToBeConfirmed = $newFaxNo;
        $this->isThereFaxNoToBeConfirmed = true;
        $this->isActivated = false;
    }
    function isInCategory(string $catId): bool {
        return $this->catId === $catId;
    }
    function addHoliday(int $year, int $month, int $day): void {
        //...
    }
    function removeHoliday(int $year, int $month, int $day): void {
        //...
    }
    function addBusinessSession(int $fromHour, int $fromMin,
                                int $toHour, int $toMin): bool {
        //...
    }
    function isInBusinessHour(DateTime $time): void {
        //...
    }
    function getAllHolidays(): array {
        return $this->holidays;
    }
    function getAllBusinessSessions(): array {
        return $this->businessSessions;
    }
}
