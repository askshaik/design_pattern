<?php
declare (strict_types=1);

/* This is a conference management system. The system needs to record
 * the ID, name, telephone of each participant and the region he comes
 * from.
 * The participant ID is a unique integer assigned by the conference
 * organizer. The name must be specified. Telephone can be omitted. All the
 * participants must come from China, US or Europe.
 * We have created a database and a table to store the information of the
 * participants. The schema is: create table Participants (
 * 		id int primary key, name varchar(20) not null, telNo varchar(20),
 *		region varchar(20));
 *	We have also written the code below to let an operator add a new
 * participant. The system will check all the existing participants to find
 * the maximum ID and then adds one to it and use it as the default value
 * for the ID of this new participant. The operator may use this ID or
 * use any other value.
 * What are the problems with this code?
 */
class AddParticipantDialog extends JDialog {
    /** @var Connection */    private $dbConn;
    /** @var JTextField */    private $id;
    /** @var JTextField */    private $name;
    /** @var JTextField */    private $telNo;
    /** @var JTextField */    private $region;
    function __construct() {
        $this->setupComponents();
        //initialize dbConn
    }
    function setupComponents(): void {
        //...
    }
    function show(): void {
        $this->showDefaultValues();
        $this->setVisible(true);
    }
    function showDefaultValues(): void {
        $next_id = 0;
        $st = $this->dbConn->prepareStatement('select max(id) from participants');
        try {
            $rs = $st->executeQuery();
            try {
                $rs->next();
                $next_id = $rs->getInt(1) + 1;
            } finally {
                $rs->close();
            }
        } finally {
            $st->close();
        }
        $this->id->setText((string)$next_id);
        $this->name->setText('');
        $this->region->setText('China');
    }
    function onOK(): void {
        if ($this->name === '') {
            JOptionPane::showMessageDialog($this, "Invalid name");
            return;
        }
        if ($this->region !== 'China' && $this->region !== 'US' && $this->region !== 'Europe') {
            JOptionPane::showMessageDialog($this, 'Region is unknown');
            return;
        }
        $st = $this->dbConn->prepareStatement('insert into from participants values(?,?,?,?)');
        try {
            $st->setInt(1, (int)($this->id->getText()));
            $st->setString(2, $this->name->getText());
            $st->setString(3, $this->telNo->getText());
            $st->setString(4, $this->region->getText());
            $st->executeUpdate();
        } finally {
            $st->close();
        }
        $this->dispose();
    }
    //...
}