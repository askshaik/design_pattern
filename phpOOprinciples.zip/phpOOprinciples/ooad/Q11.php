<?php
declare (strict_types=1);
//There are two kinds of rentals i.e. Books and Movies. Improve the code
class BookRental {
    /** @var string */
    private $bookTitle;
    /** @var string */
    private $author;
    /** @var DateTime */
    private $rentDate;
    /** @var DateTime */
    private $dueDate;
    /** @var float */
    private $rentalFee;
    function isOverdue(): bool {
        $now = new DateTime();
        return $this->dueDate < $now;
    }
    function getTotalFee(): float {
        return $this->isOverdue() ? 1.2 * $this->rentalFee : $this->rentalFee;
    }
    //...
}
class MovieRental {
    /** @var string */
    private $movieTitle;
    /** @var int */
    private $classification;
    /** @var DateTime */
    private $rentDate;
    /** @var DateTime */
    private $dueDate;
    /** @var float */
    private $rentalFee;
    function isOverdue(): bool {
        $now = new DateTime();
        return $this->dueDate < $now;
    }
    function getTotalFee(): float {
        return $this->isOverdue() ? 1.3 * $this->rentalFee : $this->rentalFee;
    }
}
