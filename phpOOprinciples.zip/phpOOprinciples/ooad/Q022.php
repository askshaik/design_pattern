<?php
declare (strict_types=1);
//Improve code
class Organization {
    /** @var string */ private $id;
    /** @var string */ private $eName; //English name
    /** @var string */ private $cName; //Chinese name
    /** @var string */ private $telCountryCode;
    /** @var string */ private $telAreaCode;
    /** @var string */ private $telLocalNumber;
    /** @var string */ private $faxCountryCode;
    /** @var string */ private $faxAreaCode;
    /** @var string */ private $faxLocalNumber;
    /** @var string */ private $contactPersonEFirstName; //First name and last name in English
    /** @var string */ private $contactPersonELastName;
    /** @var string */ private $contactPersonCFirstName; //First name and last name in Chinese
    /** @var string */ private $contactPersonCLastName;
    /** @var string */ private $contactPersonTelCountryCode;
    /** @var string */ private $contactPersonTelAreaCode;
    /** @var string */ private $contactPersonTelNumber;
    /** @var string */ private $contactPersonFaxCountryCode;
    /** @var string */ private $contactPersonFaxAreaCode;
    /** @var string */ private $contactPersonFaxLocalNumber;
    /** @var string */ private $contactPersonMobileCountryCode;
    /** @var string */ private $contactPersonMobileAreaCode;
    /** @var string */ private $contactPersonMobileLocalNumber;
    //...
}

