<?php
declare (strict_types=1);
//Improve the code
class UIDialogCustomerMain extends JDialog {
    /** @var JButton */
    private $btnOrderDel;
    /** @var JButton */
    private $btnCustChangePassword;
    function bindEvents(): void {
        //...
        $this->btnOrderDel->addActionListener(new class($this) extends ActionListener {
            /** @var UIDialogCustomerMain */
            private $ui;
            function __construct(UIDialogCustomerMain $ui) { $this->ui = $ui; }
            function actionPerformed(ActionEvent $e): void {
                $d = new UIDialogCustomerDeleteOrder($this->ui, "Del Order", true);
                $d->pack();
                $d->setLocation(400, 200);
                $d->setVisible(true);
            }
        });
        $this->btnCustChangePassword->addActionListener(new class($this) extends ActionListener {
            /** @var UIDialogCustomerMain */
            private $ui;
            function __construct(UIDialogCustomerMain $ui) { $this->ui = $ui; }
            function actionPerformed(ActionEvent $e): void {
                $d = new UIChangeAccountPW($this->ui, "chg pw", true);
                $d->pack();
                $d->setLocation(400, 200);
                $d->setVisible(true);
            }
        });
    }
    //...
}

class UIDialogRestaurantMain extends JDialog {
    /** @var JButton */
    private $btnChangePassword;
    function bindEvents(): void {
        //...
        $this->btnChangePassword->addActionListener(new class($this) extends ActionListener {
            /** @var UIDialogRestaurantMain */
            private $ui;
            function __construct(UIDialogRestaurantMain $ui) { $this->ui = $ui; }
            function actionPerformed(ActionEvent $e): void {
                $d = new UIChangeAccountPW($this->ui, "chg pw", true);
                $d->pack();
                $d->setLocation(400, 200);
                $d->setVisible(true);
            }
        });
    }
    //...
}
