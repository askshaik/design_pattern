<?php
declare (strict_types=1);
//Improve code.
//Participant is a value object i.e. It is immutable.
use PHPUnit\Framework\TestCase;

class ParticipantsInDBTest extends TestCase {
    /** @var ParticipantsInDB */
    private $p;
    protected function setUp(): void {
        $this->p = ParticipantsInDB::getInstance();
    }
    protected function tearDown(): void {
        ParticipantsInDB::freeInstance();
    }
    function testAdd(): void {
        $part1 = new Participant("ABC001", "Kent", "Tong", true, "Manager");
        $this->p->deleteAllParticipants();
        $this->p->addParticipant($part1);
        $this->assertEquals(1, $this->p->getCount());
    }
    function testAdd2(): void {
        $part1 = new Participant('ABC001', 'Kent', 'Tong', true, 'Manager');
        $part2 = new Participant('ABC003', 'Paul', 'Chan', true, 'Manager');
        $this->p->deleteAllParticipants();
        $this->p->addParticipant($part1);
        $this->p->addParticipant($part2);
        $this->assertEquals(2, $this->p->getCount());
    }
    function testEnum(): void {
        $part1 = new Participant('ABC001', 'Kent', 'Tong', true, 'Manager');
        $part2 = new Participant('ABC003', 'Paul', 'Chan', true, 'Manager');
        $this->p->deleteAllParticipants();
        $this->p->addParticipant($part2);
        $this->p->addParticipant($part1);
        $penum = new ParticipantEnumeratorById();
        $this->assertTrue($penum->next());
        $this->assertTrue($penum->get() === $part1);
        $this->assertTrue($penum->next());
        $this->assertTrue($penum->get() === $part2);
        $this->assertFalse($penum->next());
        $penum->close();
    }
}
