<?php
declare (strict_types=1);
class Account {
    const LEVEL_USER = 1;
    const LEVEL_ADMIN = 2;
    /** @var int */
    private $accountLevel;
    /** @var DateTime */
    private $expiredDate; // for user account only
    /** @var bool */
    private $hasLogin; // for admin account only
    public function getLevel(): int {
        return $this->accountLevel;
    }
    public function getExpiredDate(): DateTime {
        return $this->expiredDate;
    }
    public function hasLoggedIn(): bool {
        return $this->hasLogin;
    }
    //...
}
class ERPApp {
    function checkLoginIssue(Account $account): bool {
        if ($account->getLevel() == Account::LEVEL_USER) {
            // Check the account expired date
            $now = new DateTime();
            if ($account->getExpiredDate() < $now)
                return false;
            return true;
        } elseif ($account->getLevel() == Account::LEVEL_ADMIN) {
            // No expired date for admin account
            // Check multilogin
            if ($account->hasLoggedIn())
                return false;
            return true;
        }
        return false;
    }
}
