<?php
declare (strict_types=1);

/*
The problem domain we would like to solve is as follows:

   1. We need to represent the concept of an Investor in our application.
   2. Our Investor should know its marginal tax rate and tax liability
   		calculated from the investor’s income.
   3. The income tax laws for the following countries should be incorporated:
          * USA.
          * Australia.
          * New Zealand.
   4. If none of these countries are specified, the object should have
   non-exceptional behavior.  What does non-exceptional behavior mean?
   The application should provide intelligent do nothing behaviors if none of
   the countries are specified, by hiding the details from its collaborators.
 */
//Below is a solution with procedural orientation

class Investor {
    /** @var float */    private $income;
    /** @var string */   private $m_currentCultureName;

    public function __construct(float $income, string $culture) {
        $this->income = $income;
        $this->m_currentCultureName = $culture;
    }
    public function getIncome(): float {
        return $this->income;
    }
    public function setIncome(float $income): void {
        $this->income = $income;
    }
    public function getCurrentCultureName(): string {
        return $this->m_currentCultureName;
    }
    public function setCurrentCultureName(string $culture): void {
        $this->m_currentCultureName = $culture;
    }
    public function getTaxLiability(): float {
        $tax_liability = 0.0;
        $inv_income = $this->income;
        if ($this->m_currentCultureName === 'en-NZ') {
            // Calculate the Tax Liability for the Investor according
            // to the tax laws of the New Zealand
            if ($inv_income > 19500.99)
                $tax_liability += 19500.99 * 0.195;
            if ($inv_income <= 19500.99)
                $tax_liability += $inv_income * 0.195;
            if ($inv_income > 60000.99)
                $tax_liability += (60000.99 - 19501.00) * 0.33;
            if ($inv_income >= 19501.00 && $inv_income <= 60000.99)
                $tax_liability += ($inv_income - 19501.00) * 0.33;
            if ($inv_income > 60000.99)
                $tax_liability += ($inv_income - 60000.99) * 0.39;
        } elseif ($this->m_currentCultureName === 'en-AU') {
            // Calculate the Tax Liability for the Investor according
            // to the tax laws of the Australia
            if ($inv_income >= 6001.00 && $inv_income <= 25000.99)
                $tax_liability += ($inv_income - 6000.99) * 0.15;
            if ($inv_income > 25000.99)
                $tax_liability += (25000.99 - 6001.00) * 0.15;
            if ($inv_income > 75000.99)
                $tax_liability += (75000.99 - 25001.00) * 0.30;
            if ($inv_income >= 25001.00 && $inv_income <= 75000.99)
                $tax_liability += ($inv_income - 25001.00) * 0.30;
            if ($inv_income > 150000.99)
                $tax_liability += (150000.99 - 75001.00) * 0.40;
            if ($inv_income >= 75001.00 && $inv_income <= 150000.99)
                $tax_liability += ($inv_income - 75001.00) * 0.40;
            if ($inv_income > 150000.99)
                $tax_liability += ($inv_income - 150000.99) * 0.45;
        } elseif ($this->m_currentCultureName === 'en-US') {
            // Calculate the Tax Liability for the Investor according
            // to the tax laws of the USA
            if ($inv_income > 7550.99)
                $tax_liability += 7550.99 * 0.10;
            if ($inv_income >= 0.0 && $inv_income <= 7550.99)
                $tax_liability += $inv_income * 0.10;
            if ($inv_income > 30650.99)
                $tax_liability += (30650.99 - 7551.00) * 0.15;
            if ($inv_income >= 7551.00 && $inv_income <= 30650.99)
                $tax_liability += ($inv_income - 7551.00) * 0.15;
            if ($inv_income > 74200.99)
                $tax_liability += (74200.99 - 30651.00) * 0.25;
            if ($inv_income >= 30651.00 && $inv_income <= 74200.99)
                $tax_liability += ($inv_income - 30651.00) * 0.25;
            if ($inv_income > 154800.99)
                $tax_liability += (154800.99 - 74201.00) * 0.28;
            if ($inv_income >= 74201.00 && $inv_income <= 154800.99)
                $tax_liability += ($inv_income - 74201.00) * 0.28;
            if ($inv_income > 336550.99)
                $tax_liability += (336550.99 - 154801.00) * 0.33;
            if ($inv_income >= 154801.00 && $inv_income <= 336550.99)
                $tax_liability += ($inv_income - 154801.00) * 0.33;
            if ($inv_income > 336551.00)
                $tax_liability += ($inv_income - 336551.00) * 0.35;
        } else
            $tax_liability = 0.0;
		return $tax_liability;
	}

    public function getTaxRate(): float {
        $tax_rate = 0.0;
        $inv_income = $this->income;
        if ($this->m_currentCultureName === 'en-NZ') {
            // Calculate the tax rate for New Zealand
            if ($inv_income >= 0.0 && $inv_income <= 19500.99)
                $tax_rate = 0.195;
            elseif ($inv_income >= 19501.00 && $inv_income <= 60000.99)
                $tax_rate = 0.33;
            else
                $tax_rate = 0.39;
        } elseif ($this->m_currentCultureName === 'en-AU') {
            // Calculate the tax rate for Australia
            if ($inv_income >= 0.0 && $inv_income <= 6000.99)
                $tax_rate = 0.0;
            elseif ($inv_income >= 6001.00 && $inv_income <= 25000.99)
                $tax_rate = 0.15;
            elseif ($inv_income >= 25001.00 && $inv_income <= 75000.99)
                $tax_rate = 0.30;
            elseif ($inv_income >= 75001.00 && $inv_income <= 150000.99)
                $tax_rate = 0.40;
            else
                $tax_rate = 0.45;
        } elseif ($this->m_currentCultureName === 'en-US') {
            // Calculate the tax rate for the United States of America
            if ($inv_income >= 0.0 && $inv_income <= 7550.99)
                $tax_rate = 0.10;
            elseif ($inv_income >= 7551.00 && $inv_income <= 30650.99)
                $tax_rate = 0.15;
            elseif ($inv_income >= 30651.00 && $inv_income <= 74200.99)
                $tax_rate = 0.25;
            elseif ($inv_income >= 74201.00 && $inv_income <= 154800.99)
                $tax_rate = 0.28;
            elseif ($inv_income >= 154801.00 && $inv_income <= 336550.99)
                $tax_rate = 0.33;
            else
                $tax_rate = 0.35;
        } else
            $tax_rate = 0.0;
        return $tax_rate;
    }
}
/*
 * The above code has the following problems
   1. Copy/Paste Errors
   2. Duplicate Code
   3. Big Methods
   4. Comments
   5. Switch / if..else Statement

   Correct the above problem by using OO design principles.
 */

