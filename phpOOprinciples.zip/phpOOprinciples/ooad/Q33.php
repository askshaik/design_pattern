<?php
declare (strict_types=1);
//Improve the code
class SurveyData {
    /** @var string */
    private $path; //save the data to this file.
    /** @var bool */
    private $hidden; //should the file be hidden?

    //set the path to save the data according to the type of data (t).
    function setSavePath(int $t): void {
        if ($t == 0) { //raw data.
            $this->path = 'c:/application/data/raw.dat';
            $this->hidden = true;
        } elseif ($t == 1) { //cleaned up data.
            $this->path = 'c:/application/data/cleanedUp.dat';
            $this->hidden = true;
        } elseif ($t == 2) { //processed data.
            $this->path = 'c:/application/data/processed.dat';
            $this->hidden = true;
        } elseif ($t == 3) { //data ready for publication.
            $this->path = 'c:/application/data/publication.dat';
            $this->hidden = false;
        }
    }
    //....
}