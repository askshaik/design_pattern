<?php
declare (strict_types=1);

/* This application is about students. Originally we had a
 * simple Student class:
 * class Student { String studentId; String name; Date dateOfBirth; }
 *
 * Later, in order to record what courses the student has
 * enrolled in, on which dates he enrolled and how he paid for them,
 * we modified the code as shown below.
 * Your task is to implement this requirement without modifying
 * the Student class.
 */

class StudentManagementSystem {
    /** @var Student[] */
    public $students = [];
}
class Student {
    /** @var string */    public $studentId;
    /** @var string */    public $name;
    /** @var DateTime */  public $dateOfBirth;
    /** @var string[] */  public $courseCodes; //the student has enrolled in these courses.
    /** @var DateTime[] */public $enrollDates; //for each enrolled course, the date he enrolled.
    /** @var Payment[] */ public $payments; //for each enrolled course, how he paid.

    function enroll(string $courseCode, DateTime $enrollDate, Payment $payment): void {
        //add courseCode to courseCodes
        //add enrollDate to enrollDates
        //add payment to Payments
    }
    function unenroll(string $courseCode): void {
        //...
    }
}

