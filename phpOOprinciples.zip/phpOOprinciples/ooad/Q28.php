<?php
declare (strict_types=1);
use \Ds\Vector;
class Q28Artists {
    /** @var Vector */
    private $artists;
    function __construct(array $artists) {
        $this->artists = new Vector($artists);
    }
    function getArtist(int $index): ?Artist {
        if (($index < 0) || ($index >= $this->artists->count()))
            return null;
        return $this->artists->get($index);
    }
    function getArtistName(int $index): ?string {
        try {
            return $this->getArtist($index)->getName();
        } catch (Error $e) {
            return null;
        }
    }
    //Improve the design of this class
    //...
}
class Artist {
    private $name;
    function __construct(string $name) {
        assert($name !== null);
        $this->name = $name;
    }
    function getName(): string {
        return $this->name;
    }
    //...
}
