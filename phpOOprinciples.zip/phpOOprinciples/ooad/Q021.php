<?php
declare (strict_types=1);
class BookRental {
    private $id = '';
    private $customerName = '';
    //...
}
class BookRentals {
    private $rentals = [];
    function getCustomerName(string $rentalId): string {
        foreach($this->rentals as $rental)
            if ($rental->getId() === $rentalId)
                return $rental->getCustomerName();
        throw new RentalNotFoundException();
    }
    function deleteRental(string $rentalId): void {
        for ($i=0; $i < count($this->rentals); ++$i) {
            $rental = $this->rentals[$i];
            if ($rental->getId() === $rentalId) {
                unset($this->rentals[$i]);
                return;
            }
        }
        throw new RentalNotFoundException();
    }
    //...
}
class RentalNotFoundException extends Exception {
    //...
}

