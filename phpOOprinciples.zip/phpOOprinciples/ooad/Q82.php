<?php
declare (strict_types=1);

/* Point out the problem in the code below. Further suppose that you
 * need to reuse the fax machine code in another application. What should
 * you do?
 */
class MainApp {
    /** @var string */
    private $faxNo;
    function main(): void {
        $fax_machine = new FaxMachine($this);
        $fax_machine->sendFax('783675', 'hello');
    }
    public function getFaxNo(): string {
        return $this->faxNo;
    }
    //...
}
class FaxMachine {
    /** @var MainApp */    private $app;
    function __construct(MainApp $app) {
        $this->app = $app;
    }
    function sendFax(string $toFaxNo, string $msg): void {
        $hardware = new FaxMachineHardware();
        $hardware->setStationId($this->app->getFaxNo());
        $hardware->setRecipientFaxNo($toFaxNo);
        $hardware->start();
        $more_page_is_needed = true;
        try {
            do {
                $graphics = $hardware->newPage();
                //draw the message msg into the graphics.
            } while ($more_page_is_needed);
        } finally {
            $hardware->done();
        }
    }
}

