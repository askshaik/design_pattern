<?php
declare (strict_types=1);
use \Ds\Vector;

/* This application is concerned with training courses.
 * A course has a title, a fee and a list of sessions. However,
 * sometimes a course can consist of several modules, each of which is a
 * course. For example, there may be a compound course "Fast track to
 * becoming a web developer" which consists of three modules: a course
 * named "HTML", a course named "FrontPage" and a course named "Flash".
 * It is possible for a module to consist of some other modules.
 * If a course consists of modules, its fee and schedule are totally
 * determined by that of its modules and thus it will not maintain
 * its list of sessions.
 * Point out and remove the code smells in the code */
class Session {
    /** @var DateTime */
    private $date;
    /** @var int */
    private $startHour;
    /** @var int */
    private $endHour;
    function getDuration(): int {
        return $this->endHour - $this->startHour;
    }
    //...
}
class Course {
    /** @var string */
    private $courseTitle;
    /** @var Vector */
    private $sessions = null;
    /** @var float */
    private $fee = 0;
    /** @var Vector */
    private $modules = null;
    function __construct(string $courseTitle, array $sessionsOrModules, float $fee = 0) {
        $this->courseTitle = $courseTitle;
        if ($fee !== 0) {
            $this->fee = $fee;
            $this->sessions = new Vector($sessionsOrModules);
        } else {
            $this->modules = new Vector($sessionsOrModules);
        }
    }
    function getTitle(): string {
        return $this->courseTitle;
    }
    function getDuration(): float {
        $duration = 0;
        if ($this->modules === null)
            foreach ($this->sessions as $s)
                $duration += $s->getDuration();
        else
            foreach ($this->modules as $m)
                $duration += $m->getDuration();
        return $duration;
    }
    function getFee(): float {
        if ($this->modules === null)
            return $this->fee;
        else {
            $total_fee = 0.0;
            foreach ($this->modules as $m)
                $total_fee += $m->getFee();
            return $total_fee;
        }
    }
    function setFee(int $fee): void {
        if ($this->modules === null)
            $this->fee = $fee;
        else
            throw new Exception("Please set the fee of each module one by one");
    }
}
