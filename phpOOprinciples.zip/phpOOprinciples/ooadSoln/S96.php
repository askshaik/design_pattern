<?php
declare (strict_types=1);
class Order {
    /**@var Customer */ public $customer;
    /**@var OrderItem[] */ public $orderItem = [];
    //...
}
class OrderItem {
    /**@var string*/ public $foodId;
    /**@var int*/ public $quantity;
    //...
}
class Customer {
    //...
}
interface Orders {
    function getOrder(string $orderId) : Order;
    //...
}
interface Customers {
    function getCustomer(string $customerId) : Customer;
    //...
}
class OrdersInDB implements Orders {
    private $dbConn;
    function getOrder(string $orderId) : Order {
        $order = null;
        $st = $this->dbConn->prepareStatement('select * from Orders where orderId=?');
        try {
            $st->setString(1, $orderId);
            $rs = $st->executeQuery();
            try {
                if (!$rs->next())
                    throw new RuntimeException('Order not found.');
                $customerId = $rs->getString('customerId');
                $customers = new CustomersInDB();
                $customer = $customers->getCustomer($customerId);
                $order = new Order();
                //Add $customer details to $order
                $this->getOrderItemsFromDB($order);
            } finally {
                $rs->close();
            }
        } finally {
            $st->close();
        }
        return $order;
    }
    function getOrderItemsFromDB(Order $order) : void {
        $st = $this->dbConn->prepareStatement('select * from OrderItems where orderId=?');
        try {
            $st->setString(1, $order->getId());
            $rs = $st->executeQuery();
            try {
                while ($rs->next()) {
                    $food_id = $rs->getString(3);
                    $quantity = $rs->getInt(4);
                    //..Add these items to orderItem part of $order.
                }
            } finally {
                $rs->close();
            }
        } finally {
            $st->close();
        }
    }
    //...
}
class CustomersInDB implements Customers {
    private $dbConn;
    function getCustomer(string $customerId) : Customer {
        $customer = null;
        $st = $this->dbConn->prepareStatement('select * from Customers where customerId=?');
        try {
            $st->setString(1, $customerId);
            $rs = $st->executeQuery();
            try {
                if (!$rs->next())
                    throw new RuntimeException("Customer not found.");
                $name = $rs->getString('name');
                //Create customer object in $customer, from details in $rs
            } finally {
                $rs->close();
            }
        } finally {
            $st->close();
        }
        return $customer;
    }
}
class ShowOrderServlet extends HttpServlet {
    function doGet(HttpServletRequest $request, HttpServletResponse $response): void {
        $response->setContentType("text/html");
        $out = $response->getWriter();
        $orders = $this->getServletContext()->getAttribute('Orders');
        $out->println('<HTML><TITLE>Order details</TITLE><BODY>');
        $orderId = $request->getParameter('orderId');
        try {
            $order = $orders->getOrder($orderId);
        } catch (Exception $ex) {
            $out->println('Error: ' . $ex->getMessage());
            return;
        }
        $out->println('Customer: ' . $order->getCustomer()->getName());
        $this->orderItems($out, $order);
        $out->println('</BODY></HTML>');
    }
    function showOrderItems(PrintWriter $out, Order $order) {
        $out->println('<TABLE>');
        foreach($order->getNoOrderItems() as $oi) {
            $out->println('<TR>');
            $out->println('<TD>');
            $out->println($oi->getFoodId());
            $out->println('</TD>');
            $out->println('<TD>');
            $out->println((string)$oi->getQuanity());
            $out->println('</TD>');
            $out->println('</TD>');
            $out->println('</TR>');
        }
        $out->println('</TABLE>');
    }
}
