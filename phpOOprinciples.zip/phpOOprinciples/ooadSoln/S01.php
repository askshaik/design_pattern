<?php
declare (strict_types=1);
class StringComparer {
    static function isSameString(?string $s1, ?string $s2) : bool {
        if ($s1 === null) return false;
        return $s1 === $s2;
    }
}
class Order {
    //...
}

class Mail {
    //...
}
