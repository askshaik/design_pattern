<?php
declare (strict_types=1);
interface FontChangeListener {
    function onFontChanged(Font $newFont) : void;
}
class WordProcessorMainFrame extends JFrame implements FontChangeListener {
    function onChangeFont(): void {
        $chooseFontDialog = new ChooseFontDialog($this);
        if ($chooseFontDialog->showOnScreen()) {
            $newFont = $chooseFontDialog->getSelectedFont();
            //show the contents using this new font.
        } else {
            //show the contents using the existing font.
        }
    }
    function previewWithFont(Font $font): void {
        //show the contents using this preview font.
    }
    function onFontChanged(Font $newFont) : void {
        $this->previewWithFont($newFont);
    }

    //...
}
class ChooseFontDialog extends JDialog {
    /** @var FontChangeListener */  private $fontChangeListener;
    /** @var Font */                private $selectedFont;
    function __construct(FontChangeListener $fontChangeListener) {
        $this->fontChangeListener = $fontChangeListener;
    }
    function onSelectedFontChange(): void {
        $this->selectedFont = $this->getSelectedFontFromUI();
        $this->fontChangeListener->onFontChanged($this->selectedFont);
    }
    function getSelectedFont(): Font {
        return $this->selectedFont;
    }
    function getSelectedFontFromUI(): Font {
        //...
    }
    function showOnScreen(): bool {
        //...
    }
}
