<?php
declare (strict_types=1);
class BookRental {
    private $id = '';
    private $customerName = '';
    //...
}
class BookRentals {
    private $rentals = [];
    private function getRentalIdxById(string $rentalId) : int{
        $i=0;
        foreach($this->rentals as $rental) {
            if ($rental->getId() === $rentalId)
                return $i;
            $i++;
        }
        throw new RentalNotFoundException();
    }
    function getCustomerName(string $rentalId): string {
        $rentalIdx = $this->getRentalIdxById($rentalId);
        return $this->rentals[$rentalIdx].getCustomerName();
    }
    function deleteRental(string $rentalId): void {
        unset($this->rentals[$this->getRentalIdxById($rentalId)]);
    }
    //...
}
class RentalNotFoundException extends Exception {
    //...
}

