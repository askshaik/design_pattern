<?php
declare (strict_types=1);
/* UI was mixed with the domain logic. Extract the domain logic into a
 * class like Hangman and rename the original one as HangmanApp.
 * Make sure that HangmanApp uses Hangman but not the reverse.
 */
class Hangman { //Domain logic
    /** @var string */    private $secret = 'banana';
    /** @var string */    private $guessedChars = '';
    const MAX_NUMBER_OF_GUESSES = 7;
    function reachMaxNoGuesses() : bool {
        return $this->getNoGuessedChars() === self::MAX_NUMBER_OF_GUESSES;
    }
    function getNoGuessedChars() : int {
        return strlen($this->guessedChars);
    }
    function hasBeenGuessed(string $ch) {
        return strpos($this->guessedChars, $ch) !== false;
    }
    function getPartiallyFoundSecret() : string {
        $partially_found_secret = '';
        for ($i=0; $i < $this->secretLength(); $i++) {
            $ch = substr($this->secret, $i, 1);
            $ch_to_show = $this->hasBeenGuessed($ch)? $ch : '-';
            $partially_found_secret .= $ch_to_show;
        }
        return $partially_found_secret;
    }
    function guess(string $ch): bool {
        $n = $this->numberOfFoundChars();
        $this->guessedChars .= $ch;
        $m = $this->numberOfFoundChars();
        return $m > $n;
    }
    function isSecretFound() : bool {
        return $this->numberOfFoundChars() === $this->secretLength();
    }
    function numberOfFoundChars() : int {
        $n = 0;
        for ($i=0; $i < $this->secretLength(); $i++) {
            $ch = substr($this->secret, $i, 1);
            if (strpos($this->guessedChars, $ch) !== false)
                $n++;
        }
        return $n;
    }
    function secretLength() : int {
        return strlen($this->secret);
    }
}
class HangmanApp { //User interface
    function __construct() {
        $hangman = new Hangman();
        while (!$hangman->reachMaxNoGuesses()) {
            printf("Secret: %s\n", $hangman->getPartiallyFoundSecret());
            $ch = substr(readline("Guess letter: "), 0, 1);
            if ($hangman->hasBeenGuessed($ch)) {
                printf("You have guessed this char!\n");
                continue;
            }
            if ($hangman->guess($ch)) {
                printf("Success,  you have found the letter %s\n", $ch);
                printf("Letters found: %d\n", $hangman->numberOfFoundChars());
            }
            if ($hangman->isSecretFound()) {
                printf("You won!\n");
                return;
            }
        }
        printf("You lost!\n");
    }
}
new HangmanApp();