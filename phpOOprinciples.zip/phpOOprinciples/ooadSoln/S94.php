<?php
declare (strict_types=1);

class Course {
    /** @var string */    private $courseId;
    /** @var string */    private $title;
    /** @var int */       private $fee;
    /** @var Session[] */ private $sessions;
    //...
}
class Session {
    /** @var DateTime */  private $date;
    /** @var int */       private $startHour;
    /** @var int */       private $endHour;
    //...
}
interface Courses {
    function addCourse(Course $course) : void;
    function deleteCourse(String $courseId) : void;
    function updateCourse(Course $course) : void;
    function getAllCoursesById() : array;
    function getCoursesLongerThan(int $duration) : array;
}
class CoursesInDB implements Courses {
    function addCourse(Course $course) : void {
        $st =$this->dbConn->prepareStatement('insert into from Courses values(?,?,?)');
        try {
            $st->setString(1, $course->getId());
            $st->setString(2, $course->getTitle());
            $st->setInt(3, $course->getFee());
            $st->executeUpdate();
        } finally {
            $st->close();
        }
        $st = $this->dbConn->prepareStatement('insert into from Sessions values(?,?,?,?,?)');
        try {
            $i = 1;
            foreach ($course->getNoSessions() as $session) {
                $st->setString(1, $course->getId());
                $st->setInt(2, $i++);
			    $st->setDate(3, $session->getDate());
			    $st->setInt(4, $session->getStartHour());
			    $st->setInt(5, $session->getEndHour());
			    $st->executeUpdate();
            }
	    } finally {
            $st->close();
        }
    }
    //Other functions coded similarly.
    private $dbConn;
}
