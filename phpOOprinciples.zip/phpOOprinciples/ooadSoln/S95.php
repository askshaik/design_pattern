<?php
declare (strict_types=1);

class MasterMind {
    private $secret = "RGBY";
    const MAX_NO_GUESSES = 12;
    const NO_PEGS = 4;
    function makeGuess (string $guess) : GuessResult {
        $partial_result = new GuessPartialResult($this->secret, $guess);
        $partial_result->validateColors();
        $partial_result->findPegsInRightColorAndPos();
        $partial_result->findPegsInRightColorIgnorePos();
        return $partial_result->makeFinalResult();
    }
}
class GuessPartialResult {
    /**@var string*/private $secretLeft;
    /**@var string*/private $guessLeft;
    /**@var int*/   private $noPegsInRightColorAndPos = 0;
    /**@var int*/   private $noPegsInRightColorButWrongPos = 0;
    function __construct(string $initSecret, string $initGuess) {
        $this->secretLeft = $initSecret;
        $this->guessLeft = $initGuess;
    }
    function validateColors() : void {
        foreach (str_split($this->guessLeft) as $c)
            $this->assertValidColor($c);
    }

    const RED='R', YELLOW='Y', PINK='P', GREEN='G', BLUE='B', CYAN='C';
    const VALID_COLORS = [self::RED , self::YELLOW , self::PINK , self::GREEN , self::BLUE , self::CYAN];
    private function assertValidColor(string $ch) : void {
        if (!in_array($ch, self::VALID_COLORS))
            throw new RuntimeException('Invalid color');
    }

    function findPegsInRightColorAndPos() : void {
        for ($j = 0; $j < strlen($this->guessLeft); )
            if ($this->isPegInRightColorAndPos($j)) {
                $this->noPegsInRightColorAndPos++;
                $this->guessLeft = $this->deletePegAt($this->guessLeft, $j);
                $this->secretLeft = $this->deletePegAt($this->secretLeft, $j);
            }
            else
                $j++;
    }
    function findPegsInRightColorIgnorePos() : void {
        for ($j = 0; $j < strlen($this->guessLeft); ) {
            $k = $this->findFirstPegInSecretOfColor($this->guessLeft[$j]);
            if ($k !== -1) {
                $this->noPegsInRightColorButWrongPos++;
                $this->guessLeft = $this->deletePegAt($this->guessLeft, $j);
                $this->secretLeft = $this->deletePegAt($this->secretLeft, $k);
            } else
                $j++;
        }
    }
    private function isPegInRightColorAndPos(int $idx) : bool {
        return $this->guessLeft[$idx]  === $this->secretLeft[$idx];
    }
    private function findFirstPegInSecretOfColor(string $ch) : int {
        $r = strpos($this->secretLeft, $ch);
        return $r === false? -1 : $r;
    }
    private function deletePegAt(string $pegs, int $idx) : string {
        return substr($pegs, 0, $idx) . substr($pegs, $idx + 1);
    }
    function makeFinalResult() {
        return new GuessResult($this->noPegsInRightColorAndPos, $this->noPegsInRightColorButWrongPos);
    }
}
class GuessResult {
    /**@var int*/ public $noPegsInRightColorAndPos;
    /**@var int*/ public $noPegsInRightColorButWrongPos;
    function __construct(int $noPegsInRightColorAndPos, $noPegsInRightColorButWrongPos) {
        $this->noPegsInRightColorAndPos = $noPegsInRightColorAndPos;
        $this->noPegsInRightColorButWrongPos = $noPegsInRightColorButWrongPos;
    }
    function allFound() : bool {
        return $this->noPegsInRightColorAndPos === MasterMind::NO_PEGS;
    }
}
class MasterMindApp {
    function __construct() {
        $master_mind = new MasterMind();
        for ($i = 0; $i < MasterMind::MAX_NO_GUESSES; $i++) {
            $guess = readline("Guess:");
            try {
                $guess_result = $master_mind->makeGuess($guess);
                printf("%d are right in color and position\n", $guess_result->noPegsInRightColorAndPos);
                printf("%d are right in color but wrong position\n", $guess_result->noPegsInRightColorButWrongPos);
                if ($guess_result->allFound()) {
                    echo "You won!\n";
                    return;
                }
            } catch (RuntimeException $ex) {
                printf("Invalid color!\n");
                break;
            }
        }
        echo "You lost!\n";
    }
}
new MasterMindApp();
