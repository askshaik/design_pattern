<?php
declare (strict_types=1);
use \Ds\{Map, Hashable};

/* This application lets the network administrators document their
 * server configurations.
 * Originally we had a simple Server class as shown in the code:
 */
class Server implements Hashable {
    /** @var string */     public $name;
    /** @var string */     public $CPUModel;
    /** @var int */        public $RAMSizeInMB;
    /** @var int */        public $diskSizeInMB;
    /** @var InetAddress */public $ipAddress;
    function hash()
    {
        return $this->name->hash();
    }

    function equals($obj): bool
    {
        return $this->name === $obj->name;
    }

    //...
}
class Administrator {
    /** @var string */ public $adminId;
    /** @var Server[] */ public $serversAdminedByHim = [];
    //...
}
class DHCPConfig {
    /** @var InetAddress */public $startIp;
    /** @var InetAddress */public $endIp;
    //...
}
class FileServerConfig {
    /** @var array */public $userIdToQuota;
    function getQuotaForUser(string $userId) {
        //...
    }
    function setQuotaForUser(string $userId, int $quota) {
        //...
    }
}
class ServerConfigSystem {
    /** @var Server[] */    public $servers = [];
    /** @var Administrator[] */ public $admins = [];
    /** @var Map */ public $DHCPservers; //Key:Server  Value:DHPConfig
    /** @var Map */ public $Fileservers; //Key:Server  Value:FileServerConfig
    //...
}
