<?php
declare (strict_types=1);
use \Ds\Vector;

class PianoKey {
    /** @var int */ private $frequency;
    private function __construct($frequency) {
        $this->frequency = $frequency;
    }
    function playSound(): void {
        //play the $frequency.
    }
    static function getKey0() : PianoKey {
        return new PianoKey(self::FREQUENCY_FOR_KEY0);
    }
    static function getKey1() : PianoKey {
        return new PianoKey(self::FREQUENCY_FOR_KEY1);
    }
    //...
    const FREQUENCY_FOR_KEY0 = 0;
    const FREQUENCY_FOR_KEY1 = 1;
}
class Piano {
    /** @var Vector */
    private $rhythm;
    function play(): void {
        foreach ($this->rhythm as $piano_key)
            $piano_key->playSound();
    }
    //...
}

