<?php
declare (strict_types=1);
require_once 'S37.php';

abstract class PaymentUI {
    /** @var JTextField */    protected $paymentDate;
    function __construct(JTextField $paymentDate) {
        //...
    }
    function displayPaymentDate(Payment $payment) : void {
        $this->paymentDate->setText($payment->getDateAsString());

    }
    function makePaymentDate() : DateTime {
        //parse the text in $paymentDate and return Date.
    }
    abstract function tryToDisplayPayment(Payment $payment) : bool;
    abstract function makePayment() : Payment;
    abstract function getPanel() : JPanel;
}
abstract class RealPaymentUI extends PaymentUI {
    /** @var JTextField */ protected $actualPayment;
    /** @var JTextField */ protected $discount;
    function __construct(JTextField $paymentDate) {
        parent::__construct($paymentDate);
        $this->actualPayment = new JTextField();
        $this->discount = new JTextField();
    }
    function displayActualPayment(RealPayment $payment) {
        $this->actualPayment->setText((string)$payment->getActualPayment());
    }
    function displayDiscount(RealPayment $payment) {
        $this->discount->setText((string)$payment->getDiscount());
    }
    function makeActualPayment() : int {
        //parse the text in $actualPayment and return an int.
    }
    function makeDiscount() : int {
        //parse the text in $discount and return an int.
    }
}
class TTPaymentUI extends RealPaymentUI {
    /** @var JPanel */ private $panel;
    /** @var JTextField */ private $bankName;
    function __construct(JTextField $paymentDate) {
        parent::__construct($paymentDate);
        $this->panel = null; // initialization not shown here.
        $this->bankName = null; // initialization not shown here.
        //Add $bankName, $actualPayment, $discount to panel.
    }
    function tryToDisplayPayment(Payment $payment): bool {
        if (!($payment instanceof TTPayment))
            return false;
        $this->displayPaymentDate($payment);
        $this->displayActualPayment($payment);
        $this->displayDiscount($payment);
        $this->bankName->setText($payment->getBankName());
        return true;
    }
    function makePayment(): Payment {
        return new TTPayment($this->makePaymentDate(), $this->makeActualPayment(),
                                $this->makeDiscount(), $this->bankName->getText());
    }
    function __toString() {
        return 'TT';
    }
    function getPanel(): JPanel {
        return $this->panel;
    }
}
class FOCPaymentUI extends PaymentUI {
    //...
}
class ChequePaymentUI extends RealPaymentUI {
    //...
}
class EditPaymentDialog extends JDialog {
    /** @var Payment */     private $newPaymentToReturn;
    /** @var JPanel */      private $sharedPaymentDetails;
    /** @var JTextField */  private $paymentDate;
    /** @var JComboBox */   private $paymentType;
    /** @var PaymentUI[] */ private $paymentUIs = [];
    //...
    function __construct() {
        $this->setupComponents();
    }
    function setupComponents() : void {
        $this->setupComponentsSharedByAllPaymentTypes();
        $this->setupPaymentUIs();
        $this->setupPaymentTypeIndicator();
        $this->setupComponentsUniqueToEachPaymentType();
    }
    function setupComponentsSharedByAllPaymentTypes() : void {
        $this->paymentDate = new JTextField();
        $this->sharedPaymentDetails = new JPanel();
        $this->sharedPaymentDetails->add($this->paymentDate);
        $content_pane = $this->getContentPane();
        $content_pane->add($this->sharedPaymentDetails, BorderLayout::NORTH);
    }
    function setupPaymentUIs() : void {
        $this->paymentUIs[] = new TTPaymentUI($this->paymentDate);
        $this->paymentUIs[] = new FOCPaymentUI($this->paymentDate);
        $this->paymentUIs[] = new ChequePaymentUI($this->paymentDate);
        //...
    }
    function setupPaymentTypeIndicator()  : void {
        $this->paymentType = new JComboBox($this->paymentUIs);
        $this->sharedPaymentDetails->add($this->paymentType);
    }
    function setupComponentsUniqueToEachPaymentType() {
        $unique_payment_details = new JPanel();
        $unique_payment_details->setLayout(new CardLayout());
        foreach ($this->paymentUIs as $ui)
            $unique_payment_details->add($ui->getPanel(), (string)$ui);
        $this->getContentPane()->add($unique_payment_details, BorderLayout::CENTER);
    }

    function editPayment(Payment $payment): Payment {
        $this->displayPayment($payment);
        $this->setVisible(true);
        return $this->newPaymentToReturn;
    }

    function displayPayment(Payment $payment): void {
        foreach ($this->paymentUIs as $ui)
            if ($ui->tryToDisplayPayment($payment))
                $this->paymentType->setSelectedItem($ui);
    }
    function onOK(): void { //when the user clicks OK.
        $this->newPaymentToReturn = $this->makePayment();
        $this->dispose();
    }
    function makePayment(): Payment {
        $ui = $this->paymentType->getSelectedItem();
        return $ui->makePayment();
    }
    //...
}
