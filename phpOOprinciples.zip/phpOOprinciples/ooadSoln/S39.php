<?php
declare (strict_types=1);
use pht\Runnable;

class Scheduler implements Runnable {
    /** @var Runnable[] */ private $tasks  = [];
    function registerTask(Runnable $task) {
        $this->tasks[] = $task;
    }
    function run(): void {
        while(true) {
            sleep(1000);
            foreach ($this->tasks as $t)
                $t->run();
        }
    }
    //...
}
class OverHeatTask implements Runnable {
    /** @var Alarm */       private $alarm;
    /** @var PowerSupply */ private $powerSupply;
    /** @var HeatSensor */  private $heatSensor;
    function run() {
        if ($this->heatSensor->isOverHeated()) {
            $this->powerSupply->turnOff();
            $this->alarm->turnOn();
        }
    }
    //...
}
class RiceCookedCheckTask implements Runnable {
    /** @var Heater */          private $heater;
    /** @var MoistureSensor */  private $moistureSensor;
    function run() {
        if ($this->moistureSensor->getMoisture() < 60 )
            $this->heater->setTemperature(50);
    }
    //...
}
$scheduler = new Scheduler();
$scheduler->registerTask(new OverHeatTask());
$scheduler->registerTask(new RiceCookedCheckTask());
