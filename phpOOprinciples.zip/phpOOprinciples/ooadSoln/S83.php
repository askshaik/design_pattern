<?php
declare (strict_types=1);

interface Alarm {
    function turnOn() : void;
}
class Cooker implements Alarm {
    /** @var HeatSensor */ private $heatSensor;
    /** @var Speaker */    private $speaker;
    function turnOn() : void {
        $this->speaker->setFrequency(Speaker::HIGH_FREQUENCY);
        $this->speaker->turnOn();
    }
    //...
}
class HeatSensor {
    /** @var Alarm */    private $alarm;
    function __construct(Alarm $alarm) {
        $this->alarm = $alarm;
    }
    function checkOverHeated(): void {
        if ($this->isOverHeated()) {
            $this->alarm->turnOn();
        }
    }
    function isOverHeated(): bool {
        //...
    }
    //...
}