<?php
declare (strict_types=1);
abstract class Student {
    /** @var string */    public $studentId;
    //...
}
class NonGraduateStudent extends Student {
    //...
}
class GraduateStudent extends Student {
    //...
}
abstract class Teacher {
    /** @var string */    public $teacherId;
    /** @var Student[] */ public $studentsTaught = [];
    //...
    function getId(): string {
        return $this->teacherId;
    }
}
class NonGraduateTeacher extends Teacher {
    function addStudent(NonGraduateStudent $student): void {
        $this->studentsTaught[] = $student;
    }
    //...
}
class GraduateTeacher extends Teacher {
    function addStudent(Student $student): void {
        $this->studentsTaught[] = $student;
    }
    //...
}
