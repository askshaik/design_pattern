<?php
declare (strict_types=1);
class Participant {
    /**@var int*/ public $id;
    /**@var string*/ public $name;
    /**@var string*/ public $telNo;
    /**@var string*/ public $region;
    //...
}
class ParticipantsDBLogic {
    /**@var Connection*/ private $dbConn;
    //...Initialize $dbConn in constructor.
    function nextId() : int {
        $next_id = 0;
        $st = $this->dbConn->prepareStatement('select max(id) from participants');
        try {
            $rs = $st->executeQuery();
            try {
                $rs->next();
                $next_id = $rs->getInt(1) + 1;
            } finally {
                $rs->close();
            }
        } finally {
            $st->close();
        }
        return $next_id;
    }
    function addRecord(Participant $p) : void {
        $st = $this->dbConn->prepareStatement('insert into from participants values(?,?,?,?)');
        try {
            $st->setInt(1, $p->id);
            $st->setString(2, $p->name);
            $st->setString(3, $p->telNo);
            $st->setString(4, $p->region);
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
}
class ParticipantsBusinessLogic {
    /**@var Participant*/ private $participant;
    function __construct(Participant $participant) {
        $this->participant = $participant;
    }
    function assertValid() : void {
        if ($this->participant->name === '')
            throw new RuntimeException('Invalid name.');
        if (!in_array($this->participant->region, ['China', 'US', 'Europe']))
            throw new RuntimeException('Region is unknown.');
    }
}
class AddParticipantDialog extends JDialog {
    /** @var JTextField */    private $id;
    /** @var JTextField */    private $name;
    /** @var JTextField */    private $telNo;
    /** @var JTextField */    private $region;
    function __construct() {
        $this->setupComponents();
    }
    function setupComponents(): void {
        //...
    }
    function show(): void {
        $this->showDefaultValues();
        $this->setVisible(true);
    }
    function showDefaultValues(): void {
        $next_id = (new ParticipantsDBLogic())->nextId();
        $this->id->setText((string)$next_id);
        $this->name->setText('');
        $this->region->setText('China');
    }
    function onOK(): void {
        $p = new Participant();
        $p->id = $this->id->getText();
        $p->name = $this->name->getText();
        $p->telNo = $this->telNo->getText();
        $p->region = $this->region->getText();
        try {
            (new ParticipantsBusinessLogic($p))->assertValid();
        } catch (RuntimeException $ex) {
            JOptionPane::showMessageDialog($this,  $ex->getMessage());
            return;
        }
        (new ParticipantsDBLogic())->addRecord($p);
    }
    //...
}