<?php
declare (strict_types=1);

class CustomersInDB {
    /** @var Connection */    private $conn;

    private function replaceSymbolsInId(string $IDNumber) : string {
        $symbolsToReplace = '-()/';
        $replaceWithSpaces = str_repeat(' ', strlen($symbolsToReplace));
        str_replace($symbolsToReplace, $replaceWithSpaces, $IDNumber);
        return $IDNumber;

    }

    function getCustomer(string $IDNumber): Customer {
        $st = $this->conn->prepareStatement('select * from customer where ID=?');
        try {
            $st->setString(1, $this->replaceSymbolsInId($IDNumber));
            $rs = $st->executeQuery();
            //...
        } finally {
            $st->close();
        }
    }
    function addCustomer(Customer $customer): void {
        $st = $this->conn->prepareStatement('insert into customer values(?,?,?,?)');
        try {
            $st->setString(1, $this->replaceSymbolsInId($customer->getIDNumber()));
            $st->setString(2, $customer->getName());
            //...
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
    //...
}
