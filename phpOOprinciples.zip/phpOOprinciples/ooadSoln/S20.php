<?php
declare (strict_types=1);
class InchToPointConvertor {
    const POINTS_PER_INCH = 72;
    static function convertToPoints(float $inches): float {
        return $inches * self::POINTS_PER_INCH;
    }
}
