<?php
declare (strict_types=1);

abstract class Button {
    function addActionListener(ActionListener $listener): void {
        //...
    }
    abstract function paint(Graphics $graphics): void ;
    //...
}
class LabelButton extends Button {
    /** @var Font */    private $labelFont;
    /** @var string */  private $labelText;
    function paint(Graphics $graphics): void {
        //draw the label text on the graphics using the label's font.
    }
    //..
}
class BitmapButton extends Button {
    /** @var Bitmap */    private $bitmap;
    function paint(Graphics $graphics): void {
        //draw the bitmap on the graphics.
    }
    //...
}