<?php
declare (strict_types=1);
interface CopyMonitor {
    function updateProgress(int $noBytesCopied, int $sizeOfSource) : void;
}
class FileCopier {
    /** @var CopyMonitor */ private $copyMonitor;
    function __construct(CopyMonitor $copyMonitor) {
        $this->copyMonitor = $copyMonitor;
    }
    function copyFile(string $source, string $target): void {
        $size_of_source = filesize($source);
        //open files
        for ($i = 0; $i < $size_of_source;) {
            $n = 512;
            //read n (<= 512) bytes from source.
            //write n bytes to target.
            $i += $n;
            $this->copyMonitor->updateProgress($i, $size_of_source);
        }
        //close files
    }
    //...
}

class MainApp extends JFrame implements CopyMonitor {
    /** @var ProgressBar */   private $progressBar;
    function main(): void {
        $file_copier = new FileCopier($this);
        $file_copier->copyFile('f1.doc"', 'f2.doc');
    }
    function updateProgress(int $noBytesCopied, int $sizeOfSource) : void {
        $this->progressBar->setPercentage($noBytesCopied * 100 / $sizeOfSource);
    }
    //...
}

class TextApp implements CopyMonitor {
    function main(): void {
        $file_copier = new FileCopier($this);
        $file_copier->copyFile('f1.doc"', 'f2.doc');
    }
    function updateProgress(int $noBytesCopied, int $sizeOfSource) : void {
        printf("%f\n", $noBytesCopied * 100 / $sizeOfSource);
    }
    //...
}
/*In the above case, suppose that you need to develop another text mode
 * file copying application that will display a "*" for each 10% of
 * progress in its text console. What should you do?*/