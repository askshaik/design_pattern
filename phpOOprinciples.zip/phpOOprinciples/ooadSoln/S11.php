<?php
declare (strict_types=1);
abstract class Rental {
    /** @var DateTime */ private $rentDate;
    /** @var DateTime */ private $dueDate;
    /** @var float */    private $rentalFee;
    protected abstract function getOverduePenaltyRate() : float;
    function isOverdue(): bool {
        $now = new DateTime();
        return $this->dueDate < $now;
    }
    function getTotalFee(): float {
        return $this->isOverdue() ? ($this->getOverduePenaltyRate() * $this->rentalFee) : $this->rentalFee;
    }
}
class BookRental extends Rental {
    /** @var string */ private $bookTitle;
    /** @var string */ private $author;
    private const PENALTY_RATE = 1.2;
    protected function getOverduePenaltyRate() : float {
        return self::PENALTY_RATE;
    }
    //...
}
class MovieRental extends Rental {
    /** @var string */ private $movieTitle;
    /** @var int */    private $classification;
    private const PENALTY_RATE = 1.3;
    protected function getOverduePenaltyRate() : float {
        return self::PENALTY_RATE;
    }
}
