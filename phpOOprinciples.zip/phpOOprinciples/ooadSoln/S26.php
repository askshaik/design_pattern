<?php
declare (strict_types=1);
class Piece {
    /** @var string */    private $representation;
    function character() : string {
        return substr($this->representation, 0, 1);
    }
    function addTo(string &$bufferToBeAppended) :void {
        $bufferToBeAppended .= $this->character();
    }
    //...
}
class Location {
    /** @var Piece */    private $current;
    function addTo(string &$bufferToBeAppended) : void {
        $this->current->addTo($bufferToBeAppended);
    }
    //...
}
class Board {
    //...
    function boardRepresentation(): string {
        $buf = '';
        foreach (squares() as $location)
            $location->addTo($buf);
        return $buf;
    }
}

