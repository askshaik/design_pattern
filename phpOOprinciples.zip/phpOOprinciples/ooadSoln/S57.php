<?php
declare (strict_types=1);

/* This application is about students. Originally we had a
 * simple Student class:
 * class Student { String studentId; String name; Date dateOfBirth; }
 *
 * Later, in order to record what courses the student has
 * enrolled in, on which dates he enrolled and how he paid for them,
 * we modified the code as shown below.
 * Your task is to implement this requirement without modifying
 * the Student class.
 */



class Student {
    /** @var string */   public $id;
    /** @var string */   public $name;
    /** @var DateTime */ public $dateOfBirth;
    //...
}
class Enrollment {
    /** @var string */   public $studentId;
    /** @var string */   public $courseCode;
    /** @var DateTime */ public $enrollmentDate;
    /** @var Payment */  public $payment; //for each enrolled course, how he paid.
    //...
}
class Enrollments {
    /** @var Enrollment[] */ public $enrollments = [];
    function enroll(string $studentId, string $courseCode, DateTime $enrollDate, Payment $payment): void {
        $en = new Enrollment();
        $en->studentId = $studentId;
        $en->courseCode = $courseCode;
        $en->enrollmentDate = $enrollDate;
        $en->payment = $payment;
        $this->enrollments[] = $en;
     }
    function unenroll(string $studentId, string $courseCode): void {
        //...
    }


}
class StudentManagementSystem {
    /** @var Student[] */ public $students = [];
    /** @var Enrollments */ public $enrollments;
    //....
}
