<?php
declare (strict_types=1);
//improve code
class ReportCatalogueIndexCommandParser {
    /** @var array */static private $catalogCodes = [];
    const ORG_CATALOG = 0;
    const PART_CATALOG = 1;
    //.... other codes
    function __construct() {
        if (count(self::$catalogCodes) === 0) self::initialize();
    }
    private static function initialize() {
        self::$catalogCodes['orgNoGrouping'] = self::ORG_CATALOG;
        self::$catalogCodes['orgGroupByCountry'] = self::ORG_CATALOG;
        self::$catalogCodes['orgGroupByTypeOfOrgName'] = self::ORG_CATALOG;
        self::$catalogCodes['part'] = self::PART_CATALOG;
    }
    function getGroupingType(string $grouping): int {
        if (array_key_exists($grouping, self::$catalogCodes))
            return self::$catalogCodes[$grouping];
        throw new InvalidArgumentException("Invalid grouping!");
    }
}
