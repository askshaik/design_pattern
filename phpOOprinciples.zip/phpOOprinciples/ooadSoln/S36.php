<?php
declare (strict_types=1);
interface Currency {
    function format(int $amount) : string;
}
class USDCurrency  implements Currency {
    function format(int $amount): string {
        //return something like $1,200
    }
}
class RMBCurrency  implements Currency {
    function format(int $amount): string {
        //return something like RMB1,200
    }
}
class ESCUDOCurrency  implements Currency {
    function format(int $amount): string {
        //return something like $1.200
    }
}
