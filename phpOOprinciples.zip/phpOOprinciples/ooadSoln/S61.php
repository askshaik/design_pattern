<?php
declare (strict_types=1);

class Game {
    public const SIZE = 3;

    public const EMPTY = 0;
    public const CROSS = 1;
    public const CIRCLE = 2;

    /** @var int[][] */ private $board = [];

    public function __construct() {
        for ($r = 0; $r < self::SIZE; ++$r) {
            $this->board[] = [];
            for ($c = 0; $c < self::SIZE; ++$c)
                $this->board[$r][] = self::EMPTY;
        }
    }
    function putX(int $r, int $c): void {
        $this->board[$r][$c] = self::CROSS;
    }
    function putO(int $r, int $c): void {
        $this->board[$r][$c] = self::CIRCLE;
    }
    function isEmpty(int $r, int $c): bool {
        return $this->board[$r][$c] === self::EMPTY;
    }
    function isOver(): bool {
        return TableChecker::leftDiagnalFilledWithSameElements($this->board) ||
               TableChecker::rightDiagnalFilledWithSameElements($this->board) ||
               TableChecker::anyRowFilledWithSameElements($this->board) ||
               TableChecker::anyColumnFilledWithSameElements($this->board) ||
               TableChecker::allElementsNonZero($this->board);
    }
}
class TableChecker {
    private static function ensureOneNonZeroValuePresentInSet(Set $values) : bool {
        return ($values->contains(Game::EMPTY) === false) && ($values->count === 1);
    }
    static function leftDiagnalFilledWithSameElements(array $twoDimTable) {
        $v = new Set();
        for ($i=0; $i<Game::SIZE; $i++)
            $v->add($twoDimTable[$i][$i]);
        return self::ensureOneNonZeroValuePresentInSet($v);
    }
    static function rightDiagnalFilledWithSameElements(array $twoDimTable) {
        $v = new Set();
        $max = Game::SIZE;
        for ($i=0; $i<$max; $i++)
            $v->add($twoDimTable[$i][$max - $i - 1]);
        return self::ensureOneNonZeroValuePresentInSet($v);
    }
    private static function areValuesEqualButNotZero(array $mv) : bool {
        return self::ensureOneNonZeroValuePresentInSet(new Set($mv));
    }
    public static function anyRowFilledWithSameElements(array $twoDimTable) {
        for ($row=0; $row<Game::SIZE; $row++)
            if (self::areValuesEqualButNotZero($twoDimTable[$row]))
                return true;
        return false;
    }
    private static function getElementsOfColumn(int $col, array $twoDimTable) : array {
        $elements = [];
        for ($row=0; $row<Game::SIZE; $row++)
            $elements[] = $twoDimTable[$row][$col];
        return $elements;
    }
    public static function anyColumnFilledWithSameElements(array $twoDimTable) {
        for ($col=0; $col<Game::SIZE; $col++)
            if (self::areValuesEqualButNotZero(self::getElementsOfColumn($col, $twoDimTable)))
                return true;
        return false;
    }
    public static function allElementsNonZero(array $twoDimTable) {
        $v = new Set();
        for ($row=0; $row<Game::SIZE; $row++)
            $v->add($twoDimTable[$row]);
        return !$v->contains(0);
    }
}