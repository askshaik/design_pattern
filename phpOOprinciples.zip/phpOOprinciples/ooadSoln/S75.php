<?php
declare (strict_types=1);
//As there is no code that needs to use a PropertyFileWriter as a FileWriter,
//we should use delegation instead of inheritance:
class PropertyFileWriter {
    /**@var FileWriter*/ private $fileWriter;
    function __construct(string $path) {
        $this->fileWriter = new FileWriter($path);
    }
    function writeEntry(string $key, string $value): void {
        $this->fileWriter->write($key . '=' . $value);
    }
    function __destruct() {
        $this->fileWriter->close();
    }
    //more functions here
}
class App {
    function makePropertyFile(): void {
        $fw = new PropertyFileWriter("f1.properties");
        $fw->writeEntry("conference.abc", "10");
        $fw->writeEntry("xyz", "hello");
    }
}
