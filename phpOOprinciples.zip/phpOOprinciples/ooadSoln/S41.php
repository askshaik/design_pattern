<?php
declare (strict_types=1);
use \Ds\Vector;

class Session {
    /** @var DateTime */ private $date;
    /** @var int */      private $startHour;
    /** @var int */      private $endHour;
    function getDuration(): int {
        return $this->endHour - $this->startHour;
    }
    //...
}
abstract class Course {
    /** @var string */ private $courseTitle;
    function __construct($courseTitle) {
        //...
    }
    function getTitle() : string {
        return $this->courseTitle;
    }
    abstract function getFee() : float;
    abstract function getDuration() : float;
}
class SimpleCourse extends Course {
    /** @var Vector */  private $sessions = null;
    /** @var float */   private $fee = 0;
    function __construct(string $courseTitle, float $fee, array $sessions) {
        parent::__construct($courseTitle);
        $this->fee = $fee;
        $this->sessions = new Vector($sessions);
    }
    function getDuration(): float {
        $duration = 0;
        foreach ($this->sessions as $s)
            $duration += $s->getDuration();
        return $duration;
    }
    function getFee(): float {
            return $this->fee;
    }
    function setFee(float $fee) : void {
        $this->fee = $fee;
    }
}
class CompoundCourse extends Course {
    /** @var Vector */ private $modules = null;
    function __construct($courseTitle, array $modules) {
        parent::__construct($courseTitle);
        $this->modules = new Vector($modules);
    }
    function getFee(): float {
        $total_fee = 0.0;
        foreach ($this->modules as $m)
            $total_fee += $m->getFee();
        return $total_fee;
    }
    function getDuration(): float {
        $duration = 0;
        foreach ($this->modules as $m)
            $duration += $m->getDuration();
        return $duration;
    }
}