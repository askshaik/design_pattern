<?php
declare (strict_types=1);
interface Shape {
    function draw (Graphics $graphics) : void;
}
class Line implements Shape {
    /** @var Point */ private $startPoint;
    /** @var Point */ private $endPoint;
    function draw(Graphics $graphics): void {
        $graphics->drawLine($this->startPoint, $this->endPoint);
    }
    //...
}
class Rectangle implements Shape {
    /** @var Point */ private $lowerLeftCorner;
    /** @var Point */ private $upperRightCorner;
    function draw(Graphics $graphics): void {
        //draw the four edges.
        $graphics->drawLine(//...
        );
        $graphics->drawLine(//...
        );
        $graphics->drawLine(//...
        );
        $graphics->drawLine(//...
        );
    }
    //...
}
class Center implements Shape {
    /** @var Point */ private $center;
    /** @var int */ private $radius;
    function draw(Graphics $graphics): void {
        $graphics->drawCircle($this->center, $this->radius);
    }
    //...
}

class CADApp {
    function drawShapes(Graphics $graphics, array $shapes): void {
        foreach ($shapes as $shape)
            $shape->draw($graphics);
    }
}
