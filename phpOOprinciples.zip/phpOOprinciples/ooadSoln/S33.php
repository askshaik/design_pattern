<?php
declare (strict_types=1);
class SurveyData {
    /** @var string */ private $path; //save the data to this file.
    /** @var bool */   private $hidden; //should the file be hidden?

    function __construct(string $baseFileName, bool $hideDataFile) {
        $this->path = $baseFileName;
        $this->hidden = $hideDataFile;
    }
    function getSavePath() : string {
        return 'c:/application/data/' . $this->path . '.dat';
    }

    static function getRawDataType() : SurveyData {
        return new SurveyData('raw', true);
    }
    static function cleanedUpDataType() : SurveyData {
        return new SurveyData('cleanedUp', true);
    }
    static function processedDataType() : SurveyData {
        return new SurveyData('processed', true);
    }
    static function publicationDataType() : SurveyData {
        return new SurveyData('publication', false);
    }

    //...
}