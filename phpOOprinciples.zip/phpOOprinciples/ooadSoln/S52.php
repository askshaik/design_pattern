<?php
declare (strict_types=1);
abstract class Payment {
    /** @var int */     private $units;
    /** @var float */   private $rate;
    const TAX_RATE = 0.1;
    abstract protected function getPreTaxedAmount() : float;
    abstract protected function getTaxRate() : float;
    function getBillableAmount(): float {
        return $this->getPreTaxedAmount() * (1.0 + $this->getTaxRate());
    }
    protected function getNormalAmount() : float {
        return $this->units * $this->rate;
    }
}
class NormalPayment extends Payment {
    protected function getPreTaxedAmount(): float {
        return $this->getNormalAmount();
    }
    protected function getTaxRate(): float {
        return self::TAX_RATE;
    }
}
class PaymentForSeniorCitizen extends Payment {
    const DISCOUNT = 0.05;
    const DISCOUNTED_RATE = 0.8;
    protected function getPreTaxedAmount(): float {
        return $this->getNormalAmount() * self::DISCOUNTED_RATE;
    }
    protected function getTaxRate(): float {
        return self::TAX_RATE - self::DISCOUNT;
    }
}

