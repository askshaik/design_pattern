<?php
declare (strict_types=1);
class UserAccount {
    /** @var UserType */  public $userType;
    /** @var string */    private $id;
    /** @var string */    private $name;
    /** @var string */    private $password;
    /** @var DateTime */  public $dateOfLastPasswdChange;
    //...
}
class UserType {
    /** @var int */ private $passwordMaxAgeInDays;
    /** @var bool */ private $allowedToPrintReport;
    private function __construct(int $passwordMaxAgeInDays, bool $allowedToPrintReport) {
        $this->passwordMaxAgeInDays = $passwordMaxAgeInDays;
        $this->allowedToPrintReport = $allowedToPrintReport;
    }
    function getPasswordMaxAgeInDays() : int {
        return $this->passwordMaxAgeInDays;
    }
    function canPrintReport() : bool {
        return $this->allowedToPrintReport;
    }
    const PASSWORD_AGE_NORMAL = 90;
    const PASSWORD_AGE_ADMIN = 30;
    static function getNormalUserType() : UserType{
        return new UserType(self::PASSWORD_AGE_ADMIN, true);
    }
    static function getAdminUserType() : UserType{
        return new UserType(self::PASSWORD_AGE_ADMIN, true);
    }
    static function getGuestUserType() : UserType{
        return new UserType(PHP_INT_MAX, false);
    }
}
class InventoryApp {
    function login(UserAccount $userLoggingIn, string $password): void {
        if ($userLoggingIn->checkPassword($password)) {
            $today = new DateTime();
            $expiry_date = $this->getAccountExpiryDate($userLoggingIn);
            if ($today > $expiry_date) {
                //prompt the user to change password
            }
        }
    }
    function getAccountExpiryDate(UserAccount $account): DateTime {
        $password_max_age_in_days = $this->getPasswordMaxAgeInDays($account);
        $expiry_date = new DateTime();
        $ad = $account->dateOfLastPasswdChange;
        $expiry_date->setTime((int)$ad->format('H'), (int)$ad->format("i"), (int)$ad->format('s'));
        return $expiry_date->add(new DateInterval("P{$password_max_age_in_days}D"));
    }

    function getPasswordMaxAgeInDays(UserAccount $account): int {
        return $account->userType->getPasswordMaxAgeInDays();
    }

    function printReport(UserAccount $currentUser): void {
        $can_print = $currentUser->userType->canPrintReport();
        if ($can_print === false)
            throw new RuntimeException("You have no right");
        //print the report.
    }
}

