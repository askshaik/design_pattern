<?php
declare (strict_types=1);

abstract class TaxBandGenerator {
    static function createInstance(string $cultureInfo) : TaxBandGenerator {
        switch($cultureInfo) {
        case 'en-NZ': return new NewZealandTaxBandGenerator();
        case 'en-AU': return new AustralianTaxBandGenerator();
        case 'en-US': return new USATaxBandGenerator();
        }
        return new NullTaxBandGenerator();
    }
    /** @return TaxBand[] */
    abstract function createTaxBands() : array;
}
class NewZealandTaxBandGenerator extends TaxBandGenerator {
    function createTaxBands(): array {
        return [ new TaxBand(0.0, 19500.99, 0.195),
                 new TaxBand(19501.00, 60000.99, 0.33),
                 new TaxBand(60001.00, PHP_FLOAT_MAX, 0.39)];
    }
}
class AustralianTaxBandGenerator extends TaxBandGenerator {
    function createTaxBands(): array {
        return [new TaxBand(0.0, 6000.99, 0.0),
                new TaxBand(6001.00, 25000.99, 0.15),
                new TaxBand(25001.00, 75000.99, 0.30),
                new TaxBand(75001.00, 150000.99, 0.40),
                new TaxBand(150001.00, PHP_FLOAT_MAX, 0.45)];
    }
}
class USATaxBandGenerator extends TaxBandGenerator {
    function createTaxBands(): array {
        return [new TaxBand(0.0, 7550.99, 0.10),
                new TaxBand(7551.00, 30650.99, 0.15),
                new TaxBand(30651.00, 74200.99, 0.25),
                new TaxBand(74201.00, 154800.99, 0.28),
                new TaxBand(154801.00, 336550.99, 0.33),
                new TaxBand(336551.00, PHP_FLOAT_MAX, 0.35)];
    }
}
class NullTaxBandGenerator extends TaxBandGenerator {
    function createTaxBands(): array {
        return [new TaxBand(0.0, PHP_FLOAT_MAX, 0.0) ];
    }
}
class TaxBand {
    const ZERO_VALUE = 0.0;
    /**@var float*/ private $lowerLimitAmount;
    /**@var float*/ private $upperLimitAmount;
    /**@var float*/ private $taxRate;
    function __construct($lowerLimitAmount, $upperLimitAmount, $taxRate) {
        $this->lowerLimitAmount = $lowerLimitAmount;
        $this->upperLimitAmount = $upperLimitAmount;
        $this->taxRate = $taxRate;
    }
    function calculateTaxPortion (float $income) {
        if ($this->equalToOrLessThan($income, $this->lowerLimitAmount))
            return self::ZERO_VALUE;
        elseif ($this->fallWithinTaxBand($income))
            return ($income - $this->lowerLimitAmount) * $this->taxRate;
        elseif ($this->equalToOrGreaterThan($income, $this->upperLimitAmount))
            return ($this->upperLimitAmount - $this->lowerLimitAmount) * $this->taxRate;
        else
            return self::ZERO_VALUE;
    }
    private function fallWithinTaxBand(float $income) : bool {
        return $this->equalToOrGreaterThan($income, $this->lowerLimitAmount) &&
                    $this->equalToOrLessThan($income, $this->upperLimitAmount);
    }
    private function equalToOrGreaterThan(float $income, float $bandValue) : bool {
        return $income >= $bandValue;
    }
	private function equalToOrLessThan(float $income, float $bandValue) : bool {
        return $income <= $bandValue;
    }
    public function getLowerLimitAmount(): float {
        return $this->lowerLimitAmount;
    }
    public function getUpperLimitAmount(): float {
        return $this->upperLimitAmount;
    }
    public function getTaxRate(): float {
        return $this->taxRate;
    }
}
class IncomeTaxEngine {
    /**@var TaxBand[]*/ private $taxBands;
    function __construct(string $cultureInfo) {
        $this->taxBands = TaxBandGenerator::createInstance($cultureInfo)->createTaxBands();
    }
    function calculateTaxLiability(float $income) : float {
        $tax_liability = 0.0;
        foreach ($this->taxBands as $tax_band)
			$tax_liability += $tax_band->calculateTaxPortion($income);
        return $tax_liability;
	}
	function calculateTaxRate(float $income) : float {
        foreach ($this->taxBands as $t)
			if ($income >= $t->getLowerLimitAmount() && $income <= $t->getUpperLimitAmount())
                return $t->getTaxRate();
		throw new LogicException();
	}
}
class Investor {
    /**@var float*/             public $income;
    /**@var IncomeTaxEngine*/   private $taxEngine;
    function __construct(float $income, string $culture='') {
        $this->income = $income;
        $this->taxEngine = new IncomeTaxEngine($culture);
    }
	function getTaxLiability() : float {
		return $this->taxEngine->calculateTaxLiability($this->income);
	}
	function getTaxRate() : float {
		return $this->taxEngine->calculateTaxRate($this->income);
	}
}

