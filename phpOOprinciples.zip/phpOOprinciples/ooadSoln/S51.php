<?php
declare (strict_types=1);

class Department {
    /** @var string */private $departmentName;
    private function __construct(string $departmentName) {
        $this->departmentName = $departmentName;
    }
    static function getAccount() : Department {
        return new Department('Account');
    }
    static function getMarketing() : Department {
        return new Department('Marketing');
    }
    static function getCustomerServices() : Department {
        return new Department('Customer Services');
    }
    function getDepartmentName(): string {
        return $this->departmentName;
    }
}
