<?php
declare (strict_types=1);
interface Resource {
    function getFree() : int;
    function markFree(int $resourceId) : void;
}
class File implements Resource {
    function getFree(): int {
        //...
    }
    function markFree(int $resourceId): void {
        //...
    }
}
class Database implements Resource {
    function getFree(): int {
        //...
    }
    function markFree(int $resourceId): void {
        //...
    }
}
class Ra1 {
    function allocate(Resource $r): int {
        return $r->getFree();
    }
    function free(Resource $r, int $resourceId): void {
        $r->markFree($resourceId);
    }
}
