<?php
declare (strict_types=1);
use PHPUnit\Framework\TestCase;

class ParticipantsInDBTest extends TestCase {
    /** @var ParticipantsInDB */    private $p;
    /** @var Participant */ private $part1;
    /** @var Participant */ private $part2;
    protected function setUp(): void {
        $this->p = ParticipantsInDB::getInstance();
    }
    protected function tearDown(): void {
        ParticipantsInDB::freeInstance();
    }
    function __construct() {
        parent::__construct();
        $this->part1 = new Participant("ABC001", "Kent", "Tong", true, "Manager");
        $this->part2 = new Participant('ABC003', 'Paul', 'Chan', true, 'Manager');
    }
    function testAdd(): void {
        $this->p->deleteAllParticipants();
        $this->p->addParticipant($this->part1);
        $this->assertEquals(1, $this->p->getCount());
    }
    function testAdd2(): void {
        $this->p->deleteAllParticipants();
        $this->p->addParticipant($this->part1);
        $this->p->addParticipant($this->part2);
        $this->assertEquals(2, $this->p->getCount());
    }
    function testEnum(): void {
        $this->p->deleteAllParticipants();
        $this->p->addParticipant($this->part2);
        $this->p->addParticipant($this->part1);
        $penum = new ParticipantEnumeratorById();
        try {
            $this->assertTrue($penum->next());
            $this->assertTrue($penum->get() === $this->part1);
            $this->assertTrue($penum->next());
            $this->assertTrue($penum->get() === $this->part2);
            $this->assertFalse($penum->next());
        } finally {
            $penum->close();
        }
    }
}
