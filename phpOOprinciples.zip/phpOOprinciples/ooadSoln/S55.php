<?php
declare (strict_types=1);
interface Report {
    function print() : void;
}
class Report1 implements Report {
    function __toString(): string
    {
        return "r1";
    }
    function print(): void {
        //print some fancy report...
    }
}
class Report2 implements Report {
    function __toString(): string
    {
        return "r2";
    }
    function print(): void {
        //print another totally different fancy report...
    }
}
class Report31c implements Report {
    function __toString(): string
    {
        return "r31c";
    }
    function print(): void {
        //print yet another totally different fancy report...
    }
}
class Form1 extends JDialog {
    /** @var JComboBox */   private $comboBoxReportType;
    /** @var Report[] */    private $reports;
    function __construct() {
        $reports = [ new Report1(), new Report2(), new Report31c()];
        $this->comboBoxReportType = new JComboBox();
        foreach ($this->reports as $r)
            $this->comboBoxReportType->addItem($r);
    }
    function onPrintClick(): void {
        $this->comboBoxReportType->getSelectedItem()->print();
    }
}
