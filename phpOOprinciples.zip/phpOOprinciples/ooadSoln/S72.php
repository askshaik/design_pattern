<?php
declare (strict_types=1);
//EmployeeList doesn't want to inherit the addNode method.
//Employee is not a Node.

class Node {
    /** @var Node */    private $nextNode;
    function getNextNode(): Node {
        return $this->nextNode;
    }
    function setNextNode(Node $nextNode): void {
        $this->nextNode = $nextNode;
    }
    //...
}
class LinkList {
    /** @var Node */    private $firstNode;
    function addNode(Node $newNode): void {
        //...
    }
    function getFirstNode(): Node {
        return $this->firstNode;
    }
    //...
}
class Employee {
    /** @var string */    private $employeeId;
    /** @var string */    private $name;
    //...
}
class EmployeeNode extends Node {
    /** @var Employee */ public $employee;
    function __construct(Employee $employee) {
        $this->employee = $employee;
    }
    //...
}
class EmployeeList  {
    /**@var LinkList */ private $list;
    function addEmployee(Employee $employee): void {
        $this->list->addNode(new EmployeeNode($employee));
    }
    function getFirstEmployee() : Employee {
        return $this->list->getFirstNode()->employee;
    }
    //...
}
