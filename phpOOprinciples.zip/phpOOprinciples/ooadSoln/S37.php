<?php
declare (strict_types=1);
abstract class Payment {
    /** @var DateTime */    private $paymentDate;
    abstract function getNominalPayment(): int;
}
class FreeOfCharge extends Payment {
    /** @var int */ private $amountWaived;
    function getNominalPayment(): int {
        return $this->amountWaived;
    }
    //....
}
class RealPayment extends Payment {
    /** @var int */ private $actualPayment;
    /** @var int */ private $discount;
    function getNominalPayment(): int {
        return $this->actualPayment + $this->discount;
    }
    //...
}
class CashPayment extends RealPayment {
    //...
}
class BankPayment extends  RealPayment {
    /** @var string */    private $bankName;
    function getBankName() : string {
        return $this->bankName;
    }
    //....
}
class TelegraphicTransfer extends BankPayment {
    //...
}
class ChequePayment extends BankPayment {
    /** @var string */    private $chequeNumber;
    //...
}
class CreditCardPayment extends BankPayment {
    /** @var string */    private $creditCardType;
    /** @var string */    private $creditCardHolderName;
    /** @var string */    private $creditCardNumber;
    /** @var DateTime */  private $creditCardExpiryDate;
    //...
}
