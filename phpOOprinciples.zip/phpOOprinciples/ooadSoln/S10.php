<?php
declare (strict_types=1);
class UIDialogShower {
    private const LEFT_PIXEL = 400;
    private const TOP_PIXEL = 200;
    static function show(Dialog $d, int $left=self::LEFT_PIXEL, int $top = self::TOP_PIXEL) : void {
        $d->pack();
        $d->setLocation($left, $top);
        $d->setVisible(true);
    }
}
class ChangePasswordButton extends JButton {
    function __construct(JDialog $enclosingDialog) {
        $this->addActionListener(new class($this) extends ActionListener {
            /** @var UIDialogCustomerMain */
            private $ui;
            function __construct(UIDialogCustomerMain $ui) { $this->ui = $ui; }
            function actionPerformed(ActionEvent $e): void {
                $d = new UIDialogCustomerDeleteOrder($this->ui, "chg pw", true);
                UIDialogShower::show($d);
            }
        });
    }
}
class UIDialogCustomerMain extends JDialog {
    /** @var JButton */    private $btnOrderDel;
    /** @var JButton */    private $btnCustChangePassword;
    function __construct() {
        $this->btnCustChangePassword = new ChangePasswordButton($this);
    }
    function bindEvents(): void {
        //...
        $this->btnOrderDel->addActionListener(new class($this) extends ActionListener {
            /** @var UIDialogCustomerMain */    private $ui;
            function __construct(UIDialogCustomerMain $ui) { $this->ui = $ui; }
            function actionPerformed(ActionEvent $e): void {
                $d = new UIDialogCustomerDeleteOrder($this->ui, "Del Order", true);
                UIDialogShower::show($d);
            }
        });
    }
    //...
}

class UIDialogRestaurantMain extends JDialog {
    /** @var JButton */    private $btnChangePassword;
    function __construct() {
        $this->btnChangePassword = new ChangePasswordButton($this);
    }
    function bindEvents(): void {
        //...
    }
    //...
}
