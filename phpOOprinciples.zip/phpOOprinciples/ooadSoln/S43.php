<?php
declare (strict_types=1);
use \Ds\Map;

class Customer {
    /** @var string */    public $homeAddress;
    /** @var string */    public $workAddress;
    //...
}
interface DeliveryAddress {
}
class HomeAddress implements DeliveryAddress {
    /** @var Customer */ public $customer;
    function __construct(Customer $c) {
        $this->customer = $c;
    }
    function __toString() {
        return $this->customer->homeAddress;
    }
}
class WorkAddress implements DeliveryAddress {
    /** @var Customer */ public $customer;
    function __construct(Customer $c) {
        $this->customer = $c;
    }
    function __toString() {
        return $this->customer->workAddress;
    }
}
class SpecificAddress implements DeliveryAddress {
    /** @var string */ public $addressSpecified;
    function __construct(string $address) {
        $this->addressSpecified = $address;
    }
    function __toString() {
        return $this->addressSpecified;
    }
}
class Order {
    /** @var string */          private $orderId;
    /** @var Restaurant */      private $restaurantReceivingOrder;
    /** @var Customer */        private $customerPlacingOrder;
    /** @var DeliveryAddress */ private $deliveryAddress;
    /** @var Map */             private $orderItems;
    function getDeliveryAddress(): string {
        return (string)$this->deliveryAddress;
    }
    //...
}