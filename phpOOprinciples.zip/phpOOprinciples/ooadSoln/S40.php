<?php
declare (strict_types=1);
interface Schedule {
    function getDurationInDays() : int;
    function print() : void;
}
class WeeklySchedule implements Schedule {
    /**@var int */ private $noWeeks;
    /**@var DateTime */ private $fromDate;
    /**@var DateTime */ private $toDate;
    function getDurationInDays(): int {
        return $this->noWeeks;
    }
    function print(): void {
        //...
    }
}
class RangeSchedule implements Schedule {
    /**@var DateTime */ private $fromDate;
    /**@var DateTime */ private $toDate;
    function getDurationInDays(): int {
        return (int)($this->fromDate->diff($this->toDate)->days);
    }
    function print(): void {
        //...
    }
}
class ListSchedule implements Schedule {
    /** @var DateTime[] */ private $dateList;
    function getDurationInDays(): int {
        return count($this->dateList);
    }
    function print(): void {
        //...
    }
}
class Course {
    /** @var string */    private $courseTitle;
    /** @var Schedule */  private $schedule;
    function getDurationInDays(): int {
        return $this->schedule->getDurationInDays();
    }
    function printSchedule(): void {
        $this->schedule->print();
    }
    //...
}
