<?php
declare (strict_types=1);

abstract class PricingService {
    /** @var VoucherService */    private $voucherService;
    /** @var PriceCalculation */  private $priceCalculation;
    function __construct($voucherService, $priceCalculation) {
        $this->voucherService = $voucherService;
        $this->priceCalculation = $priceCalculation;
    }
    function calculatePrice(ShoppingBasket $shoppingBasket, User $user, string $voucher): float {
        $discount = $this->calculateDiscount($user);
        $total = 0;
        foreach ($shoppingBasket->items() as $item)
            $total += $this->priceCalculation->calculateProductPrice($item->getProduct(), $item->getQuantity());
        $total = $this->applyAdditionalDiscounts($total, $user, $voucher);
        return $total * (100 - $discount) / 100;
    }
    private function calculateDiscount(User $user): float {
        $discount = 0;
        if ($user->isPrime()) $discount = 10;
        return $discount;
    }
    private function applyAdditionalDiscounts(float $total, User $user, string $voucher) :float {
        $voucher_value = $this->voucherService->getVoucher($voucher);
        $total_after_value = $total - $voucher_value;
        return max(0.0, $total_after_value);
    }
}
interface PriceCalculation {
    function calculateProductPrice(Product $product, int $quantity): float;
}
class StandardPriceCalculation implements PriceCalculation {
    function calculateProductPrice(Product $product, int $quantity): float {
        return $product->getPrice() * $quantity;
    }
}
class BoxingDayPriceCalculation implements PriceCalculation {
    const BOXING_DAY_DISCOUNT = 0.60;
    function calculateProductPrice(Product $product, int $quantity): float {
        return $product->getPrice() * $quantity * self::BOXING_DAY_DISCOUNT;
    }
}

