<?php
declare (strict_types=1);
class ParticipantsInfoOnBadge {
    /** @var string */    private $participantId;
    /** @var string */    private $participantEnglishFullName;
    /** @var string */    private $participantChineseFullName;
    /** @var string */    private $englishOrgName;
    /** @var string */    private $chineseOrgName;
    /** @var string */    private $englishOrgCountry;
    /** @var string */    private $chineseOrgCountry;

    function __construct(string $participantId) {
        $this->loadInfoFromDB($participantId);
    }
    private function loadInfoFromDB(string $participantId) : void {
        $this->participantId = $participantId;
        $this->getParticipantFullNames();
        $this->getOrgNameAndCountry();
    }
    private function getParticipantFullNames() : void {
        $parts_in_db = ParticipantsInDB::getInstance();
        $part = $parts_in_db->locateParticipant($this->participantId);
        if ($part !== null) {
            $this->participantEnglishFullName = $part->getEFullName();
            $this->participantChineseFullName = $part->getCFullName();
        }
    }
    private function getOrgNameAndCountry() : void {
        $orgs_in_db = OrganizationsInDB::getInstance();
        $oid = $orgs_in_db->findOrganizationEmploying($this->participantId);
        if ($oid !== null) {
            $org = $orgs_in_db->locateOrganization($oid);
            $this->englishOrgName = $org->getEName();
            $this->chineseOrgName = $org->getCName();
            $this->englishOrgCountry = $org->getEAddress()->getCountry();
            $this->chineseOrgCountry = $org->getCAddress()->getCountry();
        }
    }
    //...
}
