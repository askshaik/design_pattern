<?php
declare (strict_types=1);

interface Validator {
    function isValid() : bool;
}
class PersonalLoanValidator implements Validator {
    function isValid(): bool {
        //Validation logic.
    }
}
class VechicleLoanValidator implements Validator {
    function isValid(): bool {
        //Validation logic.
    }
}
class LoanApprovalHandler {
    function approveLoan(Validator $validator): void {
        if ($validator->isValid()) {
            //Process the loan.
        }
    }
}

