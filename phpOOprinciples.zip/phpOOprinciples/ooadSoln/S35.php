<?php
declare (strict_types=1);
use \Ds\Vector;

interface RentalProcessor {
    function process(Rental $rental) : void;
}
class BookRentals {
    /** @var Vector */    private $rentals;
    function countRentals(): int {
        return $this->rentals->count();
    }
    function getRentalAt(int $i): BookRental {
        return $this->rentals->get($i);
    }
    private function processOverdueRentals(RentalProcessor $processor) {
        for ($i = 0; $i < $this->countRentals(); $i++) {
            $rental = $this->getRentalAt($i);
            if ($rental->isOverdue() &&
                true //some Complex if condition here
            )
                $processor->process($rental);
        }
    }
    function printOverdueRentals(): void {
        $this->processOverdueRentals(new class implements RentalProcessor{
            function process(Rental $rental): void {
                echo $rental . '\n';
            }
        });
    }
    function countOverdueRentals(): int {
        $count_rentals = new class implements RentalProcessor{
            public $count = 0;
            function process(Rental $rental): void {
                $this->count++;
            }
        };
        $this->processOverdueRentals($count_rentals);
        return $count_rentals->count;
    }
    //...
}