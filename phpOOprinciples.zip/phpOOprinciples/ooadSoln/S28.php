<?php
declare (strict_types=1);
use \Ds\Vector;
use \myutil\Optional;

//Two solutions are mentioned below
class S28Artists_ThrowExceptionInsteadOfReturningNull {
    /** @var Vector */    private $artists;
    function __construct(array $artists) {
        $this->artists = new Vector($artists);
    }
    function getArtist(int $index): Artist {
        if (($index < 0) || ($index >= $this->artists->count()))
            throw new InvalidArgumentException("{$index} doesn't correspond to an Artist");
        return $this->artists->get($index);
    }
    function getArtistName(int $index): string {
        return $this->getArtist($index)->getName();
    }
    //...
}
class S28Artists_ReturnOptional {
    /** @var Vector */    private $artists;
    function __construct(array $artists) {
        $this->artists = new Vector($artists);
    }
    function getArtist(int $index): Optional {
        if (($index < 0) || ($index >= $this->artists->count()))
            return Optional::empty();
        return Optional::of($this->artists->get($index));
    }
    function getArtistName(int $index): string {
        $op = $this->getArtist($index);
        return $op->isPresent()? $op->get()->getName() : "unknown";
    }
    //...
}
