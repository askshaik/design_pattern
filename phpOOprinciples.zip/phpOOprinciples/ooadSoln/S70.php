<?php
declare (strict_types=1);

//Remove the duplication for scanning the listeners array
interface GridListener {
    function onRowAppended(): void;
    function onRowMoved(int $existingIdx, int $newIdx): void;
}
interface GridListenerNotifier {
    function notify(GridListener $listener) : void;
}
class Grid {
    /** @var GridListener[] */    private $listeners = [];
    function appendRow(): void {
        //append a row at the end of the grid.
        $this->notifyListeners(new class implements GridListenerNotifier{
            function notify(GridListener $listener) : void{
                $listener->onRowAppended();
            }
        });
    }
    function moveRow(int $existingIdx, int $newIdx): void {
        //move the row.
        $this->notifyListeners(new class ($existingIdx, $newIdx) implements GridListenerNotifier{
            private $existingIdx;
            private $newIdx;
            function __construct(int $existingIdx, int $newIdx) {
                $this->existingIdx = $existingIdx;
                $this->newIdx = $newIdx;
            }
            function notify(GridListener $listener) : void{
                $listener->onRowMoved($this->existingIdx, $this->newIdx);
            }
        });
    }
    private function notifyListeners(GridListenerNotifier $notifier) : void {
        foreach ($this->listeners as $grid_listener)
            $notifier->notify($grid_listener);
    }
}
