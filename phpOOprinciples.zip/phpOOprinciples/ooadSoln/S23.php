<?php
declare (strict_types=1);
class TokenStream {
    /** @var string[] */       private $parsedTokenList;
    /** @var int */            private $currentTokenIndexInList;
    /** @var BufferedReader */ private $charInputSourceForParsing;
    /** @var string */         private $previousCharReadFromSource;

    function __construct(Reader $read) {
        $this->charInputSourceForParsing = new BufferedReader($read);
        $this->takeChar();
        $this->parsedTokenList = $this->parseTokensFromInputSource();
        $this->currentTokenIndexInList = 0;
    }
    function parseTokensFromInputSource(): array {
        $tokens_parsed_so_far = [];
        //...
        return $tokens_parsed_so_far;
    }
    //...
}