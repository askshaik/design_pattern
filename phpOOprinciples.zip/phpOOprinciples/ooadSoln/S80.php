<?php
declare (strict_types=1);

interface MessageDisplay {
    function showMessage(string $msg) : void;
}
class ZipEngine {
    function makeZip(string $zipFilePath, array $srcFilePaths, MessageDisplay $msgDisplay): void {
        //create zip file at the path.
        //...
        foreach ($srcFilePaths as $src_file) {
            $msgDisplay->showMessage("Zipping " . $src_file);
            //...
        }
    }
    //...
}
class ZipMainFrame extends Frame implements  MessageDisplay {
    /** @var StatusBar */    private $sb;
    function makeZip(): void {
        $zip_file_path = "";
        $src_file_paths = [];
        //setup zip_file_path and src_file_paths according to the UI.
        $ze = new ZipEngine();
        $ze->makeZip($zip_file_path, $src_file_paths, $this);
    }

    function setStatusBarText(string $statusText): void {
        $this->sb->setText($statusText);
    }
    function showMessage(string $msg) : void {
        $this->setStatusBarText($msg);
    }
    //...
}
class TextModeApp implements MessageDisplay {
    function makeZip() : void {
        $zip_file_path = "";
        $src_file_paths = [];
        //setup zip_file_path and src_file_paths according to the UI.
        $ze = new ZipEngine();
        $ze->makeZip($zip_file_path, $src_file_paths, $this);
    }
    function showMessage(string $msg) : void {
        printf("%s\n", $msg);
    }
    //...
}