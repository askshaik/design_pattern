<?php
declare (strict_types=1);
use \Ds\Set;
class NumberClassifier {
    private static function isFactor(int $number, int $potentialFactor): bool {
        return intdiv($number, $potentialFactor) === 0;
    }
    private static function factors(int $number): Set {
        $factors = new Set();
        $factors->add(1);
        $upper_limit = sqrt($number);
        for ($i = 2; $i <= $upper_limit; $i++)
            if (self::isFactor($number, $i)) {
                $factors->add($i);
                $factors->add(intdiv($number, $i));
            }
        return $factors;
    }
    private static function sumOfFactors(Set $factors): int {
        return $factors->sum();
    }
    static function isPerfect(int $number): bool {
        return self::sum(self::factors($number)) === $number;
    }
    static function isAbundant(int $number): bool {
        return self::sum(self::factors($number)) > $number;
    }
    static function isDeficient(int $number): bool {
        return self::sum(self::factors($number)) < $number;
    }
}