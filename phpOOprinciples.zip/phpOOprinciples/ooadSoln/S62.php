<?php
declare (strict_types=1);

class AccumulateBookDetails {
    /** @var float */ public $totalPrice = 0;
    /** @var int */   public $validRecords = 0;
    /** @var int */   public $invalidRecords = 0;
    function process(callable $input, callable $extractPrice): void {
        $skip_header = call_user_func($input);
        while (($line = call_user_func($input)) !== '') {
            $price = call_user_func($extractPrice, $line);
            if ($price > 0) $this->validRecords++; else $this->invalidRecords++;
            $this->totalPrice += $price;
        }
    }
}
class ReadEachLineOfFile {
    private $f;
    function __construct() {
        $f = fopen("book.csv", "r");
    }
    function nextLine() : string {
        $line = fgets($this->f);
        if ($line === false) {
            $line = '';
            fclose($this->f);
        }
        return $line;
    }
}
class BookRecord {
    /** @var string */ private $isbn;
    /** @var string */ private $price;
    /** @var string */ private $title;
    function __construct($isbn, $price, $title) {
        $this->isbn = $isbn;
        $this->price = $price;
        $this->title = $title;
    }
    static function createFrom(string $line) : BookRecord {
        $empty = new BookRecord('','','');
        if ($line === null || $line === '') return $empty;
        $items = explode(',', $line);
        return (count($items) === 3)? new BookRecord($items[0], $items[1], $items[2]) : $empty;
    }
    static function getValidPrice(BookRecord $b) : float {
        return (float)$b->price;
    }
}
class OOFunctionalCSV {
    static function main(): void {
        $acc = new AccumulateBookDetails();
        $rin = new ReadEachLineOfFile();
        $acc->process([$rin, 'nextLine'], function ($line) { BookRecord::getValidPrice(BookRecord::createFrom($line)); });
        printf("Total price of all Books %.2f\n. Total Valid records - %d.    Total Invalid records - %d\n",
            $acc->totalPrice, $acc->validRecords, $acc->invalidRecords);
    }
    // The above code is better designed because it can easily accommodate
    // new features like take sum of costliest 3 books only.
}

