<?php
declare (strict_types=1);

class Employee {
    /** @var string */ private $name;
    /** @var string */ private $address;
    /** @var int */    private $id;
    /** @var int */    private $mobile;
    //Assume public getters,setters, toString and other common functions.

    /** @var callable */ private $c;
    private function __construct(callable $c) {
        $this->c = $c;
    }
    function calculateHolidaysPermitted(int $month): int {
        return call_user_func($this->c, $month);
    }
    static private function permanentEmployeeHoidays(int $month): int {
        return ($month == 12) ? 4 : 3;
    }
    static private function temporaryEmployeeHoidays(int $month): int {
        return 2;
    }
    static function createPermanentEmployee() : Employee {
        return new Employee(["self", "permanentEmployeeHoidays"]);
    }
    static function createTemporaryEmployee() : Employee {
        return new Employee(["self", "temporaryEmployeeHoidays"]);
    }
}

