<?php
declare (strict_types=1);
use \Ds\Map;

require_once '..\myUtils\BetterEnum.php';
use \myutil\BetterEnum;

class DeliveryAddress extends BetterEnum {
    const HOME_ADDRESS = 0;
    const WORK_ADDRESS = self::HOME_ADDRESS + 1;
    const OTHER_ADDRESS = self::WORK_ADDRESS + 1;
}

class Order {
    /** @var string */      private $orderId;
    /** @var Restaurant */  private $restaurantToReceiveOrder;
    /** @var Customer */    private $customerPlacingOrder;
    /** @var string */      private $shippingAddress;
    /** @var Map */         private $orderItems;

    function getTotalAmount() : float {
        $total_amount= "0.00";
        foreach ($this->orderItems->values() as $oi)
            $total_amount = bcadd($total_amount, (string)($oi->getAmount()));
        return (float)$total_amount;
    }
    //...
}
