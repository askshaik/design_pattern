<?php
declare (strict_types=1);

class MainApp {
    /** @var string */    private $faxNo;
    function main(): void {
        $fax_machine = new FaxMachine($this->faxNo);
        $fax_machine->sendFax('783675', 'hello');
    }
    //...
}
class FaxMachine {
    /** @var string */    private $stationId;
    function __construct(string $stationId) {
        $this->stationId = $stationId;
    }
    function sendFax(string $toFaxNo, string $msg): void {
        $hardware = new FaxMachineHardware();
        $hardware->setStationId($this->stationId);
        $hardware->setRecipientFaxNo($toFaxNo);
        $hardware->start();
        $more_page_is_needed = true;
        try {
            do {
                $graphics = $hardware->newPage();
                //draw the message msg into the graphics.
            } while ($more_page_is_needed);
        } finally {
            $hardware->done();
        }
    }
}

