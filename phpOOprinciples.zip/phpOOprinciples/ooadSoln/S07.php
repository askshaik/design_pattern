<?php
declare (strict_types=1);
class Account {
    //...
}
class TimeRange {
    /** @var int */ private $fromHour;
    /** @var int */ private $toHour;
    /** @var int */ private $fromMinutes;
    /** @var int */ private $toMinutes;
    function __construct($fromHour, $toHour, $fromMinutes, $toMinutes) {
        //...
    }
    //....
}
class Restaurant extends Account {
    const RESTAURANT_ID_TEXT = 'Rest';
    /** @var string */    private $website;
    /** @var string */    private $chineseAddress;
    /** @var string */    private $englishAddress;
    /** @var string */    private $newFaxNumberToBeConfirmed;
    /** @var bool  */     private $hasNewFax = false;

    /** @var DateTime[] */  private $listOfHolidays;

    /** @var string */    private $catId;

    /** @var TimeRange[] */    private $businessHours;
    //...
    const BASE_YEAR = 1900;
    const HOURS_IN_A_DAY = 24;
    const MINUTES_IN_A_HOUR=60;

    function addHoliday(int $year, int $month, int $day): void {
        if ($year < self::BASE_YEAR) $year += self::BASE_YEAR;
        $a_holiday = new DateTime("{$year}-{$month}-{$day} 0:0:0", new DateTimeZone('UTC'));
        $this->listOfHolidays[] = $a_holiday;
    }
    private static function getMinutesFromMidnight(int $hours, int $minutes) : int {
        return $hours * self::MINUTES_IN_A_HOUR + $minutes;
    }
    private static function isMinutesWithinOneDay(int $minutes) : bool {
        return ($minutes >= 0) && ($minutes <= self::HOURS_IN_A_DAY * self::MINUTES_IN_A_HOUR);
    }
    function addBsHour(int $fromHour, int $fromMinute, int $toHour, int $toMinute): bool {
        $from_in_minutes = self::getMinutesFromMidnight($fromHour, $fromMinute);
        $to_in_minutes = self::getMinutesFromMidnight($toHour, $toMinute);
        $times_valid = self::isMinutesWithinOneDay($from_in_minutes) &&
                        self::isMinutesWithinOneDay($to_in_minutes) &&
                        $from_in_minutes < $to_in_minutes;
        if ($times_valid)
            $this->businessHours[] = new TimeRange($fromHour, $fromMinute, $toHour, $toMinute);
        return $times_valid;
    }
}
