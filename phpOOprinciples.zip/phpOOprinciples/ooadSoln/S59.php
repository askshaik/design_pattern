<?php
declare (strict_types=1);

class Order {
    /** @var string */    public $orderId;
    /** @var string */    public $customerId;
    /** @var string */    public $supplierId;
    /** @var DateTime */  public $orderDate;
    /** @var OrderLine[] */ public $orderLines = [];
    //...
}
class OrderLine {
    /** @var string */  public $productName;
    /** @var int */     public $quantity;
    //...
}
class Orders {
    /** @var Order[] */ public $orders = [];
    function placeOrder(string $customerId, string $supplierId, ...$misc) : void {
        //...
    }
    function printOrdersByCustomer(string $customerId) : void {
        //...
    }
    function printOrdersForSupplier(String $supplierId) : void {
        //...
    }
}
class Discount {
    /** @var string */  public $supplierId;
    /** @var string */  public $customerId;
    /** @var string */  public $productName;
    /** @var float */   public $discountRate;
}
class Discounts {
    /** @var Discount[] */  public $discounts = [];
    function addDiscount(string $supplierId, string $customerId, string $productName, float $discountRate) : void {
        //...
    }
    function findDiscount(string $supplierId, string $customerId, string $productName) : float {
        //...
        return 0;
    }
}
class SalesSystem {
    /** @var  Customer[]*/ public $customers;
    /** @var Supplier[] */ public $suppliers;
    /** @var Orders */     public $orders;
    /** @var Discounts */  public $discounts;
}
class Customer {
    /** @var string */    public $id;
    /** @var string */    public $name;
    /** @var string */    public $address;
}
class Supplier {
    /** @var string */    public $id;
    /** @var string */    public $name;
    /** @var string */    public $telNo;
    /** @var string */    public $address;
}
