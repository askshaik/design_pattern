<?php
declare (strict_types=1);
interface Courses {
    function getCoursesInSubject(string $subjectArea) : array;
}
class CoursesInDB implements Courses {
    function getCoursesInSubject(string $subjectArea): array {
        $dbConn = Database::getConnection();
        $courses = [];
        $st = $dbConn->prepareStatement('select * from Courses where subjArea=?');
        try {
            $st->setString(1, $subjectArea);
            $rs = $st->executeQuery();
            try {
                while ($rs->next()) {
                    $course_code = $rs->getString(1);
                    $course_name = $rs->getString(2);
                    $course_fee = $rs->getInt(3);
                    $courses[] = new Course($course_code, $course_name, $course_fee);
                }
            } finally {
                $rs->close();
            }
        } finally {
            $st->close();
            $dbConn->close();
        }
        return $courses;
    }
}

class ShowCoursesServlet extends HttpServlet {
    function doGet(HttpServletRequest $request, HttpServletResponse $response): void {
        $response->setContentType('text/html');
        $out = $response->getWriter();
        $out->println('<HTML><TITLE>Course listing</TITLE><BODY>');
        $courses = $this->getServletContext()->getAttribute('Courses');
        $courses_in_subject = $courses->getCoursesInSubject($request->getParameter('SubjArea'));
        $out->println('<TABLE>');
        foreach($courses_in_subject as $course) {
            $out->println('<TR>');
            $out->println('<TD>');
            $out->println($course->getCourseCode());
            $out->println('</TD>');
            $out->println('<TD>');
            $out->println($course->getCourseName());
            $out->println('</TD>');
            $out->println('<TD>');
            $out->println((string)$couse->getCouseFee);
            $out->println('</TD>');
            $out->println('</TR>');
        }
        $out->println('</TABLE>');
        $out->println('</BODY></HTML>');
    }
}
