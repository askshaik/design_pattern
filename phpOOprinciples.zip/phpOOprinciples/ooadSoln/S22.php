<?php
declare (strict_types=1);
class Account {
    //...
    function isComplexPassword(string $password): bool {
        return $this->containsLetter($password) &&
                    ($this->containsDigit($password) || $this->containsSymbol($password));
    }
    private function containsLetter(string $password) : bool {
        //...
    }
    private function containsDigit(string $password) : bool {
        //...
    }
    private function containsSymbol(string $password) : bool {
        //...
    }
}