<?php
declare (strict_types=1);
use \Ds\Map;

class FoodDB {
    function FoodsContainingNames(String $cName, String $eName): iterable {
        $food_tree_result = new Map();
        $food_list = $this->getAllRecords();
        foreach ($food_list as $food)
            if ($this->nameMatchKeyword($food->getCName, $cName) &&
                    $this->nameMatchKeyword($food->getEName, $eName))
                $food_tree_result->put($food->getFoodKey(), $food);
        return $food_tree_result->values();
    }
    private function nameMatchKeyword(string $name, string $keyword) : bool {
        return $keyword === null || $keyword === '' || strpos($name, $keyword) !== false;
    }
    //...
}