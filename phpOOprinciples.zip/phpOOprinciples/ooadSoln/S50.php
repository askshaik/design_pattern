<?php
declare (strict_types=1);

abstract class Account1 {
    /** @var float */ protected $balance;
    abstract function calcInterest(): float;
    function getInterestRate() {
        //...
    }
}
class SavingsAccount extends Account1 {
    function calcInterest(): float {
        return $this->balance * $this->getInterestRate();
    }

}
class ChequeAccount extends Account1 {
    function calcInterest(): float {
        return 0;
    }
}
class FixedAccount extends Account1 {
    function calcInterest(): float {
        return $this->balance * ($this->getInterestRate() + 0.02);
    }
}