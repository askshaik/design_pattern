<?php
declare (strict_types=1);
class TelNo {
    /** @var string */ private $countryCode;
    /** @var string */ private $areaCode;
    /** @var string */ private $localNumber;
    //...
}
class PersonName {
    /** @var string */ private $firstName; //First name and last name in English
    /** @var string */ private $lastName;
    //...
}
class ContactPerson {
    /** @var PersonName */ private $englishName;
    /** @var PersonName */ private $chineseName;
    /** @var TelNo */ private $telNo;
    /** @var TelNo */ private $faxNo;
    /** @var TelNo */ private $mobileNo;
    //...
}
class Organization {
    /** @var string */ private $id;
    /** @var string */ private $englishName;
    /** @var string */ private $chineseName;
    /** @var TelNo */ private $telNo;
    /** @var TelNo */ private $faxNo;
    /** @var ContactPerson */ private $contactPerson;
    //...
}
