<?php
declare (strict_types=1);
class ConferenceDBConnection {
    /** @var Connection */ static private $db = null;
    static function makeConnection() : Connection {
        if (self::db === null) self::openDatabase();
        return self::$db;
    }
    static function openDatabase() : void {
        Driver::load('org.postgresql.Driver');
        self::$db = DriverManager::getConnection('jdbc:postgresql://myhost/ConferenceDB', 'PaulChan', 'myP@ssword');
    }
}
class ParticipantsInDB {
    /** @var Connection */    private $db;
    function __construct() {
        $this->db = ConferenceDBConnection::makeConnection();
    }
    function addParticipant(Participant $part): void {
        $st = $this->db->prepareStatement('INSERT INTO participants VALUES (?,?,?,?,?,?,?)');
        try {
            $st->setString(1, $part->getId());
            $st->setString(2, $part->getEFirstName());
            $st->setString(3, $part->getELastName());
            //...
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
}
class OrganizationsInDB {
    /** @var Connection */    private $db;
    function __construct() {
        $this->db = ConferenceDBConnection::makeConnection();
    }
    function addOrganization(Organization $o): void {
        $st = $this->db->prepareStatement('INSERT INTO organizations VALUES (?,?,?,?,?,?,?,?,?,?,)');
        try {
            $st->setString(1, $o->getId());
            $st->setString(2, $o->getEName());
            $st->setString(3, $o->getCName());
            //...
            $st->executeUpdate();
        } finally {
            $st->close();
        }
    }
}
