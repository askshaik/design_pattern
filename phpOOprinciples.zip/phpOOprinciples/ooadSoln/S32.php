<?php
declare (strict_types=1);

class FoodSalesReport {
    /** @var int */    private $riceSold;
    /** @var int */    private $noodlesSold;
    /** @var int */    private $drinkSold; //how many items of drink sold?
    /** @var int */    private $dessertSold; //how many items of dessert sold?

    function LoadData(Connection $conn): void {
        $st = $conn->prepareStatement(self::SQL_S);
        try {
            $rs = $st->executeQuery();
            $rs->next();
            $col=1;
            $this->riceSold = $rs->getInt($col++);
            $this->noodlesSold = $rs->getInt($col++);
            $this->drinkSold = $rs->getInt($col++);
            $this->dessertSold = $rs->getInt($col);
        } finally {
            if (isset($rs)) $rs->close();
            $st->close();
        }
    }
    const RICE_CODE = 0, NOODLE_CODE = 1, DRINK_CODE = 2, DESSERT_CODE = 3,
        SUM_CASE='sum(case when foodType=',
        QTY_IF=' then qty else 0 end)';
    const SQL_S = 'select '.self::SUM_CASE.self::RICE_CODE.QTY_IF .','.
                            self::SUM_CASE.self::NOODLE_CODE_CODE.QTY_IF.','.
                            self::SUM_CASE.self::DRINK_CODE_CODE.QTY_IF.','.
                            self::SUM_CASE.self::DESSERT_CODE_CODE.QTY_IF .
                            'from foodSalesTable group by foodType';
}
