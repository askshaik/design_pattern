<?php
declare (strict_types=1);
use \Ds\Map;

class Restaurant {
    /** @var string */    public $name;
    /** @var string */    public $password;
    /** @var string */    public $telNo;
    /** @var string */    public $faxNo;
    /** @var string */    public $address;
}
abstract class RestaurantTaskActivator {
    /** @var string */    public $verificationCode;
    /** @var Restaurant */ public $restaurant;
    function tryToActivate(string $restaurantName, string $verficationCode) : bool {
        if ($this->restaurant->name === $restaurantName && $this->verificationCode === $verficationCode) {
            $this->doSomethingToRestaurant();
            return true;
        }
        return false;
    }
    abstract function doSomethingToRestaurant() : void;
}
class RestaurantActivator extends RestaurantTaskActivator {
    function doSomethingToRestaurant(): void {
        //Add Restaurant to System.
    }
    //....
}
class FaxNoActivator extends RestaurantTaskActivator {
    /** @var string */    public $newFaxNo;
    function doSomethingToRestaurant(): void {
        $this->restaurant->setFaxNo($this->newFaxNo);
    }
    //....
}
class RestaurantTaskActivators {
    /** @var RestaurantTaskActivator[] */ public $activators = [];
    function activate (string $restaurantName, string $verficationCode) : void {
        foreach($this->activators as $i=>$r)
            if ($r->tryToActivate($restaurantName, $verficationCode)) {
                unset($this->activators[$i]);
                return;
            }
    }
}
class Category {
    /** @var string */    public $catId;
    //...
}
class Holidays {
    /** @var DateTime[] */ public $holidays = [];
    function addHoliday(int $year, int $month, int $day): void {
        //...
    }
    function removeHoliday(int $year, int $month, int $day): void {
        //...
    }
    function getAllHolidays(): array {
        return $this->holidays;
    }
}
class BusinessSessions {
    /** @var DateTime[] */ public $businessSessions = [];
    function addBusinessSession(int $fromHour, int $fromMin,
                                int $toHour, int $toMin): bool {
        //...
        return true;
    }
    function isInBusinessHour(DateTime $time): void {
        //...
    }
    function getAllBusinessSessions(): array {
        return $this->businessSessions;
    }
}
class RestaurantSystem {
    /** @var Restaurant[] */ public $restaurants = [];
    /** @var RestaurantTaskActivators */ public $restaurantTaskActivators;
    /** @var Map */ public $mapOfRestToCategories; //Restaruant => Category[]
    /** @var Map */ public $mapOfRestToHolidays; //Restaruant => Holidays
    /** @var Map */ public $mapOfRestToBusinessSessions; //Restaruant => BusinessSessions
}
