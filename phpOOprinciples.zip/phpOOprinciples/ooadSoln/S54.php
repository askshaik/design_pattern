<?php
declare (strict_types=1);
interface Account {
    function canLogin() : bool;
}
class UserAccount implements Account {
    /** @var DateTime */    private $expiredDate;
    function canLogin(): bool {
        return $this->isAccountExpired();
    }
    private function isAccountExpired() : bool {
        $now = new DateTime();
        return $this->expiredDate >= $now;
    }
    //...
}
class AdminAccount implements Account {
    /** @var bool */    private $hasLogin;
    function canLogin(): bool {
        return !$this->isTryingMultiLogin();
    }
    private function isTryingMultiLogin() : bool {
        return $this->hasLogin;
    }
    //...
}
class ERPApp {
    function checkLoginIssue(Account $account): bool {
        return $account->canLogin();
    }
}
