<?php
declare (strict_types=1);
class Order {
    /** @var string */     private $orderId;
    /** @var string */     private $customerId;
    /** @var string */     private $restId;
    /** @var OrderItem[] */private $items;
    //functions, getters, setters.
}
class OrderItem {
    /** @var string */ private $foodId;
    /** @var int */    private $quantity;
    /** @var float */  private $unitPrice;
    //functions, getters, setters.
}
interface Orders {
    function addOrder(Order $order) : void;
    function deleteOrder(string $orderId) : void;
    function updateOrder(Order $order) : void;
    function getOrdersById() : array;
}
class OrdersInDB implements Orders {
    private $dbConn;
    function addOrder(Order $order): void {
        $st = $this->dbConn->prepareStatement('insert into from Orders values(?,?,?)');
        try {
            $st->setString(1, $order->getId());
            $st->setString(2, $order->getCustomerId());
            $st->setString(3, $order->getRestId());
            $st->executeUpdate();
        } finally {
            $st->close();
        }
		$st = $this->dbConn->prepareStatement('insert into from OrderItems values(?,?,?,?,?)');
		try {
		    $i = 1;
		    foreach($order->items as $orderItem) {
				$st->setString(1, $order->getId());
				$st->setInt(2, $i++);
				$st->setString(3, $orderItem->getFoodId());
				$st->setInt(4, $orderItem->getQuantity());
				$st->setDouble(5, $orderItem->getUnitPrice());
				$st->executeUpdate();
			}
		} finally {
            $st->close();
        }
    }
    //Other functions will be similar.
}