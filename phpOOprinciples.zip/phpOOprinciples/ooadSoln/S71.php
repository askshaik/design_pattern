<?php
use \Ds\Map;

class CourseCatalog {
    /** @var Map */ private $map;
    function addCourse(Course $c): void {
        $this->map->put($c->getTitle(), $c);
    }
    function findCourse(string $title): Course {
        return $this->map->get($title);
    }
    function countCourses(): int {
        return $this->map->count();
    }
    //...
}
