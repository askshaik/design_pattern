#include <iostream>
using namespace std;
namespace composite {
class DiskObject {
	public:
	virtual int getSize() = 0;
	virtual void deleteFromDisk() = 0;
};
class File : public DiskObject {
	char *name;
	int size;
	public:
	File(char *name1, int size1) {
		name = name1; size = size1;
	}
	int getSize() { return size; }
	void deleteFromDisk() { cout << name << " deleted.\n"; }
};
class Directory : public DiskObject {
	char *name;
	DiskObject *children[10];
	int totalChildren;
	public:
	Directory (char *name1) {
		name = name1; totalChildren = 0;
	}
	void addChild(DiskObject *c) {
		children[totalChildren++] = c;
	}
	int getSize() {
		int totalSize = 0;
		for (int i=0; i<totalChildren; ++i)
			totalSize += children[i]->getSize();
		return totalSize;
	}
	void deleteFromDisk() {
		for (int i=0; i<totalChildren; ++i)
			children[i]->deleteFromDisk();
		cout << name << " deleted.\n";
	}
};
void printLengthAndDelete(DiskObject *d) {
	cout << "Size is " << d->getSize() << endl;
	d->deleteFromDisk();
}
}
void composite_main() {
	using namespace composite;
	File *f1 = new File ("abc", 50);
	File *f2 = new File ("ghi", 20);
	File *f3 = new File ("xyz", 30);
	Directory *d1 = new Directory ("d1");
	d1->addChild(f1);
	d1->addChild(f2);
	Directory *d2 = new Directory ("d1");
	d2->addChild(d1);
	d2->addChild(f3);
	printLengthAndDelete(d2);
}

