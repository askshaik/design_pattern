#include <iostream>
#include <vector>
namespace strategy {
using namespace std;
class Flyable {
public:
	virtual void fly(int x1, int y1, int x2, int y2) const = 0;
	virtual ~Flyable() {}
};
class Fly_with_wings : public Flyable {
public:
	void fly(int x1, int y1, int x2, int y2) const override {
		cout << "Flying from (" << x1 << "," << y1
					<< ") to ("	<< x2 << "," << y2
					<< ")" << endl;
	}
};
class Fly_no : public Flyable {
public:
	void fly(int x1, int y1, int x2, int y2) const override {}
};
class Quackable {
public:
	virtual void make_sound() const = 0;
	virtual ~Quackable() {}
};
class Quack_normal :public Quackable {
public:
	void make_sound() const override {
		cout << "Quack" << endl;
	}
};
class Quack_squeck :public Quackable {
public:
	void make_sound() const override {
		cout << "Squeck" << endl;
	}
};
class Quack_None :public Quackable {
public:
	void make_sound() const override {}
};
class Duck {
Flyable *f;
Quackable *q;
public:
	Duck(Duck&) = delete;
	Duck& operator=(Duck&) = delete;
	Duck(Flyable *f1, Quackable *q1) : f(f1), q(q1) {}
	void swim() const { cout << "Duck swimming" << endl; }
	virtual void display(int x, int y) const = 0;
	void make_sound() const { q->make_sound(); }
	void fly(int x1, int y1, int x2, int y2) { f->fly(x1, y1, x2, y2); }
	virtual ~Duck() { delete f; delete q; }
};
class Red_head_duck  : public Duck {
public:
	Red_head_duck() : Duck(new Fly_with_wings(), new Quack_normal()) {}
	void display(int x, int y) const override {
		cout << "Red head duck displayed at ("
				<< x << "," << y << ")" << endl;
	}
};
class Decoy_duck  : public Duck {
public:
	Decoy_duck() : Duck(new Fly_no(), new Quack_None()) {}
	void display(int x, int y) const override {
		cout << "Decoy duck displayed at ("
				<< x << "," << y << ")" << endl;
	}
};
class Rubber_duck  : public Duck {
public:
	Rubber_duck() : Duck(new Fly_no(), new Quack_squeck()) {}
	void display(int x, int y) const override {
		cout << "Decoy duck displayed at ("
				<< x << "," << y << ")" << endl;
	}
};
class White_small_duck  : public Duck {
public:
	White_small_duck() : Duck(new Fly_no(), new Quack_normal()) {}
	void display(int x, int y) const override {
		cout << "Decoy duck displayed at ("
				<< x << "," << y << ")" << endl;
	}
};
}
void strategy_main() {
	using namespace strategy;
	vector<Duck *> ducks;
	ducks.push_back( new Red_head_duck ());
	ducks.push_back( new Decoy_duck());
	ducks.push_back (new Rubber_duck());
	ducks.push_back (new White_small_duck());
	for(auto d : ducks)
	{
		d->display(1,1);
		d->swim();
		d->make_sound();
		d->fly(2,3,4,5);
	}
	for (auto a=ducks.begin(); a!=ducks.end(); a=ducks.erase(a))
		delete *a;
}
