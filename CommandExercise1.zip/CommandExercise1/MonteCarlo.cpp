#include <iostream>
#include <thread>
#include <algorithm>
#include <vector>
#include <random>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include <functional>
using namespace std;
namespace monte_carlo {
	static mutex lock;
	static const int MAX_DICE_VALUE = 6;
	static const int ARRAY_SIZE = MAX_DICE_VALUE * 2 + 1;
	volatile long values_accumulated[ARRAY_SIZE];
	class Dice_probablity {
		long values_thrown[ARRAY_SIZE];
		int dice_throw() {
			return rand() % MAX_DICE_VALUE + 1;
		}
		void throw_two_dices() {
			++values_thrown[dice_throw() + dice_throw()];
		}
		void accumulate_total() {
		    lock_guard<mutex> guard(lock);
			for (int i=0; i<ARRAY_SIZE; ++i)
				values_accumulated[i] += values_thrown[i];
		}
		Dice_probablity() {
			for (int i=0; i<ARRAY_SIZE; ++i) values_thrown[i] = 0;
		}
	public:
		static void compute(long start, long end) {
			Dice_probablity dc;
			for (long i=start; i<end; ++i)
				dc.throw_two_dices();
			dc.accumulate_total();
		}
		static void print() {
			double sum = 0;
			for (int i=0; i<ARRAY_SIZE; ++i) sum+=values_accumulated[i];
			for (int dice_throw=2; dice_throw < ARRAY_SIZE; ++dice_throw)
				cout << "The probablity of " << dice_throw << " is "
					<< (values_accumulated[dice_throw]/sum) << endl;

		}
	};
}
using namespace monte_carlo;
void monte_carlo_main() {
	int number_of_processors = thread::hardware_concurrency();
	const long TOTAL_COMPUTES = 10000000;
	srand(time(0));
    std::vector<std::thread> threads;
	for(auto i=0;i<number_of_processors;++i) {
		auto start = i * TOTAL_COMPUTES / number_of_processors;
		auto end = start + TOTAL_COMPUTES /number_of_processors;
		threads.push_back(std::thread(Dice_probablity::compute, start, end));
	}
	for_each(threads.begin(),threads.end(), mem_fn(&thread::join))
		;
	Dice_probablity::print();
}
