#include <iostream>
using namespace std;
namespace state {
	class State;
	class Gumball_machine {
		State *s = nullptr;
		void update_state(State *next_state) {
			if (next_state != s) delete s;
			s = next_state;
		}
	public:
		int gumballs_remaining;  //getter and setter can be provided.
		Gumball_machine(int gumballs);
		void coin_inserted();
		void lever_turned();
		void eject_pressed();
		~Gumball_machine() { delete s; }
	};
	class State {
	public:
		virtual State *coin_inserted() {
			cout << "Refund Coin" << endl;
			return this;
		}
		virtual State *lever_turned(Gumball_machine& gm) {
			return this;
		}
		virtual State *eject_pressed() {
			return this;
		}
		virtual ~State() {}
	};
	class No_quater_state : public State {
	public:
		State *coin_inserted() override;
	};
	class Has_quater_state : public State {
	public:
		State *lever_turned(Gumball_machine& gm) override;
		State *eject_pressed() override;
	};
	class Sold_out_state : public State {
	};
	State *No_quater_state::coin_inserted() {
		return new Has_quater_state();
	}
	State *Has_quater_state::lever_turned(Gumball_machine& gm) {
		cout << "Gumball Dispensed" << endl;
		if (--gm.gumballs_remaining > 0) return new No_quater_state();
		return new Sold_out_state();
	}
	State *Has_quater_state::eject_pressed() {
		cout << "Coin refunded" << endl;
		return new No_quater_state();
	}
	Gumball_machine::Gumball_machine(int gumballs)
	 : gumballs_remaining(gumballs)
	{
		s = new No_quater_state();
	}
	void Gumball_machine::coin_inserted() {
		update_state(s->coin_inserted());
	}
	void Gumball_machine::lever_turned() {
		update_state(s->lever_turned(*this));
	}
	void Gumball_machine::eject_pressed() {
		update_state(s->eject_pressed());
	}
}
void state_main() {
	using namespace state;
	Gumball_machine gm(2);
	gm.coin_inserted();
	gm.eject_pressed();
	gm.coin_inserted();
	gm.lever_turned();
	gm.coin_inserted();
	gm.lever_turned();
	gm.coin_inserted();
}
