#include <iostream>
using namespace std;
namespace cmd {
class Command {
	public:
	virtual void execute() = 0;
	virtual void undo() = 0;
};
class Light {
	public:
	void switchOnLight() { cout << "Light on" ; }
	void switchOffLight() { cout << "Light off" ; }
};
class LightOn : public Command {
	Light *l;
	public:
	LightOn(Light *l1) { l = l1; }
	void execute() { l->switchOnLight(); }
	void undo() { l->switchOffLight(); }
};
class LightOff : public Command {
	Light *l;
	public:
	LightOff(Light *l1) { l = l1; }
	void execute() { l->switchOffLight(); }
	void undo() { l->switchOnLight(); }
};

Command *buttonsPressed[100];
int position = 0;
void buttonPressed(Command *button) {
	buttonsPressed[position++] = button;
	button->execute();
}
void undo() {
	Command *lastButton = buttonsPressed[--position];
	lastButton->undo();
}
}
void command_main() {
	using namespace cmd;
	Light light;
	Command *button1 = new LightOn(&light);
	//buttonPressed(button1);
	Command *button2 = new LightOff(&light);
	buttonPressed(button2);
	//undo();
	undo();
}





