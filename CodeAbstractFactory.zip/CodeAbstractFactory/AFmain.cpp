#include <iostream>
#include "pizzaFactory.h"
using namespace af;
void makePizza(PizzaFactory &pf) {
	Crust *cr = pf.createCrust(TypeOfCrust::THICK);
	Cheese *ch = pf.createCheese(TypeOfCheese::MOZZARELLA);
	Veggies *ve = pf.createVeggies(TypeOfVeggies::SPICY);
	cr->useBase();
	ch->addFat();
	ve->addGreen();
	std::cout << "Pizza Ready" << std::endl;
	delete cr;
	delete ch;
	delete ve;
}
void af_main() {
	MumbaiPizzaFactory mpf; //If pizza store in Mumbai
	makePizza(mpf);
}
