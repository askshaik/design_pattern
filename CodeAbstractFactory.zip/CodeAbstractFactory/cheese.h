#include <iostream>
namespace af {
class Cheese {
	public:
	virtual void addFat() = 0;
	virtual ~Cheese() {}
};
class MozzarellaCheese : public Cheese {
	public:
	void addFat() {
		std::cout << "Mozzarella Cheese added." << std::endl;
	}
};
class ReggianoCheese : public Cheese {
	public:
	void addFat() {
		std::cout << "Reggiano Cheese added." << std::endl;
	}
};
enum class TypeOfCheese { MOZZARELLA, REGGIANO };
}
