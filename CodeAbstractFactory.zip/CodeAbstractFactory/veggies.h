#include <iostream>
namespace af {
class Veggies {
	public:
	virtual void addGreen() = 0;
	virtual ~Veggies() {}
};
class StandardVeggies : public Veggies {
	public:
	void addGreen() {
		std::cout << "Normal Vegetables used." << std::endl;
	}
};
class SpicyVeggies : public Veggies {
	public:
	void addGreen() {
		std::cout << "Green chillies used." << std::endl;
	}
};
class JainVeggies : public Veggies {
	public:
	void addGreen() {
		std::cout << "No Onions used." << std::endl;
	}
};

enum class TypeOfVeggies { STANDARD, SPICY, JAIN };
}
