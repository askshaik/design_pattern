#include "crust.h"
#include "cheese.h"
#include "veggies.h"
namespace af {
class PizzaFactory {
	public:
	virtual Crust *createCrust(TypeOfCrust t) = 0;
	virtual Cheese *createCheese(TypeOfCheese t) = 0;
	virtual Veggies *createVeggies(TypeOfVeggies t) = 0;
	virtual ~PizzaFactory() {}
};
class PunePizzaFactory : public PizzaFactory {
	public:
	Crust *createCrust(TypeOfCrust t) {
		//Pune has only Thick crust. So ignore type
		return new ThickCrust();
	}
	Cheese *createCheese(TypeOfCheese t) {
		//Pune has only Mozzarella Cheese. So ignore type
		return new MozzarellaCheese();
	}
	Veggies *createVeggies(TypeOfVeggies t) {
		//Pune has all the Veggies
		switch(t){
		case TypeOfVeggies::SPICY: return new SpicyVeggies();
		case TypeOfVeggies::JAIN: return new JainVeggies();
		default: return new StandardVeggies();
		}
	}
};
class MumbaiPizzaFactory : public PizzaFactory {
	public:
	Crust *createCrust(TypeOfCrust t) {
		//Mumbai has only Thin crust. So ignore type
		return new ThinCrust();
	}
	Cheese *createCheese(TypeOfCheese t) {
		if (t == TypeOfCheese::MOZZARELLA) return new MozzarellaCheese();
		return new ReggianoCheese();
	}
	Veggies *createVeggies(TypeOfVeggies t) {
		//Mumbai has only Standard and Jain Veggies
		if (t == TypeOfVeggies::JAIN) return new JainVeggies();
		return new StandardVeggies();
	}
};
class GeneralPizzaFactory : public PizzaFactory {
	public:
	Crust *createCrust(TypeOfCrust t) {
		if (t == TypeOfCrust::THICK) return new ThickCrust;
		return new ThinCrust();
	}
	Cheese *createCheese(TypeOfCheese t) {
		if (t == TypeOfCheese::MOZZARELLA) return new MozzarellaCheese();
		return new ReggianoCheese();
	}
	Veggies *createVeggies(TypeOfVeggies t) {
		switch(t){
		case TypeOfVeggies::SPICY: return new SpicyVeggies();
		case TypeOfVeggies::JAIN: return new JainVeggies();
		default: return new StandardVeggies();
		}
	}
};
}
