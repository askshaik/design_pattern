#include <iostream>
namespace af {
class Crust {
	public:
	virtual void useBase() = 0;
	virtual ~Crust() {}
};
class ThickCrust : public Crust {
	public:
	void useBase() {
		std::cout << "Thick Crust used" << std::endl;
	}
};
class ThinCrust : public Crust {
	public:
	void useBase() {
		std::cout << "Thin Crust used" << std::endl;
	}
};
enum class TypeOfCrust { THICK, THIN };
}
