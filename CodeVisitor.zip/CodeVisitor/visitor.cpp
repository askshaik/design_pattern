#include <iostream>;
#include <vector>;
#include <string>
using namespace std;
namespace visitor {
	class Salaried_employee;
	class Hourly_employee;
	class Employee_visitor {
	public:
		virtual void visit(const Hourly_employee &he) const = 0;
		virtual void visit(const Salaried_employee &se) const = 0;
		virtual ~Employee_visitor() {}
	};
	class Employee {
		const string name;
	public:
		Employee(char *name1) : name(name1){}
		virtual void visit (const Employee_visitor &v) const = 0;
		~Employee() {}
		const string &get_name() const { return name; }
	};
	class Salaried_employee : public Employee {
		int salary;
	public:
		Salaried_employee(char *name, int salary1) :
			Employee(name), salary(salary1) {}
		void visit(const Employee_visitor &v) const override {
			v.visit(*this);
		}
		int get_salary() const { return salary; }
	};
	class Hourly_employee : public Employee {
		int hours;
	public:
		Hourly_employee(char *name, int hours1) :
			Employee(name), hours(hours1) {}
		void visit(const Employee_visitor &v) const override {
			v.visit(*this);
		}
		int get_hours() const { return hours; }
	};
	class Employee_report_visitor : public Employee_visitor {
		void visit(const Hourly_employee &he) const override {
			cout << "Hourly " << he.get_name() << " worked for "
					<< he.get_hours() << " hours." << endl;
		}
		void visit(const Salaried_employee &se) const override {
			cout << "Salaried " << se.get_name() << " earns "
					<< se.get_salary() << "." << endl;
		}
	public:
		void print_employees(const vector<Employee *> emps) const {
			for (auto e : emps)
				e->visit(*this);
		}
	};
}
void visitor_main() {
	using namespace visitor;
	Hourly_employee he("Bob", 8);
	Salaried_employee se("Bill", 350);
	vector<Employee *> emps = {&he, &se};
	Employee_report_visitor rv;
	rv.print_employees(emps);
}
