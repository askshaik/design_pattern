#include <iostream>
using namespace std;
//This code will work in c++11 or higher
class Singleton {
	Singleton() {}  //Object cannot be created
	~Singleton() {} //Object cannot be deleted
	public:
	void process() { cout << "Singleton used\n"; }
	static Singleton *getInstance();
};
Singleton *Singleton::getInstance() {
	static Singleton instance; //Singleton will be created the first time function invoked.
	return &instance;          //Thread-safety of singleton creation guaranteed by C++11
}
void singleton_main() {
	Singleton *a = Singleton::getInstance();
	a->process();
	Singleton *b = Singleton::getInstance();
	std::cout << "Are both Singletons same? " << ((a==b)?"Yes":"No") << std::endl;
}
