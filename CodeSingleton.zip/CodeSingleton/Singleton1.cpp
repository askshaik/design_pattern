#include <iostream>
#include <boost/thread.hpp>

//This code is needed for old C++ systems.
class Singleton1 {
	Singleton1() {}  //Object cannot be created
	~Singleton1() {} //Object cannot be deleted
	static Singleton1 *instance;
	public:
		void process() { std::cout << "Singleton used\n"; }
		static Singleton1 *getInstance();
};
static boost::mutex lock;
Singleton1 *Singleton1::getInstance() {
	static  Singleton1* volatile instance = 0;
	boost::lock_guard<boost::mutex> guard(lock);
	if (!instance) instance = new Singleton1();
	return instance;
}
void singleton1_main() {
	Singleton1 *a = Singleton1::getInstance();
	a->process();
	Singleton1 *b = Singleton1::getInstance();
	std::cout << "Are both Singletons same? " << ((a==b)?"Yes":"No") << std::endl;
}
