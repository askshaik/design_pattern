#include <math.h>
#include "TaxBandGenerator.h"
class NewZealandTaxBandGenerator : public TaxBandGenerator {
	public: 
	vector<TaxBand *> *CreateTaxBands() {
		vector<TaxBand *> *taxBands = new vector<TaxBand *>();
		taxBands->push_back(new TaxBand(0.0, 19500.99, 0.195));
		taxBands->push_back(new TaxBand(19501.00, 60000.99, 0.33));
		taxBands->push_back(new TaxBand(60001.00, MAXFLOAT, 0.39));
		return taxBands;
	}
};
