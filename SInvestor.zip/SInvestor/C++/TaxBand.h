class TaxBand {
	static const double ZeroValue = 0.0;
	double lowerLimitAmount;
	double upperLimitAmount;
	double taxRate;
	bool FallWithinTaxBand(double income) {
		return EqualToOrGreaterThan(income, lowerLimitAmount)
		        && EqualToOrLessThan(income, upperLimitAmount);
	}
	bool EqualToOrGreaterThan(double income, double bandValue) {
		return income >= bandValue;
	}
	bool EqualToOrLessThan(double income, double bandValue) {
		return income <= bandValue;
	}
	public:
	TaxBand(double lowerLimitAmount, double upperLimitAmount,
	        double taxRate) {
		this->lowerLimitAmount = lowerLimitAmount;
		this->upperLimitAmount = upperLimitAmount;
		this->taxRate = taxRate;
	}
	double CalculateTaxPortion(double income) {
		if (EqualToOrLessThan(income, lowerLimitAmount))
			return ZeroValue;
		else if (FallWithinTaxBand(income))
			return (income - lowerLimitAmount) * taxRate;
		else if (EqualToOrGreaterThan(income, upperLimitAmount))
			return (upperLimitAmount - lowerLimitAmount) * taxRate;
		else
			return ZeroValue;
	}
	double getTaxRate() {
		return taxRate;
	}
	double getLowerLimitAmount() {
		return lowerLimitAmount;
	}
	double getUpperLimitAmount() {
		return upperLimitAmount;
	}
};
