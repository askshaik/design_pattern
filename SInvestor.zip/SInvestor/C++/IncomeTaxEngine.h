#include <string>
#include <vector>
#include "TaxBandGenerator.h"
using namespace std;
class IncomeTaxEngine {
	vector<TaxBand *> *taxBands;
	public: 
	IncomeTaxEngine(string cultureInfo = "") {
		taxBands = TaxBandGenerator::CreateInstance(cultureInfo)
		        ->CreateTaxBands();
	}
	double CalculateTaxLiability(double income) {
		double taxLiability = 0;
		for (unsigned int i=0; i < taxBands->size(); ++i)
			taxLiability += taxBands->at(i)->CalculateTaxPortion(income);
		return taxLiability;
	}
	double CalculateTaxRate(double income) {
		TaxBand *selectedBand = 0;
		for (unsigned int i=0; i < taxBands->size(); ++i)
			if (income >= taxBands->at(i)->getLowerLimitAmount()
			        && income <= taxBands->at(i)->getUpperLimitAmount())
				selectedBand = taxBands->at(i);
		return selectedBand->getTaxRate();
	}
};
