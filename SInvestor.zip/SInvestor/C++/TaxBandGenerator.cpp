#include "TaxBandGenerator.h"
TaxBandGenerator *TaxBandGenerator::CreateInstance(string cultureInfo) {
	if (cultureInfo == "en-NZ")
		return 0; //new NewZealandTaxBandGenerator();
	else if (cultureInfo == "en-AU")
		return 0; //new AustralianTaxBandGenerator();
	else if (cultureInfo == "en-US")
		return 0; //new UsaTaxBandGenerator();
	else
		return 0; //new NullTaxBandGenerator();
}
TaxBandGenerator *TaxBandGenerator::CreateInstance() {
	return TaxBandGenerator::CreateInstance("");
}
