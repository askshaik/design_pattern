#include "TaxBand.h"
//Can move some functions here
