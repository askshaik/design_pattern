#include <math.h>
#include "TaxBandGenerator.h"
class AustralianTaxBandGenerator : public TaxBandGenerator {
	public: 
	vector<TaxBand *> *CreateTaxBands() {
		vector<TaxBand *> *taxBands = new vector<TaxBand *>();
		taxBands->push_back(new TaxBand(0.0, 6000.99, 0.0));
		taxBands->push_back(new TaxBand(6001.00, 25000.99, 0.15));
		taxBands->push_back(new TaxBand(25001.00, 75000.99, 0.30));
		taxBands->push_back(new TaxBand(75001.00, 150000.99, 0.40));
		taxBands->push_back(new TaxBand(150001.00, MAXFLOAT, 0.45));
		return taxBands;
	}
};
