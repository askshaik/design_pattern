#include <math.h>
#include "TaxBandGenerator.h"
class NullTaxBandGenerator : public TaxBandGenerator {
	public:
	vector<TaxBand *> *CreateTaxBands() {
		vector<TaxBand *> *taxBands = new vector<TaxBand *>();
		taxBands->push_back(new TaxBand(0.0, MAXFLOAT, 0.0));
		return taxBands;
	}
};
