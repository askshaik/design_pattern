#include "NullTaxBandGenerator.h"
