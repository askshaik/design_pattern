#include <string>
#include <vector>
#include "TaxBand.h"
using namespace std;

class TaxBandGenerator {
	public:
	static TaxBandGenerator *CreateInstance(string cultureInfo);
	static TaxBandGenerator *CreateInstance(); 
	virtual vector<TaxBand *> *CreateTaxBands() = 0;
};
