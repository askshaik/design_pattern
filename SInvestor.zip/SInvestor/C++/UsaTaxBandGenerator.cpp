#include "UsaTaxBandGenerator.h"
