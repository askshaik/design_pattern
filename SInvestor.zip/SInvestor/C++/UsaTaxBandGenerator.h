#include <math.h>
#include "TaxBandGenerator.h"
class UsaTaxBandGenerator : public TaxBandGenerator {
	public: 
	vector<TaxBand *> *CreateTaxBands() {
		vector<TaxBand *> *taxBands = new vector<TaxBand *>();
		taxBands->push_back(new TaxBand(0.0, 7550.99, 0.10));
		taxBands->push_back(new TaxBand(7551.00, 30650.99, 0.15));
		taxBands->push_back(new TaxBand(30651.00, 74200.99, 0.25));
		taxBands->push_back(new TaxBand(74201.00, 154800.99, 0.28));
		taxBands->push_back(new TaxBand(154801.00, 336550.99, 0.33));
		taxBands->push_back(new TaxBand(336551.00, MAXFLOAT, 0.35));
		return taxBands;
	}
};
