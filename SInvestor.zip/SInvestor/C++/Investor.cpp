#include "IncomeTaxEngine.h"
class Investor {
	double income;
	IncomeTaxEngine taxEngine; 
	public: 
	Investor(double income) {
		this->income = income;
	}
	double getIncome() {
		return income;
	}
	void setIncome(double income) {
		this->income = income;
	}
	double getTaxLiability() {
		return taxEngine.CalculateTaxLiability(income);
	}
	double getTaxRate() {
		return taxEngine.CalculateTaxRate(income);
	}
	void setTaxEngine(IncomeTaxEngine taxEngine) {
		this->taxEngine = taxEngine;
	}
};
