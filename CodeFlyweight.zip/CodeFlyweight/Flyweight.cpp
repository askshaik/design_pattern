#include <iostream>
#include <unordered_set>
using namespace std;
class Point1 {
private:
	int x, y;
public:
	Point1(int x1, int y1) : x(x1), y(y1) {} 
	int getX() const { return x; }
	int getY() const { return y; }
	void setX(int x1) { x = x1; }
	void setY(int y1) { y = y1; }
	void move(int dx, int dy)  {
		x += dx;
		y += dy;
	}
	ostream &print(ostream &of) const {
		return of << "x=" << x << " y=" << y;
	}
	bool operator == (const Point1 &p) const {
		return p.x == x && p.y == y;
	}
	virtual ~Point1() {}
	static size_t hashcode(const Point1& p) {
		return (33 * p.x) ^ p.y;
	}
};
class Point2 {
	private:
	const int x, y;
	public:
	Point2(int x1, int y1) : x(x1), y(y1) {}  //No implicit conversions while calling constructor.
	int getX() const { return x; }
	int getY() const { return y; }
	Point2 &move(int dx, int dy) const {
		return * new Point2(x+dx, y+dy);
	}
	ostream &print(ostream &of) const {
		return of <<"x="<< x << " y=" << y;
	}
	bool operator == (const Point2 &p) const {
		return p.x == x && p.y == y;
	}
	virtual ~Point2() {}
	static size_t hashcode(const Point2& p) {
		 return ( 33 * p.x ) ^ p.y;
	}
};
void flyweight_main() {
	Point1 p0(1, 2);
	p0.print(cout) << endl;

	const Point2 p1(3, 4);
	const Point2 p2 = p1.move(1, 2);
	p1.print(cout) << endl;
	p2.print(cout) << endl;

	unordered_set<Point2, decltype(Point2::hashcode)*> my_points(3,Point2::hashcode);
	my_points.insert(p1);
	my_points.insert(p2);
	my_points.insert(p1.move(1,2)); //duplicate

	for (auto &p : my_points)
		p.print(cout) << endl;
}
