#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

class Decorator1;
class LineTracker
{
	unsigned int currentLine = 0;
	vector<Decorator1 *> headers, footers;
	static thread_local LineTracker ltr;
	LineTracker() {}
public:
	const static int LINES_PER_PAGE = 66;
	static LineTracker &get_instance()
	{
		return ltr;
	}
	static void add_headers_at_start(Decorator1 *d)
	{
		ltr.headers.insert(ltr.headers.begin(), d);
	}
	static void add_footers_at_end(Decorator1 *d)
	{
		ltr.footers.push_back(d);
	}
	static bool time_for_header(Decorator1 *d)
	{
		return ltr.currentLine < ltr.headers.size() &&
			ltr.headers.at(ltr.currentLine) == d;
	}
	static bool time_for_footer(Decorator1 *d)
	{
		unsigned int footerNumber = LINES_PER_PAGE - ltr.currentLine - 1;
		return footerNumber < ltr.footers.size() &&
			ltr.footers.at(footerNumber) == d;
	}
	static void reset()
	{
		ltr.currentLine = 0;
		ltr.headers = {};
		ltr.footers = {};
		cout << "----------End of Report----------------" << endl;
	}
	void print(string &line)
	{
		cout << line << endl;
		if (++currentLine < LINES_PER_PAGE) return;
		currentLine = 0;
		cout << "-----------New Page------------" << endl;
	}
};
thread_local LineTracker LineTracker::ltr;
class Report
{
public:
	virtual ~Report() {}
	virtual string *next_line() = 0;
	void print_full()
	{
		for (auto s=next_line(); s!=nullptr; s=next_line())
			LineTracker::get_instance().print(*s);
	}
};
class LineNumber : public Report
{
	int max;
	int currentLine = 0;
	string s;
public:
	LineNumber(int maximum) : max(maximum) {}
	string *next_line() override
	{
		if (++currentLine > max) return nullptr;
		ostringstream f;
		f << currentLine;
		s = f.str();
		return &s;
	}
};
class CharacterPr :public Report {
	int max;
	char c = 'a';
	string s;
public:
	CharacterPr(int max_chars) : max(max_chars) {}

	string *next_line() override {
		char p = c;
		if (++c > 'z') c = 'a';
		if ((max-- <= 0)) return nullptr;
		ostringstream f;
		f << p;
		s = f.str();
		return &s;
	}
};

class Decorator1 : public Report
{
protected:
	Report *r;
public:
	Decorator1(Report *re) : r(re) {}
	virtual ~Decorator1() { delete r; }
};
class Header1 : public Decorator1
{
	string h = "header 1";
public:
	Header1(Report *re) : Decorator1(re)
	{
		LineTracker::add_headers_at_start(this);
	}
	string *next_line() override
	{
		return LineTracker::time_for_header(this) ? &h : r->next_line();
	}
};
class Header2 : public Decorator1
{
	string h = "header 2";
public:
	Header2(Report *re) : Decorator1(re)
	{
		LineTracker::add_headers_at_start(this);
	}
	string *next_line() override
	{
		return LineTracker::time_for_header(this) ? &h : r->next_line();
	}
};
class Footer1 : public Decorator1
{
	string f = "footer 1";
public:
	Footer1(Report *re) : Decorator1(re)
	{
		LineTracker::add_footers_at_end(this);
	}
	string *next_line() override
	{
		return LineTracker::time_for_footer(this) ? &f : r->next_line();
	}
};
class Footer2 : public Decorator1
{
	string f = "footer 2";
public:
	Footer2(Report *re) : Decorator1(re)
	{
		LineTracker::add_footers_at_end(this);
	}
	string *next_line() override
	{
		return LineTracker::time_for_footer(this) ? &f : r->next_line();
	}
};
void decorator_assignment_main1()
{
	auto r =
		//new LineNumber(500);
		//new Header1(new LineNumber(500));
		//new Header2(new Header1(new LineNumber(500)));
		//new CharacterPr(400);
		//new Footer1(new CharacterPr(400));
		//new Footer2(new Footer1(new CharacterPr(400)));
		new Header1(new Header2(new Footer1(new Footer2(new CharacterPr(400)))));
	r->print_full();
}
